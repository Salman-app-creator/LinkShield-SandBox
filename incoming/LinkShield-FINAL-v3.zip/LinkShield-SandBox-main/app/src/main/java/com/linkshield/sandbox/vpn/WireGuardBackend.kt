package com.linkshield.sandbox.vpn

import android.content.Context
import com.wireguard.android.backend.GoBackend
import com.wireguard.android.backend.Tunnel

// GoBackend ek SINGLETON hona chahiye — multiple instances crash karte hain
// kyunki woh ek hi VpnService slot ko share karte hain.
object WireGuardBackend {

    @Volatile
    private var instance: GoBackend? = null

    fun get(context: Context): GoBackend {
        return instance ?: synchronized(this) {
            instance ?: GoBackend(context.applicationContext).also {
                instance = it
            }
        }
    }

    fun getState(context: Context, tunnel: Tunnel): Tunnel.State {
        return runCatching {
            get(context).getState(tunnel)
        }.getOrDefault(Tunnel.State.DOWN)
    }
}
