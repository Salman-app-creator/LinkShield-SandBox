package com.linkshield.sandbox.vpn

import android.content.Context
import com.wireguard.android.backend.Tunnel
import com.wireguard.config.Config
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

class WireGuardVpnController(
    private val context: Context
) {
    // Singleton backend — crash fix
    private val backend get() = WireGuardBackend.get(context)
    private val tunnel = LinkShieldTunnel()

    suspend fun connect(configText: String): Result<Unit> = withContext(Dispatchers.IO) {
        runCatching {
            require(configText.isNotBlank()) { "WireGuard configuration is empty" }
            val config = Config.parse(configText.byteInputStream())
            backend.setState(tunnel, Tunnel.State.UP, config)
            check(backend.getState(tunnel) == Tunnel.State.UP) {
                "WireGuard tunnel failed to start"
            }
            Unit
        }
    }

    suspend fun disconnect(): Result<Unit> = withContext(Dispatchers.IO) {
        runCatching {
            backend.setState(tunnel, Tunnel.State.DOWN, null)
            Unit
        }
    }

    fun isConnected(): Boolean {
        return runCatching {
            backend.getState(tunnel) == Tunnel.State.UP
        }.getOrDefault(false)
    }

    fun version(): String {
        return runCatching { backend.getVersion() }.getOrDefault("unknown")
    }

    private class LinkShieldTunnel : Tunnel {
        override fun getName() = "LinkShield"
        override fun onStateChange(newState: Tunnel.State) {}
    }
}
