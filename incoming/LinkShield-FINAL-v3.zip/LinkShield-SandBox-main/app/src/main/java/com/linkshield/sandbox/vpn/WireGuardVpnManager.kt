package com.linkshield.sandbox.vpn

import android.content.Context
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

class WireGuardVpnManager(context: Context) {

    private val repository  = WireGuardVpnRepository(context)
    private val controller  = WireGuardVpnController(context)
    val state               = WireGuardVpnState()

    suspend fun connect(): Result<Unit> = withContext(Dispatchers.IO) {
        state.setConnecting()

        val configResult = repository.loadConfig()
        val config = configResult.getOrElse { error ->
            val msg = error.message ?: "WireGuard configuration missing"
            state.setError(msg)
            return@withContext Result.failure(Exception(msg))
        }

        val connectResult = controller.connect(config)
        return@withContext connectResult
            .onSuccess { state.setConnected() }
            .onFailure { error ->
                state.setError(error.message ?: "Unable to connect")
            }
    }

    suspend fun disconnect(): Result<Unit> = withContext(Dispatchers.IO) {
        state.setDisconnecting()
        return@withContext controller.disconnect()
            .onSuccess  { state.setDisconnected() }
            .onFailure  { error -> state.setError(error.message ?: "Unable to disconnect") }
    }

    fun isConnected()       = controller.isConnected()
    fun hasConfiguration()  = repository.hasConfig()
    fun clearError()        = state.clearError()

    suspend fun saveConfiguration(configText: String) = repository.saveConfig(configText)

    suspend fun removeConfiguration() {
        if (controller.isConnected()) disconnect()
        repository.deleteConfig()
        state.setDisconnected()
    }
}
