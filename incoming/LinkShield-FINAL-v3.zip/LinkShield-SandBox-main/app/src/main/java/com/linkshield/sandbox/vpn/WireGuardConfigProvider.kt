package com.linkshield.sandbox.vpn

import android.content.Context
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

class WireGuardConfigProvider(context: Context) {

    private val repository = WireGuardConfigRepository(context)

    // ── Hardcoded LinkShield VPN config ──────────────────────────────────────
    // Oracle Cloud Mumbai server — permanent free tier
    private val HARDCODED_CONFIG = """
[Interface]
PrivateKey = wGOYZWTR+lStqpZUGKn/txvKPdgCTEkjTAhRJgHqO3M=
Address = 10.66.66.2/32,fd42:42:42::2/128
DNS = 1.1.1.1,1.0.0.1

[Peer]
PublicKey = cKyQuobdhp7+twoNW0muNo1mEB/4+IRS+LP51GQuxC4=
PresharedKey = JBnPv8YQkEdtm0R+h888nd56dyrpYK+T3X/nTT8C7Qs=
Endpoint = 141.148.223.177:54536
AllowedIPs = 0.0.0.0/0,::/0
""".trimIndent()

    // Always has config — hardcoded
    fun hasConfig(): Boolean = true

    suspend fun getConfig(): Result<String> = withContext(Dispatchers.IO) {
        Result.success(HARDCODED_CONFIG)
    }

    suspend fun getValidatedConfig(): Result<String> = withContext(Dispatchers.IO) {
        val validation = WireGuardConfigValidator.validate(HARDCODED_CONFIG)
        if (validation.isSuccess) Result.success(HARDCODED_CONFIG)
        else Result.failure(validation.exceptionOrNull()!!)
    }

    suspend fun isReady(): Boolean = true

    // These are no-ops now — config is hardcoded
    suspend fun setConfig(configText: String): Result<Unit> = Result.success(Unit)
    suspend fun clearConfig() {}
}
