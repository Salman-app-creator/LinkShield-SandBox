package com.linkshield.sandbox.license

import android.content.Context
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.intPreferencesKey
import androidx.datastore.preferences.core.longPreferencesKey
import androidx.datastore.preferences.core.stringSetPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch
import kotlinx.coroutines.runBlocking

private val Context.proStateDataStore by preferencesDataStore(name = "linkshield_pro_state")

data class ProState(
    val isPro: Boolean = false,
    val installDate: Long = System.currentTimeMillis(),
    val downloadCount: Int = 0,
    val usedKeys: Set<String> = emptySet(),
    val firstLaunchComplete: Boolean = false,
    val cachedValidHashes: Set<String> = emptySet()
)

interface ProStateRepository {
    fun snapshot(): ProState
    fun isProUser(): Boolean
    fun setProUser(value: Boolean)
    fun getInstallDate(): Long
    fun setFirstLaunchComplete()
    fun getDownloadCount(): Int
    fun incrementDownloadCount(): Int
    fun getUsedKeys(): Set<String>
    fun addUsedKey(key: String)
    fun getCachedValidHashes(): Set<String>
    fun setCachedValidHashes(hashes: Set<String>)
    fun reset()
}

/** DataStore-backed implementation with one-time SharedPreferences migration. */
class DataStoreProStateRepository(context: Context) : ProStateRepository {
    private val appContext = context.applicationContext
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)

    @Volatile private var state: ProState = runBlocking(Dispatchers.IO) { loadOrMigrate() }

    override fun snapshot(): ProState = state
    override fun isProUser(): Boolean = state.isPro
    override fun getInstallDate(): Long = state.installDate

    override fun setProUser(value: Boolean) {
        state = state.copy(isPro = value)
        persist { it[KEY_IS_PRO] = value }
    }

    override fun setFirstLaunchComplete() {
        state = state.copy(firstLaunchComplete = true)
        persist { it[KEY_FIRST_LAUNCH] = true }
    }

    override fun getDownloadCount(): Int = state.downloadCount

    override fun incrementDownloadCount(): Int {
        val next = state.downloadCount + 1
        state = state.copy(downloadCount = next)
        persist { it[KEY_DOWNLOAD_COUNT] = next }
        return next
    }

    override fun getUsedKeys(): Set<String> = state.usedKeys

    override fun addUsedKey(key: String) {
        val next = state.usedKeys + key
        state = state.copy(usedKeys = next)
        persist { it[KEY_USED_KEYS] = next }
    }

    override fun getCachedValidHashes(): Set<String> = state.cachedValidHashes

    override fun setCachedValidHashes(hashes: Set<String>) {
        state = state.copy(cachedValidHashes = hashes)
        persist { it[KEY_CACHED_HASHES] = hashes }
    }

    override fun reset() {
        state = ProState()
        scope.launch { appContext.proStateDataStore.edit { it.clear() } }
    }

    private fun persist(block: (androidx.datastore.preferences.core.MutablePreferences) -> Unit) {
        scope.launch { appContext.proStateDataStore.edit(block) }
    }

    private suspend fun loadOrMigrate(): ProState {
        val existing = appContext.proStateDataStore.data.first()
        if (existing.asMap().isNotEmpty()) return existing.toState()

        val legacy = appContext.getSharedPreferences(LEGACY_PREFS, Context.MODE_PRIVATE)
        val migrated = ProState(
            isPro = legacy.getBoolean("is_pro_activated", false),
            installDate = legacy.getLong("install_date", System.currentTimeMillis()),
            downloadCount = legacy.getInt("download_count", 0),
            usedKeys = legacy.getStringSet("used_keys", emptySet()) ?: emptySet(),
            firstLaunchComplete = legacy.getBoolean("first_launch_complete", false),
            cachedValidHashes = legacy.getStringSet("cached_valid_hashes", emptySet()) ?: emptySet()
        )
        appContext.proStateDataStore.edit { prefs ->
            prefs[KEY_IS_PRO] = migrated.isPro
            prefs[KEY_INSTALL_DATE] = migrated.installDate
            prefs[KEY_DOWNLOAD_COUNT] = migrated.downloadCount
            prefs[KEY_USED_KEYS] = migrated.usedKeys
            prefs[KEY_FIRST_LAUNCH] = migrated.firstLaunchComplete
            prefs[KEY_CACHED_HASHES] = migrated.cachedValidHashes
        }
        return migrated
    }

    private fun Preferences.toState() = ProState(
        isPro = this[KEY_IS_PRO] ?: false,
        installDate = this[KEY_INSTALL_DATE] ?: System.currentTimeMillis(),
        downloadCount = this[KEY_DOWNLOAD_COUNT] ?: 0,
        usedKeys = this[KEY_USED_KEYS] ?: emptySet(),
        firstLaunchComplete = this[KEY_FIRST_LAUNCH] ?: false,
        cachedValidHashes = this[KEY_CACHED_HASHES] ?: emptySet()
    )

    companion object {
        private const val LEGACY_PREFS = "license_prefs"
        private val KEY_IS_PRO = booleanPreferencesKey("is_pro_activated")
        private val KEY_INSTALL_DATE = longPreferencesKey("install_date")
        private val KEY_DOWNLOAD_COUNT = intPreferencesKey("download_count")
        private val KEY_USED_KEYS = stringSetPreferencesKey("used_keys")
        private val KEY_FIRST_LAUNCH = booleanPreferencesKey("first_launch_complete")
        private val KEY_CACHED_HASHES = stringSetPreferencesKey("cached_valid_hashes")
    }
}
