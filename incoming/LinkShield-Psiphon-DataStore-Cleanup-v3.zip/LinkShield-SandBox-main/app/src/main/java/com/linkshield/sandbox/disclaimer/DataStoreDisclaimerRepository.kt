package com.linkshield.sandbox.disclaimer

import android.content.Context
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.runBlocking
import kotlinx.coroutines.launch

private val Context.disclaimerDataStore by preferencesDataStore(name = "linkshield_disclaimer")

class DataStoreDisclaimerRepository(context: Context) : DisclaimerRepository {
    private val appContext = context.applicationContext
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)

    @Volatile private var accepted: Boolean
    @Volatile private var browserSet: Boolean

    init {
        val values = runBlocking(Dispatchers.IO) { loadOrMigrate() }
        accepted = values.first
        browserSet = values.second
    }

    override fun isAccepted(): Boolean = accepted
    override fun setAccepted(value: Boolean) {
        accepted = value
        scope.launch { appContext.disclaimerDataStore.edit { it[KEY_ACCEPTED] = value } }
    }

    override fun isBrowserSet(): Boolean = browserSet
    override fun setBrowserSet(value: Boolean) {
        browserSet = value
        scope.launch { appContext.disclaimerDataStore.edit { it[KEY_BROWSER_SET] = value } }
    }

    private suspend fun loadOrMigrate(): Pair<Boolean, Boolean> {
        val data = appContext.disclaimerDataStore.data.first()
        if (data.asMap().isNotEmpty()) {
            return (data[KEY_ACCEPTED] ?: false) to (data[KEY_BROWSER_SET] ?: false)
        }
        val legacy = appContext.getSharedPreferences(LEGACY_PREFS, Context.MODE_PRIVATE)
        val result = legacy.getBoolean(KEY_ACCEPTED.name, false) to
            legacy.getBoolean(KEY_BROWSER_SET.name, false)
        appContext.disclaimerDataStore.edit {
            it[KEY_ACCEPTED] = result.first
            it[KEY_BROWSER_SET] = result.second
        }
        return result
    }

    companion object {
        private const val LEGACY_PREFS = "disclaimer_prefs"
        private val KEY_ACCEPTED = booleanPreferencesKey("disclaimer_accepted")
        private val KEY_BROWSER_SET = booleanPreferencesKey("browser_set")
    }
}
