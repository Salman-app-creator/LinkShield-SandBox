package com.linkshield.sandbox.disclaimer

interface DisclaimerRepository {
    fun isAccepted(): Boolean
    fun setAccepted(value: Boolean)
    fun isBrowserSet(): Boolean
    fun setBrowserSet(value: Boolean)
}
