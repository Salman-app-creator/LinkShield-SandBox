package com.linkshield.sandbox.vpn

import android.content.Context
import com.linkshield.sandbox.vpn.psiphon.PsiphonVpnManager
import kotlinx.coroutines.flow.StateFlow

/**
 * Compatibility adapter kept so the frozen UnblockShieldScreen needs no UI
 * changes. The implementation is now Psiphon; no WireGuard code is executed.
 */
class WireGuardVpnManager(context: Context) : VpnManager {
    private val delegate = PsiphonVpnManager(context.applicationContext)

    val status: StateFlow<VpnStatus> get() = delegate.status
    val error: StateFlow<String?> get() = delegate.error

    override suspend fun connect(): Result<Unit> = delegate.connect()
    override suspend fun disconnect(): Result<Unit> = delegate.disconnect()
    override fun isConnected(): Boolean = delegate.isConnected()

    // Legacy API retained for source compatibility with older callers.
    fun hasConfiguration(): Boolean = true
    suspend fun saveConfiguration(configText: String): Result<Unit> =
        if (configText.isNotBlank()) Result.success(Unit)
        else Result.failure(IllegalArgumentException("Psiphon does not use WireGuard configuration"))

    suspend fun removeConfiguration() {
        if (isConnected()) disconnect()
    }

    fun clearError() {
        // State errors are reset on the next connect/disconnect transition.
    }
}
