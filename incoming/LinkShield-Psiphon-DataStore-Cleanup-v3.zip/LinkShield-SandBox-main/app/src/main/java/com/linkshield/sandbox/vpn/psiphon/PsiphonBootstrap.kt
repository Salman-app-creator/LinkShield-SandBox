package com.linkshield.sandbox.vpn.psiphon

import android.content.Context
import android.util.Log
import ca.psiphon.PsiphonTunnel
import com.linkshield.sandbox.R

/** Small, testable bootstrap boundary around the Psiphon AAR. */
object PsiphonBootstrap {
    private const val TAG = "PsiphonBootstrap"

    fun loadConfig(context: Context): String {
        return runCatching {
            context.resources.openRawResource(R.raw.psiphon_config)
                .bufferedReader(Charsets.UTF_8)
                .use { it.readText() }
        }.getOrElse {
            Log.e(TAG, "Unable to load Psiphon config", it)
            ""
        }
    }

    fun createTunnel(hostService: PsiphonTunnel.HostService): PsiphonTunnel =
        PsiphonTunnel.newPsiphonTunnel(hostService)
}
