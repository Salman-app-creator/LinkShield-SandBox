package com.linkshield.sandbox.license

import android.content.Context
import android.util.Log
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.security.MessageDigest
import java.util.concurrent.TimeUnit

class LicenseManager(context: Context) {
    private val appContext = context.applicationContext
    private val repository: ProStateRepository = DataStoreProStateRepository(appContext)

    companion object {
        private const val TAG = "LicenseManager"
        private const val TRIAL_DAYS = 7L
        private const val FREE_DOWNLOAD_LIMIT = 20
        private const val GITHUB_JSON_URL =
            "https://raw.githubusercontent.com/Salman-app-creator/LinkShield-SandBox/refs/heads/main/Licenses.json"
    }

    fun isFirstLaunchComplete(): Boolean = repository.snapshot().firstLaunchComplete
    fun setFirstLaunchComplete() = repository.setFirstLaunchComplete()

    fun isProUser(): Boolean = repository.isProUser()
    fun getInstallDate(): Long = repository.getInstallDate()

    fun getDaysSinceInstall(): Long = TimeUnit.MILLISECONDS.toDays(
        System.currentTimeMillis() - getInstallDate()
    )

    fun getTrialDaysRemaining(): Int =
        (TRIAL_DAYS - getDaysSinceInstall()).coerceAtLeast(0).toInt()

    fun isTrialActive(): Boolean = getTrialDaysRemaining() > 0

    fun getDownloadCount(): Int = repository.getDownloadCount()

    fun incrementDownloadCount(): Boolean {
        if (isProUser()) return true
        val current = getDownloadCount()
        if (current >= FREE_DOWNLOAD_LIMIT) return false
        repository.incrementDownloadCount()
        return true
    }

    fun getRemainingDownloads(): Int =
        if (isProUser()) Int.MAX_VALUE
        else (FREE_DOWNLOAD_LIMIT - getDownloadCount()).coerceAtLeast(0)

    fun canDownload(): Boolean =
        isProUser() || (isTrialActive() && getDownloadCount() < FREE_DOWNLOAD_LIMIT)

    fun canUseFullShield(): Boolean = isProUser() || isTrialActive()

    fun isAccessAllowed(): Boolean =
        isProUser() || isTrialActive() || getDownloadCount() < FREE_DOWNLOAD_LIMIT

    fun getRestrictionReason(): String = when {
        isProUser() -> ""
        !isTrialActive() && getDownloadCount() >= FREE_DOWNLOAD_LIMIT ->
            "Trial ended and download limit reached. Upgrade to Pro for unlimited access."
        !isTrialActive() ->
            "Your 7-day trial has ended. Upgrade to Pro to continue using all features."
        getDownloadCount() >= FREE_DOWNLOAD_LIMIT ->
            "You have used all 20 free downloads. Upgrade to Pro for unlimited downloads."
        else -> ""
    }

    fun getStatusBadgeText(): String = when {
        isProUser() -> "PRO UNLOCKED"
        isTrialActive() -> "TRIAL: ${getTrialDaysRemaining()}d left"
        getDownloadCount() >= FREE_DOWNLOAD_LIMIT -> "DL LIMIT REACHED"
        else -> "TRIAL: ${getTrialDaysRemaining()}d | ${getRemainingDownloads()} DLs"
    }

    fun getUsedKeysCount(): Int = repository.getUsedKeys().size

    private fun hashKey(key: String): String {
        val bytes = MessageDigest.getInstance("SHA-256")
            .digest(key.toByteArray(Charsets.UTF_8))
        return bytes.joinToString("") { "%02x".format(it) }
    }

    suspend fun validateKey(key: String): Boolean = withContext(Dispatchers.IO) {
        val trimmed = key.trim().uppercase()
        if (trimmed.isEmpty()) return@withContext false
        if (isProUser()) return@withContext true

        val inputHash = hashKey(trimmed)
        Log.d(TAG, "Validating key hash: $inputHash")

        val remoteValid = try {
            fetchAndValidate(inputHash)
        } catch (error: Exception) {
            Log.w(TAG, "Remote license validation failed: ${error.message}")
            false
        }
        if (remoteValid) {
            activatePro(trimmed)
            return@withContext true
        }

        val cachedHashes = repository.getCachedValidHashes()
        if (cachedHashes.contains(inputHash.lowercase())) {
            activatePro(trimmed)
            return@withContext true
        }

        Log.e(TAG, "Key invalid or GitHub fetch failed.")
        false
    }

    private suspend fun fetchAndValidate(inputHash: String): Boolean = withContext(Dispatchers.IO) {
        val connection = (URL("$GITHUB_JSON_URL?t=${System.currentTimeMillis()}").openConnection() as HttpURLConnection).apply {
            requestMethod = "GET"
            connectTimeout = 12_000
            readTimeout = 12_000
            setRequestProperty("User-Agent", "Mozilla/5.0 LinkShieldAndroid")
            setRequestProperty("Cache-Control", "no-cache, no-store, must-revalidate")
            setRequestProperty("Pragma", "no-cache")
        }

        try {
            if (connection.responseCode != HttpURLConnection.HTTP_OK) {
                Log.e(TAG, "GitHub HTTP ${connection.responseCode}")
                return@withContext false
            }

            val jsonString = connection.inputStream.bufferedReader(Charsets.UTF_8).use { it.readText() }.trim()
            if (jsonString.isEmpty()) return@withContext false

            val remoteHashes = mutableSetOf<String>()
            when {
                jsonString.startsWith("[") -> {
                    val arr = JSONArray(jsonString)
                    for (i in 0 until arr.length()) remoteHashes += arr.getString(i).trim().lowercase()
                }
                jsonString.startsWith("{") -> {
                    val obj = JSONObject(jsonString)
                    val arr = obj.optJSONArray("valid_keys") ?: JSONArray()
                    for (i in 0 until arr.length()) remoteHashes += arr.getString(i).trim().lowercase()
                }
                else -> return@withContext false
            }

            if (remoteHashes.isNotEmpty()) repository.setCachedValidHashes(remoteHashes)
            remoteHashes.contains(inputHash.lowercase())
        } finally {
            connection.disconnect()
        }
    }

    private fun activatePro(key: String) {
        repository.setProUser(true)
        repository.addUsedKey(key)
        runCatching { com.linkshield.sandbox.dns.DnsManager(appContext).setProUser(true) }
        Log.d(TAG, "Pro activated")
    }

    fun resetForTesting() = repository.reset()
}
