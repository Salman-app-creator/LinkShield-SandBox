package com.linkshield.sandbox.disclaimer

import android.content.Context

class DisclaimerManager(context: Context) {
    private val repository: DisclaimerRepository = DataStoreDisclaimerRepository(context)

    fun hasAccepted(): Boolean = repository.isAccepted()
    fun accept() = repository.setAccepted(true)
    fun hasBrowserSet(): Boolean = repository.isBrowserSet()
    fun markBrowserSet() = repository.setBrowserSet(true)
}
