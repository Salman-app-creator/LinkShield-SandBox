package com.linkshield.sandbox.vpn

/** UI-facing contract for the active shield tunnel implementation. */
interface VpnManager {
    suspend fun connect(): Result<Unit>
    suspend fun disconnect(): Result<Unit>
    fun isConnected(): Boolean
}
