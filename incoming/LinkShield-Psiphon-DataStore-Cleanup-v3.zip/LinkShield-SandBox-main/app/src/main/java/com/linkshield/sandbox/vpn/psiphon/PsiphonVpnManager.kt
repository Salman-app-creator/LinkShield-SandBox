package com.linkshield.sandbox.vpn.psiphon

import android.content.Context
import android.content.Intent
import android.os.Build
import com.linkshield.sandbox.vpn.VpnManager
import com.linkshield.sandbox.vpn.VpnStatus
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.withContext

/** Psiphon-backed implementation of the app's shield contract. */
class PsiphonVpnManager(private val context: Context) : VpnManager {
    private val appContext = context.applicationContext

    val status: StateFlow<VpnStatus> get() = state.status
    val error: StateFlow<String?> get() = state.error

    override suspend fun connect(): Result<Unit> = withContext(Dispatchers.IO) {
        if (isConnected()) return@withContext Result.success(Unit)
        state.setConnecting()
        runCatching {
            val intent = Intent(appContext, PsiphonVpnService::class.java)
                .setAction(PsiphonVpnService.ACTION_START)
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                appContext.startForegroundService(intent)
            } else {
                appContext.startService(intent)
            }
            Unit
        }.onFailure { state.setError(it.message ?: "Unable to start Psiphon") }
    }

    override suspend fun disconnect(): Result<Unit> = withContext(Dispatchers.IO) {
        if (!isConnected() && state.status.value == VpnStatus.DISCONNECTED) {
            return@withContext Result.success(Unit)
        }
        state.setDisconnecting()
        runCatching {
            appContext.startService(
                Intent(appContext, PsiphonVpnService::class.java)
                    .setAction(PsiphonVpnService.ACTION_STOP)
            )
            state.setDisconnected()
            Unit
        }.onFailure { state.setError(it.message ?: "Unable to stop Psiphon") }
    }

    override fun isConnected(): Boolean = PsiphonVpnService.isRunning()

    companion object {
        private val state = PsiphonVpnState()

        internal fun markConnecting() = state.setConnecting()
        internal fun markConnected() = state.setConnected()
        internal fun markDisconnected() = state.setDisconnected()
        internal fun markError(message: String) = state.setError(message)
    }

    private class PsiphonVpnState {
        private val _status = MutableStateFlow(VpnStatus.DISCONNECTED)
        val status: StateFlow<VpnStatus> = _status.asStateFlow()
        private val _error = MutableStateFlow<String?>(null)
        val error: StateFlow<String?> = _error.asStateFlow()

        fun setConnecting() { _error.value = null; _status.value = VpnStatus.CONNECTING }
        fun setConnected() { _error.value = null; _status.value = VpnStatus.CONNECTED }
        fun setDisconnected() { _error.value = null; _status.value = VpnStatus.DISCONNECTED }
        fun setDisconnecting() { _status.value = VpnStatus.DISCONNECTING }
        fun setError(message: String) { _error.value = message; _status.value = VpnStatus.ERROR }
    }
}
