package com.linkshield.sandbox.vpn

import android.content.Intent
import android.net.VpnService
import android.os.IBinder
import com.linkshield.sandbox.vpn.psiphon.PsiphonVpnService

/**
 * Compatibility VPN-service shell for the frozen UI's VpnService.prepare() call.
 * The actual tunnel implementation is PsiphonVpnService.
 */
class WireGuardVpnService : VpnService() {
    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val action = intent?.action
        val psiphonIntent = Intent(this, PsiphonVpnService::class.java).setAction(
            if (action == VpnActionReceiver.ACTION_DISCONNECT) {
                PsiphonVpnService.ACTION_STOP
            } else {
                PsiphonVpnService.ACTION_START
            }
        )
        startService(psiphonIntent)
        stopSelf(startId)
        return START_NOT_STICKY
    }

    override fun onBind(intent: Intent): IBinder? = super.onBind(intent)
}
