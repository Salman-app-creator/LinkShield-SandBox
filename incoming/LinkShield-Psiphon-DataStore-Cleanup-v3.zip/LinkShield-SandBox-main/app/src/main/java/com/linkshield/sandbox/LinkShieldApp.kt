package com.linkshield.sandbox

import android.app.Application
import android.util.Log
import com.linkshield.sandbox.adblock.AdBlockEngine
import com.linkshield.sandbox.vpn.VpnNotificationHelper
import com.linkshield.sandbox.vpn.psiphon.PsiphonBootstrap
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch

class LinkShieldApp : Application() {

    private val appScope =
        CoroutineScope(SupervisorJob() + Dispatchers.Default)

    override fun onCreate() {
        super.onCreate()

        VpnNotificationHelper.createChannel(this)

        runCatching {
            PsiphonBootstrap.loadConfig(this)
        }.onFailure {
            Log.w("LinkShieldApp", "Psiphon configuration validation failed: ${it.message}")
        }

        appScope.launch(Dispatchers.IO) {
            runCatching {
                AdBlockEngine
                    .getInstance()
                    .initialize(this@LinkShieldApp)
            }.onFailure {
                Log.w(
                    "LinkShieldApp",
                    "AdBlock initialization failed: ${it.message}"
                )
            }
        }
    }
}
