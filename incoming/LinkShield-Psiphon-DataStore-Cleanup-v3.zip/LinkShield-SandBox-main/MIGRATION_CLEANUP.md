# LinkShield A+B+C cleanup

## Intentionally deleted
- Legacy Grabber/MediaExtractor implementation files.
- WireGuard controller/repository/state implementation files.

## Intentionally retained
- `vpn/WireGuardVpnManager.kt` — compatibility adapter required by the frozen `UnblockShieldScreen`.
- `vpn/WireGuardVpnService.kt` — compatibility VpnService shell.
- `vpn/VpnStatus.kt` — common VPN status enum.

## Runtime
The retained WireGuard-named adapter delegates to Psiphon. No WireGuard runtime dependency is used.

## Import requirement
Use `.github/workflows/import-zip.yml` to import this ZIP. Do not use the normal Build Debug workflow before importing, because Build Debug only builds the files already present in the repository.
