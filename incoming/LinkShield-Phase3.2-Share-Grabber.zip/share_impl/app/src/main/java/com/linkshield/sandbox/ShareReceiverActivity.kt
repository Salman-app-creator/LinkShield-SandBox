package com.linkshield.sandbox

import android.app.Activity
import android.content.Intent
import android.os.Bundle

/**
 * Android Sharesheet entry point for "LinkShield Grabber".
 *
 * It receives a shared URL/text and forwards it to the existing MainActivity
 * without introducing another downloader or changing the existing UI.
 */
class ShareReceiverActivity : Activity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        forwardSharedContent(intent)
    }

    private fun forwardSharedContent(source: Intent?) {
        val sharedText = source?.getStringExtra(Intent.EXTRA_TEXT)?.trim().orEmpty()
        val url = extractUrl(sharedText)

        if (url.isBlank()) {
            finish()
            return
        }

        val launch = Intent(this, MainActivity::class.java).apply {
            putExtra(EXTRA_SHARED_GRAB_URL, url)
            addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_SINGLE_TOP)
        }
        startActivity(launch)
        finish()
    }

    companion object {
        const val EXTRA_SHARED_GRAB_URL = "shared_grab_url"

        private val URL_REGEX = Regex("https?://[^\\s<>\"]+", RegexOption.IGNORE_CASE)

        fun extractUrl(text: String): String {
            val match = URL_REGEX.find(text)?.value.orEmpty()
            return match.trimEnd('.', ',', ';', ':', ')', ']', '}')
        }
    }
}
