# LinkShield Phase 3.2 — Android Share Sheet Grabber

## What changed

The existing Grabber UI and download engines are preserved. This phase adds a dedicated Android Sharesheet target named **LinkShield Grabber**.

### User flow

`Social app / browser -> Share -> LinkShield Grabber -> Grabber tab opens -> shared URL is inserted -> Fetch starts automatically`

### Implementation

- Added `ShareReceiverActivity.kt` as a dedicated `ACTION_SEND` receiver.
- Manifest entry is labeled **LinkShield Grabber**, so the Android Sharesheet can show that name without changing the launcher app label.
- Supports `text/plain` and `text/uri-list` shared content.
- Extracts the first HTTP(S) URL and removes common trailing punctuation.
- Forwards the URL to the existing `MainActivity`.
- Existing disclaimer/default-browser flow remains intact; a pending shared URL is retained until the Grabber screen consumes it.
- `UnblockShieldScreen` switches to the existing Grabber tab for a shared link.
- `LinkShieldGrabberScreen` now supports an optional `autoFetchInitialUrl` mode and starts the existing fetch engine automatically for a shared URL.
- No visual layout redesign or new floating overlay was added.

## Build verification

XML files were parsed successfully and brace/parenthesis checks passed for modified Kotlin files.

A full Gradle compile could not be executed in this environment because the repository's `gradlew` delegates to a system `gradle` executable, and that executable is not installed in the current build environment (`gradle: not found`).

## Important Android behavior

The exact placement of **LinkShield Grabber** in the Sharesheet is controlled by Android and the source app. The target should be available when another app shares compatible text/URL content; Android may rank it differently in the Sharesheet.
