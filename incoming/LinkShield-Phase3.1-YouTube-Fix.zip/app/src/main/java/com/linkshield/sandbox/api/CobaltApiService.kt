package com.linkshield.sandbox.api

import android.content.Context
import android.net.Uri
import com.linkshield.sandbox.BuildConfig
import com.linkshield.sandbox.ui.grabber.YtDlpEngine
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONObject
import java.net.SocketTimeoutException
import java.util.concurrent.TimeUnit

data class MediaResult(
    val success: Boolean,
    val url: String? = null,
    val secondaryUrl: String? = null,
    val filename: String? = null,
    val mimeType: String? = null,
    val error: String? = null
)

class CobaltApiService(context: Context) {

    private val appContext = context.applicationContext

    private val client: OkHttpClient by lazy {
        OkHttpClient.Builder()
            .connectTimeout(12, TimeUnit.SECONDS)
            .readTimeout(45, TimeUnit.SECONDS)
            .writeTimeout(15, TimeUnit.SECONDS)
            .callTimeout(60, TimeUnit.SECONDS)
            .followRedirects(true)
            .followSslRedirects(true)
            .retryOnConnectionFailure(true)
            .build()
    }

    private fun baseUrl(): String =
        BuildConfig.COBALT_BASE_URL.trim().trimEnd('/') + "/"

    private fun isYouTubeUrl(host: String): Boolean =
        host == "youtube.com" || host.endsWith(".youtube.com") ||
            host == "youtu.be" || host.endsWith(".youtu.be")

    fun cleanVideoUrl(rawUrl: String): String {
        val trimmed = rawUrl.trim()
        return try {
            val uri = Uri.parse(trimmed)
            val host = uri.host?.lowercase().orEmpty()
            when {
                host == "youtube.com" || host.endsWith(".youtube.com") -> {
                    val videoId = uri.getQueryParameter("v")
                    when {
                        !videoId.isNullOrBlank() -> "https://www.youtube.com/watch?v=$videoId"
                        uri.path?.startsWith("/shorts/") == true -> "https://www.youtube.com${uri.path}"
                        else -> trimmed
                    }
                }
                host == "youtu.be" || host.endsWith(".youtu.be") -> {
                    val videoId = uri.lastPathSegment
                    if (!videoId.isNullOrBlank()) "https://www.youtube.com/watch?v=$videoId" else trimmed
                }
                else -> trimmed
            }
        } catch (_: Exception) {
            trimmed
        }
    }

    suspend fun fetchMediaUrl(
        rawUrl: String,
        audioOnly: Boolean = false,
        resolution: String = "1080p"
    ): MediaResult = withContext(Dispatchers.IO) {
        val cleanedUrl = cleanVideoUrl(rawUrl)
        val host = Uri.parse(cleanedUrl).host?.lowercase().orEmpty()

        if (cleanedUrl.isBlank() || !cleanedUrl.startsWith("http", ignoreCase = true)) {
            return@withContext MediaResult(false, error = "Invalid media URL")
        }

        val youtube = isYouTubeUrl(host)

        // IMPORTANT: Cobalt is attempted FIRST for YouTube.
        // Current yt-dlp requires a JavaScript runtime + EJS for full YouTube
        // extraction. The Android AAR embeds Python/yt-dlp but does not provide
        // an Android Deno runtime, so waiting on yt-dlp first can leave the UI
        // stuck until the extraction timeout. Cobalt gives us a fast server-side
        // path when the self-hosted instance supports the requested URL.
        val cobaltResult = fetchFromCobalt(cleanedUrl, host, audioOnly, resolution)
        if (cobaltResult.success) return@withContext cobaltResult

        if (youtube) {
            val yt = YtDlpEngine.resolveMedia(
                appContext,
                cleanedUrl,
                resolution = resolution,
                audioOnly = audioOnly
            )
            if (yt.success && !yt.url.isNullOrBlank()) {
                return@withContext MediaResult(
                    success = true,
                    url = yt.url,
                    secondaryUrl = yt.secondaryUrl,
                    filename = yt.filename,
                    mimeType = yt.mimeType ?: if (audioOnly) "audio/mpeg" else "video/mp4"
                )
            }

            return@withContext MediaResult(
                false,
                error = buildString {
                    append("YouTube extraction failed. ")
                    append(yt.error ?: cobaltResult.error ?: "Please try again.")
                }
            )
        }

        cobaltResult
    }

    private fun fetchFromCobalt(
        cleanedUrl: String,
        host: String,
        audioOnly: Boolean,
        resolution: String
    ): MediaResult {
        return try {
            val quality = when {
                resolution.equals("4K", true) -> "2160"
                resolution.endsWith("p", true) -> resolution.dropLast(1)
                else -> "1080"
            }

            val bodyJson = JSONObject().apply {
                put("url", cleanedUrl)
                put("downloadMode", if (audioOnly) "audio" else "auto")
                put("videoQuality", quality)
                put("filenameStyle", "pretty")
                put("audioFormat", "mp3")
                put("audioBitrate", "128")
                put("localProcessing", "disabled")
                if (isYouTubeUrl(host)) {
                    put("youtubeVideoCodec", "h264")
                    put("youtubeVideoContainer", "mp4")
                }
            }.toString()

            val builder = Request.Builder()
                .url(baseUrl())
                .post(bodyJson.toRequestBody("application/json; charset=utf-8".toMediaType()))
                .header("Accept", "application/json")
                .header("Content-Type", "application/json")
                .header("User-Agent", "LinkShieldSandbox/2.3")

            if (BuildConfig.COBALT_API_KEY.isNotBlank()) {
                builder.header("Authorization", "Api-Key ${BuildConfig.COBALT_API_KEY}")
            }

            client.newCall(builder.build()).execute().use { response ->
                val body = response.body?.string().orEmpty()

                if (!response.isSuccessful) {
                    return MediaResult(
                        false,
                        error = when (response.code) {
                            401, 403 -> "Cobalt authentication/access denied (HTTP ${response.code})."
                            429 -> "Cobalt rate limit reached."
                            else -> "Cobalt server returned HTTP ${response.code}."
                        }
                    )
                }
                if (body.isBlank()) return MediaResult(false, error = "Cobalt returned an empty response.")

                val json = JSONObject(body)
                when (json.optString("status")) {
                    "tunnel", "redirect" -> {
                        val mediaUrl = json.optString("url")
                        if (mediaUrl.isBlank()) {
                            MediaResult(false, error = "Cobalt returned no media URL.")
                        } else {
                            val fallbackExt = if (audioOnly) "mp3" else "mp4"
                            val filename = json.optString("filename").ifBlank {
                                "LinkShield_${System.currentTimeMillis()}.$fallbackExt"
                            }
                            MediaResult(
                                success = true,
                                url = mediaUrl,
                                filename = filename,
                                mimeType = if (audioOnly) "audio/mpeg" else guessMime(filename)
                            )
                        }
                    }

                    "picker" -> {
                        val picker = json.optJSONArray("picker")
                        if (picker == null || picker.length() == 0) {
                            MediaResult(false, error = "Cobalt returned an empty media picker.")
                        } else {
                            var chosen = picker.optJSONObject(0)
                            for (i in 0 until picker.length()) {
                                val item = picker.optJSONObject(i)
                                if (item?.optString("type") == "video") {
                                    chosen = item
                                    break
                                }
                            }
                            val mediaUrl = chosen?.optString("url").orEmpty()
                            if (mediaUrl.isBlank()) {
                                MediaResult(false, error = "Cobalt picker item contained no media URL.")
                            } else {
                                MediaResult(
                                    true,
                                    url = mediaUrl,
                                    filename = "LinkShield_${System.currentTimeMillis()}.mp4",
                                    mimeType = "video/mp4"
                                )
                            }
                        }
                    }

                    "local-processing" -> MediaResult(
                        false,
                        error = "Cobalt requires local media processing."
                    )

                    "error" -> {
                        val errorObject = json.optJSONObject("error")
                        val code = errorObject?.optString("code").orEmpty()
                        val contextObject = errorObject?.optJSONObject("context")
                        val service = contextObject?.optString("service").orEmpty()
                        val limit = contextObject?.optInt("limit", -1)?.takeIf { it >= 0 }
                        val details = buildList {
                            if (service.isNotBlank()) add("service=$service")
                            if (limit != null) add("limit=$limit")
                        }.joinToString(", ")
                        MediaResult(
                            false,
                            error = "Cobalt error${if (code.isNotBlank()) " [$code]" else ""}" +
                                if (details.isNotBlank()) " ($details)" else "."
                        )
                    }

                    else -> MediaResult(
                        false,
                        error = "Unexpected Cobalt status: '${json.optString("status", "unknown")}'."
                    )
                }
            }
        } catch (_: SocketTimeoutException) {
            MediaResult(false, error = "Cobalt request timed out.")
        } catch (e: Exception) {
            MediaResult(false, error = e.localizedMessage ?: "Cobalt network request failed.")
        }
    }

    private fun guessMime(filename: String): String = when (
        filename.substringAfterLast('.', "").lowercase()
    ) {
        "mp3" -> "audio/mpeg"
        "m4a" -> "audio/mp4"
        "ogg" -> "audio/ogg"
        "wav" -> "audio/wav"
        "webm" -> "video/webm"
        "gif" -> "image/gif"
        else -> "video/mp4"
    }
}
