# LinkShield Sandbox — Phase 3.1 YouTube Fetch Fix

## Symptom
Facebook downloads work, but YouTube remains on `Fetching...`.

## Root cause found in Phase 3
The Grabber tried local yt-dlp FIRST for YouTube. The current yt-dlp ecosystem requires a JavaScript runtime plus EJS for full YouTube extraction. The Android `yt-dlp-android` AAR embeds Python/yt-dlp but does not provide an Android Deno runtime. As a result, the local extractor could wait for its timeout before Cobalt was tried.

There was also a second bug: the `-g` resolver only completed its coroutine when an HTTP URL appeared. If yt-dlp reported an error, it could wait until the timeout instead of immediately returning failure.

## Fix
1. Cobalt is now attempted FIRST for YouTube, using the existing self-hosted current POST `/` API.
2. If Cobalt fails, yt-dlp is used as a fallback.
3. yt-dlp resolver timeout reduced from 45s to 15s.
4. yt-dlp error lines now complete the resolver immediately instead of waiting for timeout.
5. Audio-only YouTube requests also benefit from Cobalt-first behavior.
6. No visual Compose UI changes were made for this fix.

## Important limitation
If both Cobalt and yt-dlp fail, YouTube may still require a working JS runtime/EJS setup, bot/region access, or a server-side extractor path. This is an extraction/backend limitation, not a UI issue.

## Files changed
- `app/src/main/java/com/linkshield/sandbox/api/CobaltApiService.kt`
- `app/src/main/java/com/linkshield/sandbox/ui/grabber/YtDlpEngine.kt`

No Gradle build was performed in this environment because the repository's `gradlew` delegates to a system `gradle` executable and no system Gradle is installed here.
