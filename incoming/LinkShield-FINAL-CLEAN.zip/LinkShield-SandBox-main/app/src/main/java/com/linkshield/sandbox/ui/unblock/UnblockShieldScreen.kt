package com.linkshield.sandbox.ui.unblock

import android.app.Activity
import android.net.VpnService
import android.webkit.WebView
import android.widget.Toast
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Download
import androidx.compose.material.icons.filled.Public
import androidx.compose.material.icons.filled.Star
import androidx.compose.material3.Icon
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import com.linkshield.sandbox.license.LicenseManager
import com.linkshield.sandbox.ui.browser.SandboxBrowserScreen
import com.linkshield.sandbox.ui.grabber.LinkShieldGrabberScreen
import com.linkshield.sandbox.ui.upgrade.UpgradeScreen
import com.linkshield.sandbox.vpn.WireGuardVpnManager
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import java.net.URLEncoder

private enum class MainTab(val label: String) {
    BROWSE("Shield"),
    GRAB("Grabber"),
    UPGRADE("Upgrade")
}

@Composable
fun UnblockShieldScreen(
    initialUrl: String = "",
    isDarkTheme: Boolean = true,
    onThemeToggle: (Boolean) -> Unit = {}
) {
    val context = LocalContext.current
    val scope   = rememberCoroutineScope()

    val licenseManager = remember { LicenseManager(context.applicationContext) }

    // Pro state — mutable so it refreshes after key activation
    var isProUser by remember { mutableStateOf(licenseManager.isProUser()) }
    var trialDays by remember { mutableIntStateOf(licenseManager.getTrialDaysRemaining()) }

    // Poll every 3s — badge updates within 3s of key activation
    LaunchedEffect(Unit) {
        while (true) {
            delay(3000)
            val newPro = licenseManager.isProUser()
            if (newPro != isProUser) {
                isProUser = newPro
                trialDays = licenseManager.getTrialDaysRemaining()
            }
        }
    }

    // Refresh on tab switch too
    var selectedTab by rememberSaveable { mutableStateOf(MainTab.BROWSE.name) }
    LaunchedEffect(selectedTab) {
        isProUser = licenseManager.isProUser()
        trialDays = licenseManager.getTrialDaysRemaining()
    }

    val wireGuardManager = remember { WireGuardVpnManager(context.applicationContext) }
    var isWireGuardConnected by remember { mutableStateOf(wireGuardManager.isConnected()) }

    val vpnPermissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.StartActivityForResult()
    ) { result ->
        if (result.resultCode == Activity.RESULT_OK) {
            scope.launch {
                val res = wireGuardManager.connect()
                isWireGuardConnected = res.isSuccess
                if (res.isFailure) {
                    Toast.makeText(
                        context,
                        res.exceptionOrNull()?.message ?: "Connection failed",
                        Toast.LENGTH_SHORT
                    ).show()
                }
            }
        } else {
            isWireGuardConnected = false
        }
    }

    var url by rememberSaveable {
        mutableStateOf(normalizeUrl(initialUrl).ifBlank { "https://www.google.com" })
    }
    var browserUrl  by rememberSaveable { mutableStateOf(url) }
    val isAdGuardActive = true
    var canBack     by remember { mutableStateOf(false) }
    var canForward  by remember { mutableStateOf(false) }
    var isLoading   by remember { mutableStateOf(false) }
    var webView     by remember { mutableStateOf<WebView?>(null) }
    var webViewGeneration by remember { mutableIntStateOf(0) }

    val tab = try { MainTab.valueOf(selectedTab) } catch (e: Exception) { MainTab.BROWSE }

    BackHandler {
        when {
            tab == MainTab.BROWSE && canBack -> webView?.goBack()
            tab != MainTab.BROWSE            -> selectedTab = MainTab.BROWSE.name
            else                             -> (context as? Activity)?.finish()
        }
    }

    Scaffold(
        contentWindowInsets = WindowInsets(0),
        bottomBar = {
            NavigationBar {
                MainTab.values().forEach { item ->
                    NavigationBarItem(
                        selected = tab == item,
                        onClick  = { selectedTab = item.name },
                        icon = {
                            Icon(
                                imageVector = when (item) {
                                    MainTab.BROWSE  -> Icons.Default.Public
                                    MainTab.GRAB    -> Icons.Default.Download
                                    MainTab.UPGRADE -> Icons.Default.Star
                                },
                                contentDescription = item.label
                            )
                        },
                        label    = { Text(item.label) },
                        modifier = Modifier.weight(1f)
                    )
                }
            }
        }
    ) { padding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
        ) {
            when (tab) {
                MainTab.BROWSE -> {
                    SandboxBrowserScreen(
                        generation              = webViewGeneration,
                        startUrl                = browserUrl,
                        currentUrl              = url,
                        onUrlChange             = { url = it },
                        isShieldProtectionEnabled = isAdGuardActive,
                        onShieldProtectionToggle  = {},
                        isWireGuardEnabled      = isWireGuardConnected,
                        onWireGuardToggle       = {
                            scope.launch {
                                if (wireGuardManager.isConnected()) {
                                    val res = wireGuardManager.disconnect()
                                    if (res.isSuccess) isWireGuardConnected = false
                                } else {
                                    // Config is hardcoded — no missing config possible
                                    val prepareIntent = VpnService.prepare(context)
                                    if (prepareIntent != null) {
                                        vpnPermissionLauncher.launch(prepareIntent)
                                    } else {
                                        val res = wireGuardManager.connect()
                                        isWireGuardConnected = res.isSuccess
                                        if (res.isFailure) {
                                            Toast.makeText(
                                                context,
                                                res.exceptionOrNull()?.message ?: "Connection failed",
                                                Toast.LENGTH_SHORT
                                            ).show()
                                        }
                                    }
                                }
                            }
                        },
                        trialDaysLeft           = trialDays,
                        isProUser               = isProUser,
                        isDarkTheme             = isDarkTheme,
                        onThemeToggle           = onThemeToggle,
                        canGoBack               = canBack,
                        canGoForward            = canForward,
                        onBack                  = { webView?.goBack() },
                        onForward               = { webView?.goForward() },
                        onReload                = { webView?.reload() },
                        onNavigate              = {
                            val target = normalizeUrl(url)
                            if (target.isNotBlank()) {
                                url      = target
                                browserUrl = target
                                webView?.loadUrl(target)
                            }
                        },
                        isLoading               = isLoading,
                        onReady                 = { webView = it },
                        onUrlChanged            = { browserUrl = it; url = it },
                        onLoading               = { isLoading = it },
                        onNavigation            = { back, forward -> canBack = back; canForward = forward },
                        onRendererGone          = { webView = null; webViewGeneration++ }
                    )
                }

                MainTab.GRAB -> {
                    // No runCatching — per UI_FREEZE_CONTRACT Rule 2
                    // initialUrl passes current browser URL for auto-fill
                    LinkShieldGrabberScreen(
                        onBackToBrowser = { selectedTab = MainTab.BROWSE.name },
                        onUpgradeClick  = { selectedTab = MainTab.UPGRADE.name },
                        isProUser       = isProUser,
                        trialDaysLeft   = trialDays
                    )
                }

                MainTab.UPGRADE -> {
                    // No runCatching — per UI_FREEZE_CONTRACT Rule 2
                    UpgradeScreen(
                        licenseManager = licenseManager,
                        modifier       = Modifier.fillMaxSize()
                    )
                }
            }
        }
    }
}

private fun normalizeUrl(value: String): String {
    val trimmed = value.trim()
    if (trimmed.isBlank()) return ""
    val hasProtocol  = trimmed.startsWith("http://", true) || trimmed.startsWith("https://", true)
    val hasDomainDot = trimmed.contains(".") && !trimmed.contains(" ")
    return when {
        hasProtocol  -> trimmed
        hasDomainDot -> "https://$trimmed"
        else -> "https://www.google.com/search?q=${URLEncoder.encode(trimmed, "UTF-8")}"
    }
}
