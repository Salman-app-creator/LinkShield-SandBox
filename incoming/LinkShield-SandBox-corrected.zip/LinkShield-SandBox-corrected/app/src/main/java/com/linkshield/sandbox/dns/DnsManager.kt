package com.linkshield.sandbox.dns

import android.content.Context
import android.content.SharedPreferences
import android.util.Log
import okhttp3.Dns
import okhttp3.HttpUrl.Companion.toHttpUrl
import okhttp3.OkHttpClient
import okhttp3.dnsoverhttps.DnsOverHttps
import java.net.InetAddress
import java.util.concurrent.TimeUnit

private const val TAG = "DnsManager"
private const val PREFS_NAME = "shield_prefs"
private const val KEY_DOH_ENABLED = "doh_enabled"
private const val KEY_PROVIDER = "doh_provider"
private const val KEY_DOWNLOAD_COUNT = "download_count"
private const val KEY_IS_PRO = "is_pro"
private const val KEY_INITIALIZED = "initialized"
private const val FREE_DOWNLOAD_LIMIT = 20

enum class DohProvider(val displayName: String, val url: String, val ips: List<String>) {
    CLOUDFLARE("Cloudflare (1.1.1.1)", "https://cloudflare-dns.com/dns-query", listOf("1.1.1.1", "1.0.0.1")),
    CLOUDFLARE_WARP("Cloudflare WARP", "https://1.1.1.1/dns-query", listOf("1.1.1.1", "1.0.0.1")),
    GOOGLE("Google (8.8.8.8)", "https://dns.google/dns-query", listOf("8.8.8.8", "8.8.4.4")),
    QUAD9("Quad9 (9.9.9.9)", "https://dns.quad9.net/dns-query", listOf("9.9.9.9", "149.112.112.112")),
    ADGUARD("AdGuard", "https://dns.adguard-dns.com/dns-query", listOf("94.140.14.14", "94.140.15.15"))
}

class DnsManager(private val context: Context) {

    private val prefs: SharedPreferences =
        context.applicationContext.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)

    @Volatile private var cachedClient: OkHttpClient? = null

    private val bootstrapClient: OkHttpClient by lazy {
        OkHttpClient.Builder()
            .connectTimeout(10, TimeUnit.SECONDS)
            .readTimeout(10, TimeUnit.SECONDS)
            .build()
    }

    init {
        if (!prefs.getBoolean(KEY_INITIALIZED, false)) {
            prefs.edit()
                .putInt(KEY_DOWNLOAD_COUNT, 0)
                .putBoolean(KEY_INITIALIZED, true)
                .apply()
            Log.d(TAG, "Fresh install — download counter initialised at 0")
        }
    }

    fun getClient(): OkHttpClient = cachedClient ?: synchronized(this) {
        cachedClient ?: buildClient().also { cachedClient = it }
    }

    fun enableDoh(provider: DohProvider = getCurrentProvider()) {
        prefs.edit()
            .putBoolean(KEY_DOH_ENABLED, true)
            .putString(KEY_PROVIDER, provider.name)
            .apply()
        invalidate()
        try {
            getClient()
            Log.d(TAG, "DoH ON: ${provider.displayName}")
        } catch (e: Exception) {
            Log.w(TAG, "Primary DoH failed, trying WARP: ${e.message}")
            prefs.edit().putString(KEY_PROVIDER, DohProvider.CLOUDFLARE_WARP.name).apply()
            invalidate()
            runCatching { getClient() }.onFailure { Log.e(TAG, "WARP fallback also failed: ${it.message}") }
        }
    }

    fun disableDoh() {
        prefs.edit().putBoolean(KEY_DOH_ENABLED, false).apply()
        invalidate()
        Log.d(TAG, "DoH OFF")
    }

    fun isDohEnabled(): Boolean = prefs.getBoolean(KEY_DOH_ENABLED, true)
    fun isShieldPersistedOn(): Boolean = isDohEnabled()

    fun getCurrentProvider(): DohProvider {
        val name = prefs.getString(KEY_PROVIDER, DohProvider.CLOUDFLARE.name)
        return runCatching { DohProvider.valueOf(name!!) }.getOrDefault(DohProvider.CLOUDFLARE)
    }

    fun isProUser(): Boolean = prefs.getBoolean(KEY_IS_PRO, false)
    fun setProUser(pro: Boolean) { prefs.edit().putBoolean(KEY_IS_PRO, pro).apply() }
    fun getDownloadCount(): Int = prefs.getInt(KEY_DOWNLOAD_COUNT, 0)

    fun getRemainingDownloads(): Int =
        if (isProUser()) Int.MAX_VALUE
        else (FREE_DOWNLOAD_LIMIT - getDownloadCount()).coerceAtLeast(0)

    fun canDownload(): Boolean = isProUser() || getDownloadCount() < FREE_DOWNLOAD_LIMIT

    fun consumeDownload(): Boolean {
        if (isProUser()) return true
        val current = getDownloadCount()
        if (current >= FREE_DOWNLOAD_LIMIT) return false
        prefs.edit().putInt(KEY_DOWNLOAD_COUNT, current + 1).apply()
        Log.d(TAG, "Download consumed: ${current + 1}/$FREE_DOWNLOAD_LIMIT")
        return true
    }

    fun resetDownloadCount() { prefs.edit().putInt(KEY_DOWNLOAD_COUNT, 0).apply() }

    private fun invalidate() { synchronized(this) { cachedClient = null } }

    private fun buildClient(): OkHttpClient {
        val builder = OkHttpClient.Builder()
            .connectTimeout(15, TimeUnit.SECONDS)
            .readTimeout(30, TimeUnit.SECONDS)
            .writeTimeout(30, TimeUnit.SECONDS)
            .followRedirects(true)
            .followSslRedirects(true)
            .retryOnConnectionFailure(true)

        if (isDohEnabled()) {
            // Keep TLS completely standard. The previous custom ClientHello
            // fragmentation layer could break otherwise-valid HTTPS sites.
            builder.dns(buildDohDns(getCurrentProvider()))
        }
        return builder.build()
    }

    private fun buildDohDns(provider: DohProvider): Dns {
        val ips = provider.ips.mapNotNull {
            runCatching { InetAddress.getByName(it) }.getOrNull()
        }
        return DnsOverHttps.Builder()
            .client(bootstrapClient)
            .url(provider.url.toHttpUrl())
            .bootstrapDnsHosts(ips)
            .includeIPv6(false)
            .post(true)
            .build()
    }

}
