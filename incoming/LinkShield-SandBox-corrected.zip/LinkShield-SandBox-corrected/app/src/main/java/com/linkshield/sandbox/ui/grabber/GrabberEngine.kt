package com.linkshield.sandbox.ui.grabber

import android.content.Context
import android.os.Environment
import android.util.Log
import com.yausername.ffmpeg.FFmpeg
import com.yausername.youtubedl_android.YoutubeDL.UpdateChannel
import com.yausername.youtubedl_android.YoutubeDL
import com.yausername.youtubedl_android.YoutubeDLRequest
import com.yausername.youtubedl_android.mapper.VideoInfo
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.withContext
import java.io.File

private const val TAG = "GrabberEngine"

data class MediaMetadata(
    val title: String,
    val thumbnailUrl: String?,
    val durationSeconds: Long,
    val uploader: String,
    val formats: List<MediaFormat>
)

data class MediaFormat(
    val id: String,
    val label: String,
    val ext: String,
    val isAudioOnly: Boolean,
    val requiresMerge: Boolean
)

sealed class DownloadState {
    data object Idle : DownloadState()
    data class Fetching(val url: String) : DownloadState()
    data class Progress(val percent: Float, val eta: String, val speed: String) : DownloadState()
    data class Success(val file: File) : DownloadState()
    data class Error(val message: String) : DownloadState()
}

object GrabberEngine {

    private val _downloadState = MutableStateFlow<DownloadState>(DownloadState.Idle)
    val downloadState = _downloadState.asStateFlow()

    @Volatile private var initialized = false

    fun init(context: Context) {
        if (initialized) return
        synchronized(this) {
            if (initialized) return
            runCatching {
                YoutubeDL.getInstance().init(context.applicationContext)
                FFmpeg.getInstance().init(context.applicationContext)
                initialized = true
                Log.i(TAG, "yt-dlp + FFmpeg initialized")
            }.onFailure {
                Log.e(TAG, "Grabber initialization failed", it)
            }
        }
    }

    suspend fun updateExtractor(context: Context): Result<String> = withContext(Dispatchers.IO) {
        runCatching {
            init(context)
            val status = YoutubeDL.getInstance().updateYoutubeDL(context.applicationContext, UpdateChannel.STABLE)
            val message = "yt-dlp update: $status"
            Log.i(TAG, message)
            message
        }
    }

    suspend fun fetchMetadata(context: Context, url: String): Result<MediaMetadata> = withContext(Dispatchers.IO) {
        if (url.isBlank()) return@withContext Result.failure(IllegalArgumentException("URL must not be empty"))
        init(context)
        _downloadState.value = DownloadState.Fetching(url)

        runCatching {
            val info: VideoInfo = YoutubeDL.getInstance().getInfo(
                YoutubeDLRequest(normalizeInputUrl(url)).apply {
                    addOption("--no-playlist")
                    addOption("--socket-timeout", "30")
                    addOption("--no-warnings")
                }
            )

            MediaMetadata(
                title = info.title?.trim().orEmpty().ifBlank { "Untitled media" },
                thumbnailUrl = info.thumbnail,
                durationSeconds = info.duration?.toLong() ?: 0L,
                uploader = info.uploader?.trim().orEmpty(),
                formats = buildFormatList(info)
            ).also { _downloadState.value = DownloadState.Idle }
        }.onFailure { error ->
            val message = mapError(error)
            _downloadState.value = DownloadState.Error(message)
            Log.e(TAG, "Metadata fetch failed: $message", error)
        }
    }

    fun download(
        context: Context,
        url: String,
        format: MediaFormat,
        outputDir: File = defaultOutputDir()
    ): Flow<DownloadState> = flow {
        if (url.isBlank()) {
            emit(DownloadState.Error("URL is empty"))
            return@flow
        }

        init(context)
        outputDir.mkdirs()
        val before = outputDir.listFiles()?.associateBy { it.absolutePath } ?: emptyMap()
        emit(DownloadState.Progress(0f, "", ""))

        val result = withContext(Dispatchers.IO) {
            runCatching {
                val request = YoutubeDLRequest(normalizeInputUrl(url)).apply {
                    addOption("--no-playlist")
                    addOption("--socket-timeout", "60")
                    addOption("--retries", "3")
                    addOption("--fragment-retries", "3")
                    addOption("--newline")
                    addOption("-o", File(outputDir, "%(title)s.%(ext)s").absolutePath)

                    if (format.isAudioOnly) {
                        addOption("-x")
                        addOption("--audio-format", "mp3")
                        addOption("--audio-quality", "0")
                    } else {
                        val h = heightFor(format.label)
                        addOption("-f", "bestvideo[height<=${h}]+bestaudio/best[height<=${h}]/best")
                        addOption("--merge-output-format", "mp4")
                    }
                }

                YoutubeDL.getInstance().execute(request) { progress, eta, _ ->
                    val state = DownloadState.Progress(
                        percent = progress.coerceIn(0f, 100f),
                        eta = if (eta > 0) "${eta}s" else "",
                        speed = ""
                    )
                    _downloadState.value = state
                }

                val file = outputDir.listFiles()
                    ?.filter { it.isFile && !before.containsKey(it.absolutePath) }
                    ?.maxByOrNull { it.lastModified() }
                    ?: outputDir.listFiles()
                        ?.filter { it.isFile }
                        ?.maxByOrNull { it.lastModified() }
                    ?: throw IllegalStateException("Downloaded file was not created")

                file
            }
        }

        result.fold(
            onSuccess = { file ->
                val state = DownloadState.Success(file)
                _downloadState.value = state
                emit(state)
            },
            onFailure = { error ->
                val message = mapError(error)
                val state = DownloadState.Error(message)
                _downloadState.value = state
                emit(state)
                Log.e(TAG, "Download failed: $message", error)
            }
        )
    }

    fun resetState() { _downloadState.value = DownloadState.Idle }

    private fun buildFormatList(info: VideoInfo): List<MediaFormat> {
        val heights = info.formats?.mapNotNull { it.height?.toInt() }?.toSet().orEmpty()
        val result = mutableListOf(
            MediaFormat("mp3", "MP3", "mp3", true, false)
        )

        for (height in listOf(360, 480, 720, 1080, 2160)) {
            if (heights.isEmpty() || heights.any { it >= height }) {
                result += MediaFormat(
                    id = "v$height",
                    label = if (height == 2160) "4K" else "${height}p",
                    ext = "mp4",
                    isAudioOnly = false,
                    requiresMerge = true
                )
            }
        }
        return result
    }

    private fun heightFor(label: String): Int = when (label) {
        "4K" -> 2160
        "1080p" -> 1080
        "720p" -> 720
        "480p" -> 480
        else -> 360
    }

    private fun defaultOutputDir(): File =
        File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS), "LinkShield")

    private fun normalizeInputUrl(value: String): String {
        val trimmed = value.trim()
        return if (trimmed.startsWith("http://", true) || trimmed.startsWith("https://", true)) {
            trimmed
        } else {
            "https://$trimmed"
        }
    }

    private fun mapError(error: Throwable): String {
        val message = error.message.orEmpty()
        return when {
            error is java.net.UnknownHostException -> "No internet connection. Check your network."
            error is java.net.SocketTimeoutException -> "Connection timed out. Try again."
            message.contains("Private video", true) || message.contains("login", true) ->
                "This media is private or requires login."
            message.contains("not available", true) ->
                "This media is not available in your region."
            message.contains("429", true) ->
                "Too many requests. Please wait a moment and try again."
            message.contains("HTTP Error 403", true) || message.contains("Forbidden", true) ->
                "The platform denied access to this media."
            message.isBlank() -> "Download failed. Try another URL."
            else -> message.replace(Regex("\s+"), " ").take(180)
        }
    }
}
