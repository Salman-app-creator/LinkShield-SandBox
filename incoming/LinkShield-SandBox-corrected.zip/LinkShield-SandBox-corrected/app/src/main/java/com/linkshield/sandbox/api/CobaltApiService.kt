package com.linkshield.sandbox.api

import android.app.DownloadManager
import android.content.Context
import android.net.Uri
import android.os.Environment
import com.linkshield.sandbox.BuildConfig
import com.linkshield.sandbox.dns.DnsManager
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONObject
import java.io.IOException
import java.util.concurrent.TimeUnit

/** Optional Cobalt v10+ client. The main Grabber path uses yt-dlp directly. */
class CobaltApiService(context: Context, dnsManager: DnsManager) {
    private val client = dnsManager.getClient().newBuilder()
        .connectTimeout(30, TimeUnit.SECONDS)
        .readTimeout(120, TimeUnit.SECONDS)
        .build()

    private val downloadManager =
        context.getSystemService(Context.DOWNLOAD_SERVICE) as DownloadManager

    companion object {
        private val JSON = "application/json".toMediaType()
        val API_BASE: String
            get() = BuildConfig.COBALT_API_BASE.trim().trimEnd('/')
    }

    data class MediaResult(
        val success: Boolean,
        val url: String? = null,
        val filename: String? = null,
        val mimeType: String? = null,
        val error: String? = null,
        val isDirectDownload: Boolean = false
    )

    suspend fun fetchMediaUrl(
        pageUrl: String,
        downloadMode: String = "auto",
        videoQuality: String = "720"
    ): MediaResult = withContext(Dispatchers.IO) {
        if (API_BASE.isBlank()) {
            return@withContext MediaResult(
                false,
                error = "Cobalt is not configured. LinkShield uses the built-in yt-dlp engine instead."
            )
        }

        try {
            val body = JSONObject().apply {
                put("url", pageUrl.trim())
                put("videoQuality", videoQuality)
                put("audioFormat", "mp3")
                put("downloadMode", downloadMode)
                put("youtubeVideoCodec", "h264")
                put("disableMetadata", false)
                put("twitterGif", true)
            }

            val request = Request.Builder()
                .url(API_BASE)
                .addHeader("Accept", "application/json")
                .addHeader("Content-Type", "application/json")
                .addHeader("User-Agent", "LinkShieldSandbox/2.2")
                .post(body.toString().toRequestBody(JSON))
                .build()

            client.newCall(request).execute().use { response ->
                val responseBody = response.body?.string().orEmpty()
                if (!response.isSuccessful || responseBody.isBlank()) {
                    return@withContext MediaResult(false, error = "Cobalt API HTTP ${response.code}")
                }

                val json = JSONObject(responseBody)
                when (json.optString("status")) {
                    "redirect", "tunnel" -> {
                        val url = json.optString("url")
                        if (url.isBlank()) {
                            MediaResult(false, error = "Cobalt returned no download URL")
                        } else {
                            val filename = json.optString("filename").ifBlank { "LinkShield_download" }
                            MediaResult(
                                success = true,
                                url = url,
                                filename = filename,
                                mimeType = mimeFromFilename(filename, url),
                                isDirectDownload = json.optString("status") == "redirect"
                            )
                        }
                    }
                    "picker" -> {
                        val first = json.optJSONArray("picker")?.optJSONObject(0)
                        val url = first?.optString("url").orEmpty()
                        if (url.isBlank()) {
                            MediaResult(false, error = "Cobalt returned no selectable media")
                        } else {
                            MediaResult(true, url = url, filename = "LinkShield_media", mimeType = "video/mp4")
                        }
                    }
                    "local-processing" -> {
                        val url = json.optJSONArray("tunnel")?.optString(0).orEmpty()
                        val output = json.optJSONObject("output")
                        val filename = output?.optString("filename").orEmpty().ifBlank { "LinkShield_download" }
                        val mime = output?.optString("type").orEmpty().ifBlank { mimeFromFilename(filename, url) }
                        if (url.isBlank()) MediaResult(false, error = "Cobalt returned no processing tunnel")
                        else MediaResult(true, url = url, filename = filename, mimeType = mime)
                    }
                    "error" -> {
                        val error = json.optJSONObject("error")
                        val code = error?.optString("code").orEmpty().ifBlank { "unknown" }
                        MediaResult(false, error = "Cobalt: $code")
                    }
                    else -> MediaResult(false, error = "Unexpected Cobalt response")
                }
            }
        } catch (e: IOException) {
            MediaResult(false, error = "Cobalt network error: ${e.message}")
        } catch (e: Exception) {
            MediaResult(false, error = "Cobalt error: ${e.message}")
        }
    }

    fun startDownload(url: String, filename: String, mimeType: String = "video/mp4"): Long {
        val safeName = filename.ifBlank { "LinkShield_download" }
            .replace(Regex("[\\\\/:*?\"<>|]"), "_")
        val request = DownloadManager.Request(Uri.parse(url))
            .setTitle(safeName)
            .setDescription("Downloading via LinkShield")
            .setMimeType(mimeType)
            .setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED)
            .setDestinationInExternalPublicDir(Environment.DIRECTORY_DOWNLOADS, "LinkShield/$safeName")
            .setAllowedOverMetered(true)
            .setAllowedOverRoaming(true)
        return downloadManager.enqueue(request)
    }

    private fun mimeFromFilename(filename: String, url: String): String {
        val value = (filename + " " + url).lowercase()
        return when {
            ".mp3" in value -> "audio/mpeg"
            ".m4a" in value -> "audio/mp4"
            ".aac" in value -> "audio/aac"
            ".ogg" in value -> "audio/ogg"
            ".webm" in value -> "video/webm"
            ".m3u8" in value -> "application/vnd.apple.mpegurl"
            ".mpd" in value -> "application/dash+xml"
            else -> "video/mp4"
        }
    }
}
