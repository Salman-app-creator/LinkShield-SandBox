package com.linkshield.sandbox.vpn

import android.content.Context
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

class WireGuardVpnRepository(
    context: Context
) {

    private val configRepository = WireGuardConfigRepository(context)

    suspend fun saveConfig(configText: String): Result<Unit> =
        withContext(Dispatchers.IO) {
            WireGuardConfigValidator.validate(configText).map {
                configRepository.save(configText.trim())
            }
        }

    suspend fun loadConfig(): Result<String> = withContext(Dispatchers.IO) {
        val stored = configRepository.load()
        if (!stored.isNullOrBlank()) {
            return@withContext WireGuardConfigValidator.validate(stored).fold(
                onSuccess = { Result.success(stored) },
                onFailure = { Result.failure(it) }
            )
        }

        // No private key is shipped in the APK. The user must import or save
        // their own WireGuard client configuration before connecting.
        Result.failure(IllegalStateException("WireGuard configuration not installed"))
    }

    fun hasConfig(): Boolean = configRepository.exists()

    suspend fun deleteConfig() = withContext(Dispatchers.IO) {
        configRepository.delete()
    }
}
