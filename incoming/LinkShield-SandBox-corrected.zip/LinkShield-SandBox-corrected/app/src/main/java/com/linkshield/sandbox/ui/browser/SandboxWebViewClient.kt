package com.linkshield.sandbox.ui.browser

import android.graphics.Bitmap
import android.net.http.SslError
import android.webkit.SslErrorHandler
import android.webkit.WebResourceError
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebView
import android.webkit.WebViewClient
import com.linkshield.sandbox.adblock.AdBlockEngine
import com.linkshield.sandbox.ui.grabber.MediaSnifferState
import java.io.ByteArrayInputStream
import java.util.Locale

class SandboxWebViewClient(
    private val shieldEnabled: Boolean = true,
    private val onPageChanged: ((String) -> Unit)? = null,
    private val onLoadingChanged: ((Boolean) -> Unit)? = null,
    private val onNavigationChanged: ((Boolean, Boolean) -> Unit)? = null,
    private val onPageError: ((String) -> Unit)? = null,
    private val onRendererGone: (() -> Unit)? = null
) : WebViewClient() {

    private val blockedDomains = setOf(
        "doubleclick.net",
        "googleadservices.com",
        "googlesyndication.com",
        "adservice.google.com",
        "pagead2.googlesyndication.com",
        "ad.doubleclick.net",
        "g.doubleclick.net",
        "stats.g.doubleclick.net",
        "cm.g.doubleclick.net",
        "tpc.googlesyndication.com",
        "googletagmanager.com",
        "googletagservices.com",
        "google-analytics.com",
        "adnxs.com",
        "appnexus.com",
        "adsrvr.org",
        "rubiconproject.com",
        "pubmatic.com",
        "openx.net",
        "casalemedia.com",
        "criteo.com",
        "taboola.com",
        "outbrain.com"
    )

    override fun shouldOverrideUrlLoading(
        view: WebView,
        request: WebResourceRequest
    ): Boolean {
        val scheme = request.url.scheme?.lowercase(Locale.US)
        return scheme != null && scheme !in setOf("http", "https")
    }

    @Deprecated("Deprecated in Java")
    override fun shouldOverrideUrlLoading(view: WebView, url: String): Boolean {
        val scheme = runCatching { android.net.Uri.parse(url).scheme?.lowercase(Locale.US) }.getOrNull()
        return scheme != null && scheme !in setOf("http", "https")
    }

    override fun onPageStarted(view: WebView, url: String, favicon: Bitmap?) {
        super.onPageStarted(view, url, favicon)
        onLoadingChanged?.invoke(true)
        onPageChanged?.invoke(url)
    }

    override fun onPageFinished(view: WebView, url: String) {
        super.onPageFinished(view, url)
        onLoadingChanged?.invoke(false)
        onPageChanged?.invoke(view.url ?: url)
        onNavigationChanged?.invoke(view.canGoBack(), view.canGoForward())
    }

    override fun onReceivedError(
        view: WebView,
        request: WebResourceRequest,
        error: WebResourceError
    ) {
        super.onReceivedError(view, request, error)
        if (request.isForMainFrame) {
            onLoadingChanged?.invoke(false)
            onPageError?.invoke(error.description?.toString().orEmpty().ifBlank { "Unable to load this page" })
        }
    }

    @Deprecated("Deprecated in Java")
    override fun onReceivedError(
        view: WebView,
        errorCode: Int,
        description: String,
        failingUrl: String
    ) {
        super.onReceivedError(view, errorCode, description, failingUrl)
        onLoadingChanged?.invoke(false)
        onPageError?.invoke(description.ifBlank { "Unable to load this page" })
    }

    override fun onReceivedSslError(view: WebView, handler: SslErrorHandler, error: SslError) {
        // Never bypass certificate errors. Cancel keeps the sandbox browser secure.
        handler.cancel()
        onLoadingChanged?.invoke(false)
        onPageError?.invoke("Secure connection could not be verified")
    }

    override fun onRenderProcessGone(view: WebView, detail: android.webkit.RenderProcessGoneDetail): Boolean {
        onLoadingChanged?.invoke(false)
        runCatching { view.destroy() }
        SandboxWebViewSession.destroy()
        onRendererGone?.invoke()
        return true
    }

    override fun shouldInterceptRequest(
        view: WebView,
        request: WebResourceRequest
    ): WebResourceResponse? {
        val url = request.url.toString()

        if (shieldEnabled && isAdOrTracker(url)) {
            return emptyBlockedResponse()
        }

        inspectResource(url, request.requestHeaders["Content-Type"])
        return super.shouldInterceptRequest(view, request)
    }

    @Deprecated("Deprecated in Java")
    override fun shouldInterceptRequest(view: WebView, url: String): WebResourceResponse? {
        if (shieldEnabled && isAdOrTracker(url)) {
            return emptyBlockedResponse()
        }
        inspectResource(url, null)
        return super.shouldInterceptRequest(view, url)
    }

    private fun emptyBlockedResponse(): WebResourceResponse = WebResourceResponse(
        "text/plain",
        "utf-8",
        204,
        "No Content",
        emptyMap(),
        ByteArrayInputStream(ByteArray(0))
    )

    private fun isAdOrTracker(url: String): Boolean {
        if (url.isBlank()) return false
        val lower = url.lowercase(Locale.US)

        if (AdBlockEngine.getInstance().shouldBlock(url)) return true
        if (blockedDomains.any { lower.contains(it) }) return true

        if (lower.contains("youtube.com")) {
            val youtubeAdPatterns = listOf(
                "/pagead/",
                "/api/stats/ads",
                "/ptracking",
                "/youtubei/v1/log_event",
                "/youtubei/v1/feedback"
            )
            if (youtubeAdPatterns.any(lower::contains)) return true
        }

        if (lower.contains("googlevideo.com")) {
            val adParameters = listOf("adformat=", "oad=", "afs=", "ad_type=", "adunit=")
            if (adParameters.any(lower::contains)) return true
        }

        return false
    }

    private fun inspectResource(url: String, contentType: String?) {
        if (url.isBlank()) return
        val lowerUrl = url.lowercase(Locale.US)
        val lowerType = contentType?.lowercase(Locale.US).orEmpty()

        val media = lowerType.startsWith("video/") ||
            lowerType.startsWith("audio/") ||
            MEDIA_EXTENSIONS.any {
                lowerUrl.substringBefore("?").substringBefore("#").endsWith(it)
            } ||
            lowerUrl.contains(".m3u8") ||
            lowerUrl.contains(".mpd") ||
            lowerUrl.startsWith("blob:")

        if (!media) return

        MediaSnifferState.publish(
            url = url,
            mimeType = contentType.orEmpty(),
            extension = detectExtension(lowerUrl)
        )
    }

    private fun detectExtension(url: String): String {
        val clean = url.substringBefore("?").substringBefore("#")
        return clean.substringAfterLast('.', "").take(10)
    }

    companion object {
        private val MEDIA_EXTENSIONS = setOf(
            ".mp4", ".webm", ".mkv", ".mov", ".mp3", ".m4a", ".aac", ".ogg", ".wav"
        )
    }
}

fun createSandboxWebViewClient(
    shieldEnabled: Boolean = true,
    onPageChanged: ((String) -> Unit)? = null,
    onLoadingChanged: ((Boolean) -> Unit)? = null,
    onNavigationChanged: ((Boolean, Boolean) -> Unit)? = null,
    onPageError: ((String) -> Unit)? = null,
    onRendererGone: (() -> Unit)? = null
): SandboxWebViewClient = SandboxWebViewClient(
    shieldEnabled = shieldEnabled,
    onPageChanged = onPageChanged,
    onLoadingChanged = onLoadingChanged,
    onNavigationChanged = onNavigationChanged,
    onPageError = onPageError,
    onRendererGone = onRendererGone
)
