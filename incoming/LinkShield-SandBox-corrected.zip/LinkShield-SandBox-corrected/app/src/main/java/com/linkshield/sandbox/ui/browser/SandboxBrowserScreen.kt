package com.linkshield.sandbox.ui.browser

import android.graphics.Color
import android.os.Build
import android.view.ViewGroup
import android.webkit.CookieManager
import android.webkit.WebChromeClient
import android.webkit.WebSettings
import android.webkit.WebView
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.runtime.Composable
import androidx.compose.runtime.key
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.viewinterop.AndroidView
import com.linkshield.sandbox.ui.components.TopHeader

@Composable
fun SandboxBrowserScreen(
    generation: Int,
    startUrl: String,
    currentUrl: String,
    onUrlChange: (String) -> Unit,
    isShieldProtectionEnabled: Boolean,
    onShieldProtectionToggle: () -> Unit,
    isWireGuardEnabled: Boolean,
    onWireGuardToggle: () -> Unit,
    onWireGuardConfigImport: () -> Unit = {},
    trialDaysLeft: Int,
    isProUser: Boolean = false,
    isDarkTheme: Boolean,
    onThemeToggle: (Boolean) -> Unit,
    canGoBack: Boolean,
    canGoForward: Boolean,
    onBack: () -> Unit,
    onForward: () -> Unit,
    onReload: () -> Unit,
    onNavigate: () -> Unit,
    isLoading: Boolean,
    onReady: (WebView) -> Unit,
    onUrlChanged: (String) -> Unit,
    onLoading: (Boolean) -> Unit,
    onNavigation: (Boolean, Boolean) -> Unit,
    onRendererGone: () -> Unit
) {
    val webViewState = remember { mutableStateOf<WebView?>(null) }

    key(generation) {
        Column(modifier = Modifier.fillMaxSize()) {
            TopHeader(
                currentUrl = currentUrl,
                onUrlChange = onUrlChange,
                isShieldProtectionEnabled = isShieldProtectionEnabled,
                onShieldProtectionToggle = onShieldProtectionToggle,
                isWireGuardEnabled = isWireGuardEnabled,
                onWireGuardToggle = onWireGuardToggle,
                onWireGuardConfigImport = onWireGuardConfigImport,
                trialDaysLeft = trialDaysLeft,
                isProUser = isProUser,
                isDarkTheme = isDarkTheme,
                onThemeToggle = onThemeToggle,
                canGoBack = canGoBack,
                canGoForward = canGoForward,
                onBack = onBack,
                onForward = onForward,
                onReload = onReload,
                onNavigate = onNavigate,
                isLoading = isLoading
            )

            AndroidView(
                modifier = Modifier.weight(1f).fillMaxWidth(),
                factory = { ctx ->
                    SandboxWebViewSession.get()?.also { existing ->
                        webViewState.value = existing
                        onReady(existing)
                        if (startUrl.isNotBlank() && existing.url != startUrl) {
                            existing.loadUrl(startUrl)
                        }
                    } ?: WebView(ctx).apply {
                        setBackgroundColor(
                            if (isDarkTheme) Color.parseColor("#FF0A0F14")
                            else Color.parseColor("#FFF0F2F5")
                        )

                        layoutParams = ViewGroup.LayoutParams(
                            ViewGroup.LayoutParams.MATCH_PARENT,
                            ViewGroup.LayoutParams.MATCH_PARENT
                        )

                        settings.apply {
                            javaScriptEnabled = true
                            domStorageEnabled = true
                            databaseEnabled = true
                            mediaPlaybackRequiresUserGesture = false
                            useWideViewPort = true
                            loadWithOverviewMode = false
                            cacheMode = WebSettings.LOAD_DEFAULT
                            allowFileAccess = false
                            allowContentAccess = true
                            mixedContentMode = WebSettings.MIXED_CONTENT_NEVER_ALLOW
                            javaScriptCanOpenWindowsAutomatically = false
                            setSupportMultipleWindows(false)
                            builtInZoomControls = false
                            displayZoomControls = false
                            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                                safeBrowsingEnabled = true
                            }
                        }

                        CookieManager.getInstance().setAcceptCookie(true)
                        CookieManager.getInstance().setAcceptThirdPartyCookies(this, true)
                        WebView.setNetworkAvailable(true)

                        webViewClient = createSandboxWebViewClient(
                            shieldEnabled = isShieldProtectionEnabled,
                            onPageChanged = { onUrlChanged(it) },
                            onLoadingChanged = { onLoading(it) },
                            onNavigationChanged = { back, forward -> onNavigation(back, forward) },
                            onPageError = { message ->
                                onLoading(false)
                                // Keep the current URL visible; the caller can reload.
                                onUrlChanged(webViewState.value?.url.orEmpty())
                            },
                            onRendererGone = {
                                webViewState.value = null
                                onRendererGone()
                            }
                        )

                        webChromeClient = object : WebChromeClient() {
                            override fun onProgressChanged(view: WebView?, newProgress: Int) {
                                // Loading state is driven by page callbacks; this avoids flicker.
                                super.onProgressChanged(view, newProgress)
                            }
                        }

                        webViewState.value = this
                        SandboxWebViewSession.attach(this)
                        onReady(this)

                        if (startUrl.isNotBlank()) loadUrl(startUrl)
                    }
                },
                update = { webView ->
                    webViewState.value = webView
                    onReady(webView)
                }
            )
        }
    }
}
