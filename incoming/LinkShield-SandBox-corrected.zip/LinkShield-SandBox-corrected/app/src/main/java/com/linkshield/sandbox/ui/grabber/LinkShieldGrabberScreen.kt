package com.linkshield.sandbox.ui.grabber

import android.widget.Toast
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Download
import androidx.compose.material.icons.filled.PlayCircle
import androidx.compose.material.icons.filled.Upgrade
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.linkshield.sandbox.dns.DnsManager
import kotlinx.coroutines.launch

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun LinkShieldGrabberScreen(
    onBackToBrowser: () -> Unit,
    onUpgradeClick: () -> Unit,
    isProUser: Boolean = false,
    trialDaysLeft: Int = 7
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val dnsManager = remember { DnsManager(context.applicationContext) }

    var inputUrl by rememberSaveable { mutableStateOf("") }
    var audioOnly by rememberSaveable { mutableStateOf(false) }
    var selectedResolution by rememberSaveable { mutableStateOf("1080p") }
    var fetched by rememberSaveable { mutableStateOf(false) }
    var isLoading by rememberSaveable { mutableStateOf(false) }
    var errorMsg by rememberSaveable { mutableStateOf<String?>(null) }
    var mediaTitle by rememberSaveable { mutableStateOf("") }
    var uploader by rememberSaveable { mutableStateOf("") }
    var availableFormats by remember { mutableStateOf<List<MediaFormat>>(emptyList()) }

    val effectivelyPro = isProUser || dnsManager.isProUser()
    val remainingDownloads = if (effectivelyPro) Int.MAX_VALUE else dnsManager.getRemainingDownloads()
    val resolutions = listOf("360p", "480p", "720p", "1080p", "4K")

    Column(
        Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 14.dp, vertical = 10.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = onBackToBrowser, modifier = Modifier.size(40.dp)) {
                Icon(Icons.Default.ArrowBack, "Back to browser")
            }
            Text(
                "Grabber",
                style = MaterialTheme.typography.titleLarge,
                fontWeight = FontWeight.Bold,
                modifier = Modifier.weight(1f)
            )
        }

        Card(
            Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(14.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.tertiaryContainer)
        ) {
            Row(
                Modifier.fillMaxWidth().padding(12.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(Modifier.weight(1f)) {
                    Text(
                        if (effectivelyPro) "PRO • Unlimited downloads" else "${remainingDownloads.coerceAtMost(20)} Free Downloads Remaining",
                        fontWeight = FontWeight.Bold
                    )
                    if (!effectivelyPro) {
                        Text("Trial: $trialDaysLeft days left • Upgrade for unlimited", fontSize = 12.sp)
                    }
                }
                if (!effectivelyPro) {
                    TextButton(onClick = onUpgradeClick) {
                        Icon(Icons.Default.Upgrade, null, Modifier.size(17.dp))
                        Spacer(Modifier.width(3.dp))
                        Text("Upgrade")
                    }
                }
            }
        }

        OutlinedTextField(
            value = inputUrl,
            onValueChange = {
                inputUrl = it
                fetched = false
                errorMsg = null
                mediaTitle = ""
                uploader = ""
                availableFormats = emptyList()
            },
            modifier = Modifier.fillMaxWidth(),
            singleLine = true,
            placeholder = { Text("Paste or Fetch Link...") },
            leadingIcon = { Icon(Icons.Default.PlayCircle, null) },
            trailingIcon = {
                if (inputUrl.isNotEmpty()) {
                    IconButton(onClick = { inputUrl = ""; fetched = false; errorMsg = null }) {
                        Icon(Icons.Default.ArrowBack, "Clear", Modifier.size(18.dp))
                    }
                }
            },
            shape = RoundedCornerShape(12.dp),
            isError = errorMsg != null
        )

        errorMsg?.let {
            Text(it, color = MaterialTheme.colorScheme.error, fontSize = 12.sp)
        }

        Card(
            Modifier.fillMaxWidth().height(180.dp),
            shape = RoundedCornerShape(14.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
        ) {
            Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Icon(Icons.Default.PlayCircle, null, Modifier.size(54.dp), tint = MaterialTheme.colorScheme.primary)
                    Spacer(Modifier.height(8.dp))
                    Text(
                        when {
                            isLoading -> "Fetching media..."
                            fetched -> "Ready to download"
                            else -> "Media Preview Area"
                        },
                        fontWeight = FontWeight.SemiBold
                    )
                    if (fetched && mediaTitle.isNotBlank()) {
                        Text(mediaTitle, fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                    if (fetched && uploader.isNotBlank()) {
                        Text(uploader, fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                }
            }
        }

        Text("Options:", fontWeight = FontWeight.Bold)
        Row(verticalAlignment = Alignment.CenterVertically) {
            Checkbox(checked = audioOnly, onCheckedChange = { audioOnly = it; fetched = false })
            Text("Audio Only (MP3)", fontSize = 13.sp)
        }

        if (!audioOnly) {
            Text("Select Resolution:", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                resolutions.forEach { res ->
                    FilterChip(
                        selected = selectedResolution == res,
                        onClick = { selectedResolution = res; fetched = false },
                        label = { Text(res, fontSize = 12.sp) },
                        shape = RoundedCornerShape(8.dp)
                    )
                }
            }
        }

        if (fetched) {
            Text(
                "Quality: ${if (audioOnly) "MP3 Audio" else "$selectedResolution • MP4"}",
                color = MaterialTheme.colorScheme.primary,
                fontWeight = FontWeight.SemiBold
            )
        }

        Spacer(Modifier.height(4.dp))

        Button(
            onClick = {
                if (!fetched) {
                    if (inputUrl.isBlank()) {
                        errorMsg = "Enter a URL first"
                        return@Button
                    }
                    if (!effectivelyPro && remainingDownloads <= 0) {
                        errorMsg = "Download limit reached. Upgrade to Pro."
                        return@Button
                    }

                    isLoading = true
                    errorMsg = null
                    scope.launch {
                        val result = GrabberEngine.fetchMetadata(context, inputUrl)
                        isLoading = false
                        result.onSuccess { metadata ->
                            mediaTitle = metadata.title
                            uploader = metadata.uploader
                            availableFormats = metadata.formats
                            fetched = true
                        }.onFailure {
                            errorMsg = it.message ?: "Could not fetch this link"
                            fetched = false
                        }
                    }
                } else {
                    if (!effectivelyPro && remainingDownloads <= 0) {
                        errorMsg = "Download limit reached. Upgrade to Pro."
                        return@Button
                    }

                    val format = if (audioOnly) {
                        availableFormats.firstOrNull { it.isAudioOnly }
                    } else {
                        availableFormats.firstOrNull { it.label == selectedResolution }
                            ?: MediaFormat(
                                id = "v$selectedResolution",
                                label = selectedResolution,
                                ext = "mp4",
                                isAudioOnly = false,
                                requiresMerge = true
                            )
                    }

                    if (format == null) {
                        errorMsg = "No compatible media format was returned"
                        return@Button
                    }

                    isLoading = true
                    errorMsg = null
                    scope.launch {
                        GrabberEngine.download(context, inputUrl, format).collect { state ->
                            when (state) {
                                is DownloadState.Progress -> isLoading = true
                                is DownloadState.Success -> {
                                    if (!effectivelyPro) {
                                        dnsManager.consumeDownload()
                                    }
                                    isLoading = false
                                    Toast.makeText(
                                        context,
                                        "Download complete: ${state.file.name}",
                                        Toast.LENGTH_LONG
                                    ).show()
                                    fetched = false
                                    inputUrl = ""
                                }
                                is DownloadState.Error -> {
                                    isLoading = false
                                    errorMsg = state.message
                                }
                                else -> Unit
                            }
                        }
                    }
                }
            },
            enabled = inputUrl.isNotBlank() && !isLoading,
            modifier = Modifier.fillMaxWidth().height(52.dp),
            shape = RoundedCornerShape(12.dp)
        ) {
            Icon(Icons.Default.Download, null)
            Spacer(Modifier.width(8.dp))
            Text(
                when {
                    isLoading -> "Working..."
                    fetched -> "Download"
                    else -> "Fetch Media"
                },
                fontWeight = FontWeight.Bold
            )
        }
    }
}
