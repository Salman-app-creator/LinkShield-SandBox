# LinkShield Sandbox — Audit & Fix Notes

## Fixed in this build

1. **Enable Shield / default-browser button**
   - Uses Android `ROLE_BROWSER` request on Android 10+.
   - Falls back to `Settings.ACTION_MANAGE_DEFAULT_APPS_SETTINGS`.
   - Browser-role status is rechecked on Activity resume instead of a 500 ms polling loop.
   - Removed the duplicate HTTP/HTTPS intent filter from `LinkInterceptorActivity`; only `MainActivity` is now the browser-role candidate.

2. **Main screen spacing**
   - Reduced top header vertical padding.
   - Made the bottom navigation use the system navigation-bar inset explicitly.
   - Avoided adding another navigation-bar inset to the browser content.

3. **Websites / WebView**
   - Main browser now uses the hardened `SandboxWebViewClient` instead of the old raw WebView client.
   - Enables JavaScript, DOM storage and third-party cookies required by modern sites.
   - Keeps mixed-content blocking and SSL-error rejection.
   - Adds main-frame error handling and renderer-crash recovery.
   - Removes the custom TLS ClientHello/SNI fragmentation layer from `DnsManager`, which could break otherwise valid HTTPS connections.
   - Shield blocking is now tied to the actual Shield toggle instead of being permanently forced on.

4. **Grabber / Cobalt**
   - The main downloader no longer depends on Cobalt.
   - Upgraded youtubedl-android from the old 0.14.x line to 0.18.1 from Maven Central.
   - Initializes both yt-dlp and FFmpeg.
   - Uses yt-dlp directly for metadata, video and MP3 downloads.
   - Removed the incorrect `--ffmpeg-location` pointing at a native `.so`; the library itself configures its FFmpeg path.
   - Cobalt remains as an optional client only. Its old `/api/json` style is replaced with the current `POST /` request/response model and a configurable `COBALT_API_BASE`.

5. **WireGuard**
   - Uses the official `com.wireguard.android:tunnel` GoBackend architecture already present in the project.
   - Removed the unused custom VPN service from the app manifest so there is one tunnel lifecycle.
   - Removed the embedded WireGuard private key from the repository.
   - Added import of a user-owned `.conf` file. The config is stored in the app's private files directory.
   - Tapping WireGuard without a config now opens the config importer instead of pretending a hardcoded tunnel is available.

## Important WireGuard requirement

A working WireGuard client needs a real client configuration from your VPN server/provider. The corrected project intentionally does **not** ship a private key.

Import a standard WireGuard `.conf` containing `[Interface]` and `[Peer]` sections. After importing, enable WireGuard from the browser header menu.

## About the supplied Green VPN XAPK

The supplied APK was inspected as a reference. Its native split contains `libhev-socks5-tunnel.so`, and its classes reference a custom VPN service. I did not find WireGuard strings/classes in the inspected APK. So it should not be treated as a WireGuard reference implementation; it is a `VpnService` + HEV SOCKS5 tunnel architecture.

If LinkShield should specifically use **WireGuard**, the official GoBackend approach in this project is the correct direction. If you want to reproduce Green VPN's exact architecture, that is a different job: it would require integrating an HEV SOCKS5 tunnel instead of WireGuard.

## Build note

The uploaded source did not include a usable Gradle wrapper/runtime in the analysis environment, so a full `assembleDebug` build could not be executed here. Kotlin syntax checks were run on the modified source files. Build and install on Android Studio/Gradle should be the final verification step.
