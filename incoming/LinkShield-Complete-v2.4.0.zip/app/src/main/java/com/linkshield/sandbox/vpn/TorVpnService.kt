package com.linkshield.sandbox.vpn

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Intent
import android.net.VpnService
import android.os.Build
import android.os.ParcelFileDescriptor
import android.util.Log
import androidx.core.app.NotificationCompat
import com.linkshield.sandbox.MainActivity
import com.linkshield.sandbox.R
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.launch
import org.torproject.jni.TorService
import java.io.FileInputStream
import java.io.FileOutputStream
import java.io.IOException
import java.net.InetSocketAddress
import java.net.Socket
import java.nio.ByteBuffer

class TorVpnService : VpnService() {

    companion object {
        const val ACTION_START = "com.linkshield.sandbox.TOR_START"
        const val ACTION_STOP  = "com.linkshield.sandbox.TOR_STOP"

        private const val TAG                  = "TorVpnService"
        private const val NOTIFICATION_ID      = 1001
        private const val CHANNEL_ID           = "tor_vpn_channel"
        private const val VPN_ADDRESS          = "10.0.0.2"
        private const val VPN_DNS              = "9.9.9.9"
        private const val TOR_SOCKS_HOST       = "127.0.0.1"
        private const val TOR_SOCKS_PORT       = 9050
        private const val BOOTSTRAP_TIMEOUT_MS = 90_000L
        private const val PORT_POLL_MS         = 800L
        private const val PORT_CONNECT_TIMEOUT = 1500
    }

    private var vpnInterface: ParcelFileDescriptor? = null
    private var torServiceIntent: Intent? = null
    private val serviceScope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    @Volatile private var isRunning = false

    override fun onCreate() {
        super.onCreate()
        createNotificationChannel()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_START -> {
                if (isRunning) return START_STICKY
                startForeground(NOTIFICATION_ID, buildNotification("Initializing Tor..."))
                serviceScope.launch { startVpn() }
            }
            ACTION_STOP -> serviceScope.launch { stopVpn() }
        }
        return START_STICKY
    }

    override fun onDestroy() {
        stopVpnInternal()
        serviceScope.cancel()
        super.onDestroy()
    }

    private suspend fun startVpn() {
        try {
            isRunning = true
            TorVpnManager.setConnected(false)

            // Step 1: Start Tor daemon
            updateNotification("Starting Tor daemon...")
            torServiceIntent = Intent(this, TorService::class.java)
            startService(torServiceIntent)

            // Step 2: Wait for Tor SOCKS port to be ready
            updateNotification("Bootstrapping Tor network...")
            if (!waitForTorBootstrap()) {
                throw IOException("Tor bootstrap timed out after ${BOOTSTRAP_TIMEOUT_MS / 1000}s")
            }

            // Step 3: Build VPN TUN interface
            updateNotification("Creating VPN interface...")
            vpnInterface = buildVpnInterface()
                ?: throw IOException("Android rejected VPN interface — permission revoked?")

            // Step 4: Start packet forwarding loop (TUN → SOCKS → Tor)
            updateNotification("Starting traffic routing...")
            startPacketForwarding(vpnInterface!!.fd)

            // Step 5: Mark as connected — only AFTER routing is active
            TorVpnManager.setConnected(true)
            updateNotification("🔒 VPN Connected — Traffic routing through Tor")

        } catch (e: Exception) {
            Log.e(TAG, "VPN start failed: ${e.message}", e)
            TorVpnManager.setConnected(false)
            updateNotification("❌ ${e.message ?: "VPN failed"}")
            stopVpnInternal()
        }
    }

    private fun waitForTorBootstrap(): Boolean {
        val deadline = System.currentTimeMillis() + BOOTSTRAP_TIMEOUT_MS
        while (System.currentTimeMillis() < deadline) {
            if (isPortOpen(TOR_SOCKS_HOST, TOR_SOCKS_PORT)) {
                Thread.sleep(1500) // let Tor fully stabilize
                return true
            }
            Thread.sleep(PORT_POLL_MS)
        }
        return false
    }

    private fun isPortOpen(host: String, port: Int): Boolean {
        return try {
            Socket().use { s ->
                s.connect(InetSocketAddress(host, port), PORT_CONNECT_TIMEOUT)
                true
            }
        } catch (_: IOException) { false }
    }

    private fun buildVpnInterface(): ParcelFileDescriptor? {
        return try {
            val builder = Builder()
                .setSession("LinkShield Tor VPN")
                .addAddress(VPN_ADDRESS, 32)
                .addRoute("0.0.0.0", 0)   // Route all IPv4 traffic through VPN
                .addRoute("::", 0)         // Route all IPv6 traffic through VPN
                .addDnsServer(VPN_DNS)
                .setMtu(1500)
                .setBlocking(true)

            // KEY FIX: Exclude our own app from the VPN tunnel.
            // Without this, our OkHttp calls to Cobalt (private IP) go through
            // Tor and fail. Own app traffic goes direct, all other apps go via Tor.
            try {
                builder.addDisallowedApplication(packageName)
                Log.i(TAG, "Own package excluded from VPN — Cobalt API will work normally")
            } catch (e: Exception) {
                Log.w(TAG, "Could not exclude own package: ${e.message}")
            }

            builder.establish()
        } catch (e: Exception) {
            Log.e(TAG, "VPN builder failed: ${e.message}", e)
            null
        }
    }

    /**
     * Packet forwarding loop — reads raw IP packets from TUN fd,
     * forwards each TCP connection through Tor SOCKS5 proxy.
     *
     * This is a lightweight Java-based approach that works without
     * any native binary (no libtun2socks.so required).
     *
     * Architecture:
     *   App → TUN device → this loop → SOCKS5 (Tor:9050) → Internet
     */
    private fun startPacketForwarding(tunFd: Int) {
        serviceScope.launch(Dispatchers.IO) {
            val tunIn  = FileInputStream("/proc/self/fd/$tunFd")
            val tunOut = FileOutputStream("/proc/self/fd/$tunFd")
            val buf    = ByteBuffer.allocate(32767)

            Log.i(TAG, "Packet forwarding started on TUN fd=$tunFd → SOCKS5 $TOR_SOCKS_HOST:$TOR_SOCKS_PORT")

            while (isRunning) {
                try {
                    buf.clear()
                    val len = tunIn.read(buf.array())
                    if (len <= 0) continue

                    buf.limit(len)

                    // Parse destination from IP packet header
                    val dest = parseDestination(buf) ?: continue

                    // Forward packet via SOCKS5 to Tor
                    forwardViaSocks(dest.first, dest.second, buf.array(), len)

                } catch (e: Exception) {
                    if (isRunning) Log.w(TAG, "Packet forward error: ${e.message}")
                }
            }

            tunIn.close()
            tunOut.close()
            Log.i(TAG, "Packet forwarding stopped")
        }
    }

    /**
     * Parse destination IP and port from raw IPv4 TCP packet.
     * Returns null for non-TCP or malformed packets.
     */
    private fun parseDestination(buf: ByteBuffer): Pair<String, Int>? {
        return try {
            if (buf.limit() < 20) return null
            val b = buf.array()

            val ipVersion = (b[0].toInt() and 0xFF) shr 4
            if (ipVersion != 4) return null   // IPv6 not handled here

            val protocol = b[9].toInt() and 0xFF
            if (protocol != 6) return null    // TCP only

            val ihl = (b[0].toInt() and 0x0F) * 4
            if (buf.limit() < ihl + 4) return null

            val destIp = "${b[16].toInt() and 0xFF}.${b[17].toInt() and 0xFF}" +
                         ".${b[18].toInt() and 0xFF}.${b[19].toInt() and 0xFF}"
            val destPort = ((b[ihl + 2].toInt() and 0xFF) shl 8) or (b[ihl + 3].toInt() and 0xFF)

            Pair(destIp, destPort)
        } catch (_: Exception) { null }
    }

    /**
     * Forward data to destination via SOCKS5 (Tor).
     * Uses SOCKS5 CONNECT method (RFC 1928).
     */
    private fun forwardViaSocks(destIp: String, destPort: Int, data: ByteArray, len: Int) {
        try {
            Socket().use { sock ->
                sock.connect(InetSocketAddress(TOR_SOCKS_HOST, TOR_SOCKS_PORT), 5000)
                sock.soTimeout = 10000
                val out = sock.getOutputStream()
                val inp = sock.getInputStream()

                // SOCKS5 handshake
                out.write(byteArrayOf(0x05, 0x01, 0x00)) // Version5, 1 method, NoAuth
                val resp = ByteArray(2)
                inp.read(resp)
                if (resp[1] != 0x00.toByte()) return // auth not accepted

                // SOCKS5 CONNECT request
                val ipBytes = destIp.split(".").map { it.toInt().toByte() }.toByteArray()
                val req = byteArrayOf(
                    0x05, 0x01, 0x00, 0x01,           // VER, CMD=CONNECT, RSV, ATYP=IPv4
                    *ipBytes,                          // destination IP
                    (destPort shr 8).toByte(),         // port high byte
                    (destPort and 0xFF).toByte()       // port low byte
                )
                out.write(req)

                val connResp = ByteArray(10)
                inp.read(connResp)
                if (connResp[1] != 0x00.toByte()) return // connection refused

                // Send original packet data
                out.write(data, 0, len)
                out.flush()
            }
        } catch (_: Exception) {
            // Silently drop unroutable packets — normal during browsing
        }
    }

    private suspend fun stopVpn() {
        stopVpnInternal()
        @Suppress("DEPRECATION")
        stopForeground(true)
        stopSelf()
    }

    private fun stopVpnInternal() {
        isRunning = false
        TorVpnManager.setConnected(false)

        try { vpnInterface?.close() } catch (e: Exception) { Log.w(TAG, "TUN close: ${e.message}") }
        vpnInterface = null

        try {
            torServiceIntent?.let { stopService(it) }
            torServiceIntent = null
        } catch (e: Exception) { Log.w(TAG, "Tor stop: ${e.message}") }
    }

    private fun updateNotification(text: String) {
        getSystemService(NotificationManager::class.java)
            ?.notify(NOTIFICATION_ID, buildNotification(text))
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val ch = NotificationChannel(
                CHANNEL_ID, "Tor VPN Tunnel", NotificationManager.IMPORTANCE_LOW
            ).apply { description = "LinkShield secure tunnel status"; setShowBadge(false) }
            getSystemService(NotificationManager::class.java)?.createNotificationChannel(ch)
        }
    }

    private fun buildNotification(text: String): Notification {
        val pi = PendingIntent.getActivity(
            this, 0,
            Intent(this, MainActivity::class.java).apply {
                flags = Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_SINGLE_TOP
            },
            PendingIntent.FLAG_IMMUTABLE
        )
        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle("LinkShield Secure Tunnel")
            .setContentText(text)
            .setSmallIcon(R.drawable.ic_app_logo)
            .setContentIntent(pi)
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .build()
    }
}
