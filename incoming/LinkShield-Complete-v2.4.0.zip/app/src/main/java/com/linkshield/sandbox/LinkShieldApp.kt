package com.linkshield.sandbox

import android.app.Application
import android.util.Log
import com.linkshield.sandbox.adblock.AdBlockEngine
import com.linkshield.sandbox.ui.grabber.YtDlpEngine
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch

class LinkShieldApp : Application() {

    private val appScope = CoroutineScope(SupervisorJob() + Dispatchers.Default)

    override fun onCreate() {
        super.onCreate()

        // AdBlock engine — background IO
        appScope.launch(Dispatchers.IO) {
            runCatching {
                AdBlockEngine.getInstance().initialize(this@LinkShieldApp)
            }.onFailure {
                Log.w("LinkShieldApp", "AdBlock init failed: ${it.message}")
            }
        }

        // yt-dlp — background IO, does not block UI startup
        appScope.launch(Dispatchers.IO) {
            runCatching {
                YtDlpEngine.initialize(this@LinkShieldApp)
            }.onFailure {
                // Non-fatal — yt-dlp will retry on first YouTube fetch
                Log.w("LinkShieldApp", "yt-dlp pre-init failed: ${it.message}")
            }
        }
    }
}
