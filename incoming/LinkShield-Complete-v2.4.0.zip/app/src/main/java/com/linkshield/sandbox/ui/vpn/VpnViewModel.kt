package com.linkshield.sandbox.ui.vpn

import android.app.Application
import android.content.Intent
import android.net.VpnService
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.linkshield.sandbox.vpn.TorVpnManager
import com.linkshield.sandbox.vpn.VpnConnectionState
import com.linkshield.sandbox.vpn.isActive
import com.linkshield.sandbox.vpn.isBusy
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

class VpnViewModel(application: Application) : AndroidViewModel(application) {

    private val torManager = TorVpnManager(application)

    private val _vpnState = MutableStateFlow<VpnConnectionState>(VpnConnectionState.Disconnected)
    val vpnState: StateFlow<VpnConnectionState> = _vpnState.asStateFlow()

    fun getVpnPermissionIntent(): Intent? = VpnService.prepare(getApplication())

    fun onToggleVpn(onPermissionRequired: (Intent) -> Unit) {
        val current = _vpnState.value
        if (current.isBusy) return
        if (current.isActive) { disconnect(); return }
        val permissionIntent = getVpnPermissionIntent()
        if (permissionIntent != null) onPermissionRequired(permissionIntent)
        else onPermissionGranted()
    }

    fun onPermissionGranted() {
        _vpnState.value = VpnConnectionState.Connecting
        viewModelScope.launch {
            val result = torManager.connect()
            if (result.isFailure) {
                _vpnState.value = VpnConnectionState.Error(
                    result.exceptionOrNull()?.message ?: "Could not start VPN service"
                )
                return@launch
            }

            // FIX: Poll actual connected state instead of setting Connected immediately.
            // TorVpnManager.isConnected() is only true after Tor bootstraps AND
            // packet forwarding loop starts inside TorVpnService.
            val timeoutMs = 100_000L
            val deadline  = System.currentTimeMillis() + timeoutMs

            while (System.currentTimeMillis() < deadline) {
                if (torManager.isConnected()) {
                    _vpnState.value = VpnConnectionState.Connected()
                    return@launch
                }
                delay(1_000L)
            }

            _vpnState.value = VpnConnectionState.Error(
                "Tor took too long to connect. Check internet and try again."
            )
            torManager.disconnect()
        }
    }

    fun disconnect() {
        _vpnState.value = VpnConnectionState.Disconnecting
        viewModelScope.launch {
            torManager.disconnect()
            _vpnState.value = VpnConnectionState.Disconnected
        }
    }

    fun clearError() {
        if (_vpnState.value is VpnConnectionState.Error)
            _vpnState.value = VpnConnectionState.Disconnected
    }
}
