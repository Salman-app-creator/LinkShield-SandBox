package com.linkshield.sandbox.ui.grabber

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.linkshield.sandbox.api.CobaltApiService
import com.linkshield.sandbox.dns.DnsManager
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

class MediaExtractorViewModel(
    application: Application
) : AndroidViewModel(application) {

    private val fallbackRepository = MediaExtractorRepository()
    private val cobalt = CobaltApiService(
        application.applicationContext,
        DnsManager(application.applicationContext)
    )

    private val _state = MutableStateFlow(MediaExtractorState())
    val state: StateFlow<MediaExtractorState> = _state.asStateFlow()

    fun extract(url: String, title: String = "") {
        if (url.isBlank()) {
            _state.value = _state.value.copy(error = "Media URL is empty")
            return
        }

        viewModelScope.launch(Dispatchers.IO) {
            _state.value = _state.value.copy(isLoading = true, error = null, options = emptyList(), selected = null)
            try {
                val cobaltResult = cobalt.fetchMediaUrl(url.trim())
                val options = if (cobaltResult.success && !cobaltResult.url.isNullOrBlank()) {
                    val mediaUrl = cobaltResult.url
                    val mime = inferMimeType(mediaUrl, cobaltResult.filename.orEmpty())
                    listOf(
                        MediaQualityOption(
                            url = mediaUrl,
                            quality = inferQuality(cobaltResult.filename.orEmpty()),
                            label = cobaltResult.filename?.takeIf { it.isNotBlank() } ?: "Cobalt result",
                            mimeType = mime,
                            title = title,
                            isAudio = mime.startsWith("audio/")
                        )
                    )
                } else if (cobalt.isDirectFileLink(url)) {
                    // Direct-file fallback keeps local media links usable when Cobalt rejects a URL.
                    fallbackRepository.extract(url, title)
                } else {
                    emptyList()
                }

                _state.value = _state.value.copy(
                    isLoading = false,
                    options = options,
                    selected = options.firstOrNull(),
                    error = if (options.isEmpty()) cobaltResult.error ?: "No downloadable media found" else null
                )
            } catch (e: Exception) {
                _state.value = _state.value.copy(
                    isLoading = false,
                    error = e.message ?: "Extraction failed"
                )
            }
        }
    }

    fun select(option: MediaQualityOption) {
        _state.value = _state.value.copy(selected = option)
    }

    fun clear() {
        _state.value = MediaExtractorState()
    }

    private fun inferMimeType(url: String, filename: String): String {
        val value = (url + " " + filename).lowercase()
        return when {
            ".mp3" in value -> "audio/mpeg"
            ".m4a" in value -> "audio/mp4"
            ".aac" in value -> "audio/aac"
            ".ogg" in value -> "audio/ogg"
            ".webm" in value -> "video/webm"
            ".m3u8" in value -> "application/vnd.apple.mpegurl"
            ".mpd" in value -> "application/dash+xml"
            ".mp4" in value -> "video/mp4"
            else -> "application/octet-stream"
        }
    }

    private fun inferQuality(value: String): String = when {
        "1080" in value -> "1080p"
        "720" in value -> "720p"
        "480" in value -> "480p"
        "360" in value -> "360p"
        else -> ""
    }
}

class MediaExtractorViewModelFactory(
    private val application: Application
) : ViewModelProvider.Factory {
    @Suppress("UNCHECKED_CAST")
    override fun <T : ViewModel> create(modelClass: Class<T>): T {
        if (modelClass.isAssignableFrom(MediaExtractorViewModel::class.java)) {
            return MediaExtractorViewModel(application) as T
        }
        throw IllegalArgumentException("Unknown ViewModel: ${modelClass.name}")
    }
}
