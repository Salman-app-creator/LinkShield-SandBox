package com.linkshield.sandbox.ui.grabber

import android.content.ClipboardManager
import android.content.Context
import android.widget.Toast
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Clear
import androidx.compose.material.icons.filled.ContentPaste
import androidx.compose.material.icons.filled.Download
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.Checkbox
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalSoftwareKeyboardController
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.linkshield.sandbox.license.LicenseManager

@Composable
fun MediaGrabberScreen(
    onBackToBrowser: () -> Unit,
    viewModel: MediaExtractorViewModel = viewModel()
) {
    val context = LocalContext.current
    val keyboard = LocalSoftwareKeyboardController.current
    val state by viewModel.state.collectAsState()
    val licenseManager = remember { LicenseManager(context.applicationContext) }
    var inputUrl by remember { mutableStateOf("") }
    var audioOnly by remember { mutableStateOf(false) }
    var highQuality by remember { mutableStateOf(false) }

    BackHandler(onBack = onBackToBrowser)

    LaunchedEffect(state.error) {
        state.error?.let { Toast.makeText(context, it, Toast.LENGTH_LONG).show() }
    }

    fun fetch() {
        if (inputUrl.isBlank()) return
        keyboard?.hide()
        viewModel.extract(
            url = inputUrl.trim(),
            audioOnly = audioOnly,
            highQuality = highQuality
        )
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Grabber") },
                navigationIcon = {
                    IconButton(onClick = onBackToBrowser) {
                        Icon(Icons.Default.ArrowBack, "Back to current website")
                    }
                }
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(horizontal = 14.dp, vertical = 10.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            val remaining = licenseManager.getRemainingDownloads()
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(12.dp),
                colors = CardDefaults.cardColors(
                    containerColor = MaterialTheme.colorScheme.primaryContainer
                )
            ) {
                Column(Modifier.padding(12.dp)) {
                    Text(
                        if (licenseManager.isProUser()) "Unlimited Downloads • PRO" else "$remaining Free Downloads Remaining",
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        if (licenseManager.isProUser()) "Pro is active." else "Upgrade to Pro for unlimited downloads.",
                        style = MaterialTheme.typography.bodySmall
                    )
                }
            }

            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                OutlinedTextField(
                    value = inputUrl,
                    onValueChange = { inputUrl = it },
                    modifier = Modifier.weight(1f),
                    singleLine = true,
                    placeholder = { Text("Paste or Fetch Link...") },
                    shape = RoundedCornerShape(10.dp),
                    trailingIcon = {
                        if (inputUrl.isNotEmpty()) {
                            IconButton(onClick = { inputUrl = ""; viewModel.clear() }) {
                                Icon(Icons.Default.Clear, "Clear")
                            }
                        } else {
                            IconButton(onClick = {
                                val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                                val text = clipboard.primaryClip?.getItemAt(0)?.text?.toString().orEmpty()
                                if (text.isNotBlank()) inputUrl = text
                            }) {
                                Icon(Icons.Default.ContentPaste, "Paste")
                            }
                        }
                    },
                    keyboardOptions = KeyboardOptions(imeAction = ImeAction.Go),
                    keyboardActions = KeyboardActions(onGo = { fetch() })
                )
            }

            Button(
                onClick = { fetch() },
                enabled = inputUrl.isNotBlank() && !state.isLoading,
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(10.dp)
            ) {
                if (state.isLoading) {
                    CircularProgressIndicator(Modifier.size(18.dp), strokeWidth = 2.dp, color = MaterialTheme.colorScheme.onPrimary)
                    Spacer(Modifier.width(8.dp))
                    Text("Fetching...")
                } else {
                    Text("Fetch Media")
                }
            }

            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(150.dp),
                shape = RoundedCornerShape(12.dp)
            ) {
                Column(
                    modifier = Modifier.fillMaxSize().padding(16.dp),
                    verticalArrangement = Arrangement.Center,
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    val preview = state.selected ?: state.options.firstOrNull()
                    Text(
                        preview?.title?.substringBeforeLast('.') ?: "Media Preview",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold
                    )
                    Spacer(Modifier.height(6.dp))
                    Text(
                        preview?.displayLabel ?: "Paste a media link and tap Fetch Media",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }

            Text("Options", fontWeight = FontWeight.Bold)
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Checkbox(
                        checked = audioOnly,
                        onCheckedChange = {
                            audioOnly = it
                            viewModel.clear()
                        }
                    )
                    Text("Audio Only")
                }
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Checkbox(
                        checked = highQuality,
                        onCheckedChange = {
                            highQuality = it
                            viewModel.clear()
                        }
                    )
                    Text("High Qual")
                }
            }

            if (state.options.isNotEmpty()) {
                HorizontalDivider()
                Text(
                    state.selected?.displayLabel ?: "Ready to download",
                    fontWeight = FontWeight.SemiBold
                )
                Button(
                    onClick = {
                        val option = state.selected ?: return@Button
                        if (!licenseManager.canDownload()) {
                            Toast.makeText(context, "Free download limit reached. Upgrade to Pro.", Toast.LENGTH_LONG).show()
                            return@Button
                        }
                        val manager = GrabberDownloadManager(context.applicationContext)
                        val id = manager.download(option)
                        if (id != null) {
                            licenseManager.incrementDownloadCount()
                            Toast.makeText(context, "Download started", Toast.LENGTH_SHORT).show()
                        } else {
                            Toast.makeText(context, "Download failed", Toast.LENGTH_LONG).show()
                        }
                    },
                    modifier = Modifier.fillMaxWidth().height(50.dp),
                    shape = RoundedCornerShape(10.dp)
                ) {
                    Icon(Icons.Default.Download, null)
                    Spacer(Modifier.width(8.dp))
                    Text("Download")
                }
            }
        }
    }
}
