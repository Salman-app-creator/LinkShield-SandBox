package com.linkshield.sandbox.api

import android.app.DownloadManager
import android.content.Context
import android.net.Uri
import android.os.Environment
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaTypeOrNull
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONObject
import java.io.IOException
import java.util.concurrent.TimeUnit
import com.linkshield.sandbox.dns.DnsManager

class CobaltApiService(
    context: Context,
    dnsManager: DnsManager
) {
    private val client = dnsManager.getClient().newBuilder()
        .connectTimeout(30, TimeUnit.SECONDS)
        .readTimeout(90, TimeUnit.SECONDS)
        .build()

    private val downloadManager = context.getSystemService(Context.DOWNLOAD_SERVICE) as DownloadManager

    companion object {
        const val API_BASE = "https://api.cobalt.tools"
    }

    data class MediaResult(
        val success: Boolean,
        val url: String? = null,
        val filename: String? = null,
        val error: String? = null,
        val isDirectDownload: Boolean = false
    )

    suspend fun fetchMediaUrl(
        pageUrl: String,
        audioOnly: Boolean = false,
        videoQuality: String = "720"
    ): MediaResult = withContext(Dispatchers.IO) {
        try {
            val jsonBody = JSONObject().apply {
                put("url", pageUrl)
                put("downloadMode", if (audioOnly) "audio" else "auto")
                put("videoQuality", videoQuality)
                put("audioFormat", "mp3")
                put("audioBitrate", "128")
                put("filenameStyle", "classic")
                put("youtubeVideoCodec", "h264")
                put("youtubeVideoContainer", "mp4")
            }

            val request = Request.Builder()
                .url(API_BASE)
                .addHeader("Accept", "application/json")
                .addHeader("Content-Type", "application/json")
                .post(jsonBody.toString().toRequestBody("application/json".toMediaTypeOrNull()))
                .build()

            client.newCall(request).execute().use { response ->
                val body = response.body?.string()
                if (!response.isSuccessful || body.isNullOrBlank()) {
                    return@withContext MediaResult(false, error = "Media service error: HTTP ${response.code}")
                }

                val json = JSONObject(body)
                when (json.optString("status")) {
                    "redirect", "tunnel", "stream" -> {
                        val url = json.optString("url")
                        if (url.isBlank()) MediaResult(false, error = "Media service returned no download URL")
                        else MediaResult(
                            success = true,
                            url = url,
                            filename = json.optString("filename", if (audioOnly) "LinkShield Audio.mp3" else "LinkShield Video.mp4"),
                            isDirectDownload = json.optString("status") == "tunnel"
                        )
                    }
                    "picker" -> {
                        val picker = json.optJSONArray("picker")
                        val first = picker?.optJSONObject(0)
                        val url = first?.optString("url").orEmpty()
                        if (url.isBlank()) MediaResult(false, error = "No selectable media was returned")
                        else MediaResult(true, url = url, filename = if (audioOnly) "LinkShield Audio.mp3" else "LinkShield Video.mp4")
                    }
                    "error" -> {
                        val errorObject = json.optJSONObject("error")
                        MediaResult(
                            false,
                            error = errorObject?.optString("code")
                                ?: json.optString("text", "Media service rejected this URL")
                        )
                    }
                    else -> MediaResult(false, error = "Unexpected media service response")
                }
            }
        } catch (e: IOException) {
            MediaResult(false, error = "Network error: ${e.message ?: "connection failed"}")
        } catch (e: Exception) {
            MediaResult(false, error = "Media extraction failed: ${e.message ?: "unknown error"}")
        }
    }

    fun startDownload(url: String, filename: String, mimeType: String = "video/mp4"): Long {
        val request = DownloadManager.Request(Uri.parse(url))
            .setTitle(filename)
            .setDescription("Downloading via LinkShield")
            .setMimeType(mimeType)
            .setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED)
            .setDestinationInExternalPublicDir(Environment.DIRECTORY_DOWNLOADS, "LinkShield/$filename")
            .setAllowedOverMetered(true)
            .setAllowedOverRoaming(true)
        return downloadManager.enqueue(request)
    }
}
