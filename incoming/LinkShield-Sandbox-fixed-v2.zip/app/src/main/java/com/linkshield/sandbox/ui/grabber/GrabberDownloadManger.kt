package com.linkshield.sandbox.ui.grabber

import android.app.DownloadManager
import android.content.Context
import android.net.Uri
import android.os.Environment
import android.webkit.URLUtil

class GrabberDownloadManager(
    private val context: Context
) {
    private val downloadManager = context.getSystemService(Context.DOWNLOAD_SERVICE) as DownloadManager

    fun download(option: MediaQualityOption): Long? {
        val url = option.url.trim()
        if (!url.startsWith("http://") && !url.startsWith("https://")) return null

        return try {
            val fileName = createFileName(option)
            val request = DownloadManager.Request(Uri.parse(url)).apply {
                setTitle(option.title.ifBlank { fileName })
                setDescription("LinkShield Sandbox")
                setMimeType(option.mimeType.ifBlank { "application/octet-stream" })
                setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED)
                setAllowedOverMetered(true)
                setAllowedOverRoaming(true)
                setDestinationInExternalPublicDir(Environment.DIRECTORY_DOWNLOADS, "LinkShield/$fileName")
            }
            downloadManager.enqueue(request)
        } catch (_: Exception) {
            null
        }
    }

    private fun createFileName(option: MediaQualityOption): String {
        var title = option.title.ifBlank {
            URLUtil.guessFileName(option.url, null, option.mimeType)
        }
        title = title
            .replace(Regex("[\\\\/:*?\"<>|]"), "_")
            .trim()
            .ifBlank { "LinkShield Download" }

        val extension = when {
            option.mimeType.contains("audio/mpeg", true) -> ".mp3"
            option.mimeType.contains("audio/mp4", true) -> ".m4a"
            option.mimeType.contains("webm", true) -> ".webm"
            option.mimeType.contains("mp4", true) -> ".mp4"
            else -> ".mp4"
        }

        return if (title.endsWith(extension, true)) title else "$title$extension"
    }
}
