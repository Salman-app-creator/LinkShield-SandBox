package com.linkshield.sandbox.ui.grabber

import android.content.Context
import com.linkshield.sandbox.api.CobaltApiService
import com.linkshield.sandbox.dns.DnsManager
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

class MediaExtractorRepository(
    context: Context
) {
    private val cobalt = CobaltApiService(
        context.applicationContext,
        DnsManager(context.applicationContext)
    )

    suspend fun extract(
        mediaUrl: String,
        title: String = "",
        audioOnly: Boolean = false,
        highQuality: Boolean = false
    ): List<MediaQualityOption> = withContext(Dispatchers.IO) {
        if (mediaUrl.isBlank()) return@withContext emptyList()
        if (mediaUrl.startsWith("blob:", ignoreCase = true)) return@withContext emptyList()

        val result = cobalt.fetchMediaUrl(
            pageUrl = mediaUrl,
            audioOnly = audioOnly,
            videoQuality = if (highQuality) "1080" else "720"
        )

        if (!result.success || result.url.isNullOrBlank()) {
            throw IllegalStateException(result.error ?: "Unable to extract media")
        }

        val filename = result.filename.orEmpty().ifBlank {
            if (audioOnly) "LinkShield Audio.mp3" else "LinkShield Video.mp4"
        }
        val mime = when {
            audioOnly -> "audio/mpeg"
            filename.endsWith(".webm", true) -> "video/webm"
            else -> "video/mp4"
        }
        val quality = if (audioOnly) "Audio" else if (highQuality) "1080p" else "720p"
        val displayTitle = title.ifBlank { filename.substringBeforeLast('.') }

        listOf(
            MediaQualityOption(
                url = result.url,
                quality = quality,
                label = if (audioOnly) "Audio Only • MP3" else "Video • $quality • MP4",
                mimeType = mime,
                title = filename.ifBlank { displayTitle },
                isAudio = audioOnly
            )
        )
    }
}
