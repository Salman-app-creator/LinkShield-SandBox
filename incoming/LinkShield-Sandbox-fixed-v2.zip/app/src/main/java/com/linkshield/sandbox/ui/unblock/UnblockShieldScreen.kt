package com.linkshield.sandbox.ui.unblock

import android.app.Activity
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.graphics.Bitmap
import android.view.ViewGroup
import java.io.ByteArrayInputStream
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Toast
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalSoftwareKeyboardController
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.lifecycle.viewmodel.compose.viewModel
import com.linkshield.sandbox.SecurityChecker
import com.linkshield.sandbox.adblock.AdBlockEngine
import com.linkshield.sandbox.api.SecurityApiService
import com.linkshield.sandbox.dns.DnsManager
import com.linkshield.sandbox.dns.DohProvider
import com.linkshield.sandbox.license.LicenseManager
import com.linkshield.sandbox.ui.components.TopHeader
import com.linkshield.sandbox.ui.grabber.CapturedMediaItem
import com.linkshield.sandbox.ui.grabber.MediaGrabberScreen
import com.linkshield.sandbox.ui.upgrade.UpgradeScreen
import com.linkshield.sandbox.vpn.WireGuardPermissionManager
import com.linkshield.sandbox.vpn.WireGuardVpnManager
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

private enum class MainTab {
    CHECK, BROWSE, GRABBER, SECURE, UPGRADE
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun UnblockShieldScreen(
    viewModel: UnblockShieldViewModel = viewModel(),
    initialUrl: String = "",
    isDarkTheme: Boolean = true,
    onThemeToggle: (Boolean) -> Unit = {}
) {
    val context = LocalContext.current
    val keyboardController = LocalSoftwareKeyboardController.current
    val dnsManager = remember { DnsManager(context.applicationContext) }
    val licenseManager = remember { LicenseManager(context.applicationContext) }
    var selectedTab by remember { mutableStateOf(MainTab.BROWSE) }
    var isShieldActive by remember { mutableStateOf(dnsManager.isDohEnabled()) }
    var webView by remember { mutableStateOf<WebView?>(null) }
    val startUrl = remember(initialUrl, viewModel.currentUrl) {
        initialUrl.trim().takeIf { it.isNotBlank() }?.let(::normalizeUrl) ?: viewModel.currentUrl
    }
    var urlInput by remember(startUrl) { mutableStateOf(startUrl) }
    var isLoading by remember { mutableStateOf(false) }
    var progress by remember { mutableStateOf(0) }
    var canGoBack by remember { mutableStateOf(false) }
    var canGoForward by remember { mutableStateOf(false) }
    var showMediaSheet by remember { mutableStateOf(false) }

    val capturedMediaList = viewModel.capturedMediaList.map {
        CapturedMediaItem(url = it.url, title = it.title ?: "Media File", mimeType = it.type)
    }

    LaunchedEffect(startUrl) {
        if (startUrl.isNotBlank()) viewModel.updateUrl(startUrl)
    }

    BackHandler {
        when {
            selectedTab == MainTab.BROWSE && canGoBack -> webView?.goBack()
            selectedTab != MainTab.BROWSE -> selectedTab = MainTab.BROWSE
            else -> (context as? Activity)?.finish()
        }
    }

    Scaffold(
        topBar = {
            TopHeader(
                currentUrl = urlInput,
                onUrlChange = { urlInput = it },
                isShieldActive = isShieldActive,
                onShieldToggle = {
                    if (dnsManager.isDohEnabled()) dnsManager.disableDoh() else dnsManager.enableDoh()
                    isShieldActive = dnsManager.isDohEnabled()
                },
                trialDaysLeft = licenseManager.getTrialDaysRemaining(),
                isDarkTheme = isDarkTheme,
                onThemeToggle = onThemeToggle,
                canGoBack = selectedTab == MainTab.BROWSE && canGoBack,
                canGoForward = selectedTab == MainTab.BROWSE && canGoForward,
                onBack = { webView?.goBack() },
                onForward = { webView?.goForward() },
                onReload = { webView?.reload() },
                onNavigate = {
                    keyboardController?.hide()
                    val target = normalizeUrl(urlInput)
                    urlInput = target
                    viewModel.updateUrl(target)
                    selectedTab = MainTab.BROWSE
                    webView?.loadUrl(target)
                },
                onSecureClick = { selectedTab = MainTab.SECURE },
                onDnsProviderChange = { providerName ->
                    val provider = when {
                        providerName == "WARP" -> DohProvider.CLOUDFLARE_WARP
                        providerName == "Cloudflare" -> DohProvider.CLOUDFLARE
                        providerName == "Google" -> DohProvider.GOOGLE
                        providerName == "Quad9" -> DohProvider.QUAD9
                        providerName == "AdGuard" -> DohProvider.ADGUARD
                        else -> DohProvider.CLOUDFLARE
                    }
                    dnsManager.enableDoh(provider)
                    isShieldActive = true
                },
                onDnsDisable = {
                    dnsManager.disableDoh()
                    isShieldActive = false
                }
            )
        },
        bottomBar = {
            NavigationBar(tonalElevation = 8.dp, modifier = Modifier.fillMaxWidth()) {
                listOf(MainTab.CHECK, MainTab.BROWSE, MainTab.GRABBER, MainTab.UPGRADE).forEach { tab ->
                    NavigationBarItem(
                        selected = selectedTab == tab,
                        onClick = { selectedTab = tab },
                        icon = {
                            Icon(
                                when (tab) {
                                    MainTab.CHECK -> Icons.Default.Security
                                    MainTab.BROWSE -> Icons.Default.Public
                                    MainTab.GRABBER -> Icons.Default.Download
                                    MainTab.UPGRADE -> Icons.Default.Star
                                    MainTab.SECURE -> Icons.Default.Lock
                                },
                                contentDescription = null
                            )
                        },
                        label = {
                            Text(
                                when (tab) {
                                    MainTab.CHECK -> "Check"
                                    MainTab.BROWSE -> "Browse"
                                    MainTab.GRABBER -> "Grabber"
                                    MainTab.UPGRADE -> "Upgrade"
                                    MainTab.SECURE -> "Secure"
                                }
                            )
                        }
                    )
                }
            }
        }
    ) { innerPadding ->
        Box(Modifier.fillMaxSize().padding(innerPadding)) {
            when (selectedTab) {
                MainTab.BROWSE -> {
                    BrowserPane(
                        viewModel = viewModel,
                        startUrl = startUrl,
                        onUrlChanged = { url -> urlInput = url; viewModel.updateUrl(url) },
                        onLoadingChanged = { isLoading = it },
                        onProgressChanged = { progress = it },
                        onNavigationChanged = { back, forward -> canGoBack = back; canGoForward = forward },
                        onWebViewReady = { webView = it },
                        modifier = Modifier.fillMaxSize()
                    )
                    if (isLoading) {
                        LinearProgressIndicator(
                            progress = { progress / 100f },
                            modifier = Modifier.fillMaxWidth().height(2.dp).align(Alignment.TopCenter)
                        )
                    }
                    BadgedBox(
                        badge = { if (capturedMediaList.isNotEmpty()) Badge { Text("${capturedMediaList.size}") } },
                        modifier = Modifier.align(Alignment.BottomEnd)
                    ) {
                        FloatingActionButton(onClick = { showMediaSheet = true }, modifier = Modifier.padding(16.dp)) {
                            Icon(Icons.Default.Download, "Detected media")
                        }
                    }
                    if (showMediaSheet) {
                        MediaLinksSheet(
                            context = context,
                            items = capturedMediaList,
                            onDismiss = { showMediaSheet = false },
                            onClear = { viewModel.clearCapturedMedia() }
                        )
                    }
                }
                MainTab.CHECK -> CheckTab()
                MainTab.GRABBER -> {
                    MediaGrabberScreen(
                        onBackToBrowser = {
                            selectedTab = MainTab.BROWSE
                            webView?.loadUrl(normalizeUrl(urlInput))
                        }
                    )
                }
                MainTab.SECURE -> SecureTab(dnsManager)
                MainTab.UPGRADE -> UpgradeScreen(licenseManager)
            }
        }
    }
}

@Composable
private fun BrowserPane(
    viewModel: UnblockShieldViewModel,
    startUrl: String,
    onUrlChanged: (String) -> Unit,
    onLoadingChanged: (Boolean) -> Unit,
    onProgressChanged: (Int) -> Unit,
    onNavigationChanged: (Boolean, Boolean) -> Unit,
    onWebViewReady: (WebView) -> Unit,
    modifier: Modifier
) {
    AndroidView(
        modifier = modifier,
        factory = { ctx ->
            WebView(ctx).apply {
                layoutParams = ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT)
                settings.javaScriptEnabled = true
                settings.domStorageEnabled = true
                settings.databaseEnabled = true
                settings.allowFileAccess = false
                settings.allowContentAccess = true
                settings.mediaPlaybackRequiresUserGesture = false
                settings.useWideViewPort = true
                settings.loadWithOverviewMode = true
                settings.setSupportMultipleWindows(false)
                settings.userAgentString = "Mozilla/5.0 (Linux; Android 12) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/128.0 Mobile Safari/537.36"

                webViewClient = object : WebViewClient() {
                    override fun onPageStarted(view: WebView?, url: String?, favicon: Bitmap?) {
                        onLoadingChanged(true)
                        url?.let(onUrlChanged)
                    }

                    override fun onPageFinished(view: WebView?, url: String?) {
                        onLoadingChanged(false)
                        onNavigationChanged(view?.canGoBack() == true, view?.canGoForward() == true)
                    }

                    override fun shouldInterceptRequest(view: WebView?, request: WebResourceRequest?): WebResourceResponse? {
                        val reqUrl = request?.url?.toString().orEmpty()
                        return try {
                            if (reqUrl.isNotBlank() && AdBlockEngine.getInstance().shouldBlock(reqUrl)) {
                                WebResourceResponse("text/plain", "utf-8", 204, "No Content", emptyMap(), ByteArrayInputStream(ByteArray(0)))
                            } else {
                                if (reqUrl.isNotBlank() && isMediaUrl(reqUrl)) {
                                    view?.post {
                                        val type = when {
                                            reqUrl.contains(".mp3", true) -> "Audio"
                                            reqUrl.contains(".m3u8", true) -> "HLS Stream"
                                            else -> "Video"
                                        }
                                        viewModel.addCapturedMedia(reqUrl, type, view.title)
                                    }
                                }
                                super.shouldInterceptRequest(view, request)
                            }
                        } catch (_: Exception) {
                            super.shouldInterceptRequest(view, request)
                        }
                    }

                    override fun shouldOverrideUrlLoading(view: WebView?, request: WebResourceRequest?): Boolean {
                        val scheme = request?.url?.scheme?.lowercase()
                        return scheme != null && scheme !in setOf("http", "https")
                    }
                }

                webChromeClient = object : WebChromeClient() {
                    override fun onProgressChanged(view: WebView?, newProgress: Int) { onProgressChanged(newProgress) }
                    override fun onShowCustomView(view: android.view.View?, callback: CustomViewCallback?) { viewModel.showCustomView(callback) }
                    override fun onHideCustomView() { viewModel.hideCustomView() }
                }

                onWebViewReady(this)
                loadUrl(startUrl)
            }
        },
        update = { onWebViewReady(it) }
    )
}

@Composable
private fun CheckTab() {
    val scope = rememberCoroutineScope()
    val api = remember { SecurityApiService() }
    var input by remember { mutableStateOf("") }
    var loading by remember { mutableStateOf(false) }
    var resultText by remember { mutableStateOf<String?>(null) }
    var expandedUrl by remember { mutableStateOf<String?>(null) }
    Column(Modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Text("Link Security Check", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
        Text("Expand shortened links and check the destination before opening it.", color = MaterialTheme.colorScheme.onSurfaceVariant)
        OutlinedTextField(value = input, onValueChange = { input = it }, modifier = Modifier.fillMaxWidth(), singleLine = true, placeholder = { Text("https://example.com/...") })
        Button(
            onClick = {
                val target = normalizeUrl(input)
                if (target.isBlank()) return@Button
                loading = true
                scope.launch(Dispatchers.IO) {
                    val local = SecurityChecker.analyzeUrl(target)
                    val remote = api.checkAndExpand(target)
                    expandedUrl = remote.second.expandedUrl.takeIf { remote.second.success }
                    resultText = when {
                        remote.first.isMalicious -> "DANGEROUS: ${remote.first.message}"
                        remote.first.isSuspicious || local.isDangerous -> "SUSPICIOUS: ${remote.first.message.ifBlank { local.warnings.joinToString() }}"
                        else -> "No threat detected. Local score: ${local.score}/100"
                    }
                    loading = false
                }
            },
            enabled = input.isNotBlank() && !loading,
            modifier = Modifier.fillMaxWidth()
        ) { if (loading) CircularProgressIndicator(Modifier.size(18.dp), strokeWidth = 2.dp) else Text("Check Link") }
        resultText?.let {
            Card(Modifier.fillMaxWidth()) { Column(Modifier.padding(16.dp)) { Text(it, fontWeight = FontWeight.Bold); expandedUrl?.let { url -> Text("Expanded: $url", style = MaterialTheme.typography.bodySmall) } } }
        }
    }
}

@Composable
private fun SecureTab(dnsManager: DnsManager) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val activity = context as? Activity
    val vpnManager = remember { WireGuardVpnManager(context.applicationContext) }
    var dohEnabled by remember { mutableStateOf(dnsManager.isDohEnabled()) }
    var vpnConnected by remember { mutableStateOf(vpnManager.isConnected()) }
    var message by remember { mutableStateOf<String?>(null) }
    Column(Modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
        Text("Secure Network", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
        Card(Modifier.fillMaxWidth()) {
            Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text("DNS-over-HTTPS", fontWeight = FontWeight.Bold)
                Text(if (dohEnabled) "DNS requests are protected." else "DoH is disabled.", color = MaterialTheme.colorScheme.onSurfaceVariant)
                Button(onClick = { if (dohEnabled) dnsManager.disableDoh() else dnsManager.enableDoh(); dohEnabled = dnsManager.isDohEnabled() }, modifier = Modifier.fillMaxWidth()) {
                    Text(if (dohEnabled) "Disable DNS Shield" else "Enable DNS Shield")
                }
            }
        }
        Card(Modifier.fillMaxWidth()) {
            Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text("WireGuard", fontWeight = FontWeight.Bold)
                Text(if (vpnManager.hasConfiguration()) "A valid WireGuard configuration is installed." else "No WireGuard configuration is installed.", color = MaterialTheme.colorScheme.onSurfaceVariant)
                Button(
                    onClick = {
                        if (vpnConnected) {
                            scope.launch { vpnManager.disconnect(); vpnConnected = vpnManager.isConnected() }
                        } else if (vpnManager.hasConfiguration() && activity != null) {
                            val permissionManager = WireGuardPermissionManager(activity)
                            if (permissionManager.prepare()) {
                                scope.launch {
                                    val result = vpnManager.connect()
                                    vpnConnected = result.isSuccess && vpnManager.isConnected()
                                    message = result.exceptionOrNull()?.message
                                }
                            }
                        } else message = "Install a WireGuard configuration first."
                    },
                    modifier = Modifier.fillMaxWidth()
                ) { Text(if (vpnConnected) "Disconnect VPN" else "Connect VPN") }
            }
        }
        message?.let { Text(it, color = MaterialTheme.colorScheme.primary) }
    }
}

private fun normalizeUrl(value: String): String {
    val input = value.trim()
    if (input.isBlank()) return "https://google.com"
    return if (input.startsWith("http://") || input.startsWith("https://")) input else "https://$input"
}

private fun isMediaUrl(url: String): Boolean {
    val value = url.lowercase()
    return value.contains(".mp4") || value.contains(".mp3") || value.contains(".m4a") || value.contains(".webm") || value.contains(".m3u8")
}

@Composable
private fun MediaLinksSheet(
    context: Context,
    items: List<CapturedMediaItem>,
    onDismiss: () -> Unit,
    onClear: () -> Unit
) {
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Detected Media") },
        text = {
            LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                items(items) { item ->
                    Column {
                        Text(item.title, fontWeight = FontWeight.SemiBold)
                        Text(item.url, style = MaterialTheme.typography.bodySmall)
                        TextButton(onClick = {
                            val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                            clipboard.setPrimaryClip(ClipData.newPlainText("Media URL", item.url))
                            Toast.makeText(context, "URL copied", Toast.LENGTH_SHORT).show()
                        }) { Text("Copy URL") }
                    }
                }
            }
        },
        confirmButton = { TextButton(onClick = onDismiss) { Text("Close") } },
        dismissButton = { TextButton(onClick = onClear) { Text("Clear") } }
    )
}
