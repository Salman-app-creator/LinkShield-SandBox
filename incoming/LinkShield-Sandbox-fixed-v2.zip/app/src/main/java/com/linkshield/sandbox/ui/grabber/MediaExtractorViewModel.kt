package com.linkshield.sandbox.ui.grabber

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

data class MediaExtractorState(
    val isLoading: Boolean = false,
    val options: List<MediaQualityOption> = emptyList(),
    val selected: MediaQualityOption? = null,
    val error: String? = null
)

class MediaExtractorViewModel(
    application: Application
) : AndroidViewModel(application) {
    private val repository = MediaExtractorRepository(application.applicationContext)
    private val _state = MutableStateFlow(MediaExtractorState())
    val state: StateFlow<MediaExtractorState> = _state.asStateFlow()

    fun extract(
        url: String,
        title: String = "",
        audioOnly: Boolean = false,
        highQuality: Boolean = false
    ) {
        if (url.isBlank()) {
            _state.value = _state.value.copy(error = "Media URL is empty")
            return
        }

        viewModelScope.launch(Dispatchers.IO) {
            _state.value = _state.value.copy(isLoading = true, error = null, options = emptyList(), selected = null)
            try {
                val options = repository.extract(url, title, audioOnly, highQuality)
                if (options.isEmpty()) throw IllegalStateException("No downloadable media was found")
                _state.value = _state.value.copy(
                    isLoading = false,
                    options = options,
                    selected = options.firstOrNull(),
                    error = null
                )
            } catch (e: Exception) {
                _state.value = _state.value.copy(
                    isLoading = false,
                    options = emptyList(),
                    selected = null,
                    error = e.message ?: "Extraction failed"
                )
            }
        }
    }

    fun select(option: MediaQualityOption) {
        _state.value = _state.value.copy(selected = option)
    }

    fun clear() {
        _state.value = MediaExtractorState()
    }
}
