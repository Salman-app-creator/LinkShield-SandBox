package com.linkshield.sandbox.api

import android.content.Context
import android.net.Uri
import com.linkshield.sandbox.BuildConfig
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONObject
import java.net.SocketTimeoutException
import java.util.concurrent.TimeUnit

data class MediaResult(
    val success: Boolean,
    val url: String? = null,
    val filename: String? = null,
    val mimeType: String? = null,
    val error: String? = null
)

class CobaltApiService(context: Context) {

    private val appContext = context.applicationContext

    private val client: OkHttpClient by lazy {
        OkHttpClient.Builder()
            .connectTimeout(12, TimeUnit.SECONDS)
            .readTimeout(45, TimeUnit.SECONDS)
            .writeTimeout(15, TimeUnit.SECONDS)
            .callTimeout(60, TimeUnit.SECONDS)
            .followRedirects(true)
            .followSslRedirects(true)
            .retryOnConnectionFailure(true)
            .build()
    }

    private fun baseUrl(): String =
        BuildConfig.COBALT_BASE_URL.trim().trimEnd('/') + "/"

    private fun isYouTubeUrl(host: String): Boolean =
        host == "youtube.com" || host.endsWith(".youtube.com") ||
        host == "youtu.be"   || host.endsWith(".youtu.be")

    // FIX: All platforms — full URL preserved, NO path-only stripping
    // Facebook/Instagram/TikTok share URLs need query params to resolve video ID
    fun cleanVideoUrl(rawUrl: String): String {
        val trimmed = rawUrl.trim()
        return try {
            val uri  = Uri.parse(trimmed)
            val host = uri.host?.lowercase().orEmpty()
            when {
                host == "youtube.com" || host.endsWith(".youtube.com") -> {
                    val vid = uri.getQueryParameter("v")
                    when {
                        !vid.isNullOrBlank() -> "https://www.youtube.com/watch?v=$vid"
                        uri.path?.startsWith("/shorts/") == true ->
                            "https://www.youtube.com${uri.path}"
                        else -> trimmed
                    }
                }
                host == "youtu.be" || host.endsWith(".youtu.be") -> {
                    val vid = uri.lastPathSegment
                    if (!vid.isNullOrBlank()) "https://www.youtube.com/watch?v=$vid" else trimmed
                }
                // FIXED: return trimmed (full URL) for ALL other platforms
                // Previously was returning "https://www.facebook.com${uri.path}" — stripped query params
                else -> trimmed
            }
        } catch (_: Exception) { trimmed }
    }

    // FIX: resolution parameter added — wired from UI selection
    suspend fun fetchMediaUrl(
        rawUrl: String,
        audioOnly: Boolean = false,
        resolution: String = "1080p"
    ): MediaResult = withContext(Dispatchers.IO) {
        try {
            val cleanedUrl = cleanVideoUrl(rawUrl)
            val host = Uri.parse(cleanedUrl).host?.lowercase().orEmpty()

            if (cleanedUrl.isBlank() || !cleanedUrl.startsWith("http", ignoreCase = true)) {
                return@withContext MediaResult(false, error = "Invalid URL")
            }

            // Normalize resolution to numeric string Cobalt expects
            val qualityNum = when (resolution.uppercase().trim()) {
                "4K", "2160P" -> "2160"
                "1440P"       -> "1440"
                "1080P"       -> "1080"
                "720P"        -> "720"
                "480P"        -> "480"
                "360P"        -> "360"
                else          -> resolution.filter { it.isDigit() }.ifBlank { "1080" }
            }

            val bodyJson = JSONObject().apply {
                put("url",            cleanedUrl)
                put("downloadMode",   if (audioOnly) "audio" else "auto")
                put("videoQuality",   qualityNum)
                put("filenameStyle",  "pretty")
                put("audioFormat",    "mp3")
                put("audioBitrate",   "128")
                put("localProcessing","disabled")
                if (isYouTubeUrl(host)) {
                    put("youtubeVideoCodec",    "h264")
                    put("youtubeVideoContainer","mp4")
                }
            }.toString()

            val builder = Request.Builder()
                .url(baseUrl())
                .post(bodyJson.toRequestBody("application/json; charset=utf-8".toMediaType()))
                .header("Accept",       "application/json")
                .header("Content-Type", "application/json")
                .header("User-Agent",   "LinkShieldSandbox/2.4")

            if (BuildConfig.COBALT_API_KEY.isNotBlank()) {
                builder.header("Authorization", "Api-Key ${BuildConfig.COBALT_API_KEY}")
            }

            client.newCall(builder.build()).execute().use { response ->
                val body = response.body?.string().orEmpty()

                if (!response.isSuccessful) {
                    return@withContext MediaResult(
                        false,
                        error = when (response.code) {
                            400  -> "Cobalt rejected request (HTTP 400) — URL may be unsupported."
                            401, 403 -> "Cobalt auth denied (HTTP ${response.code})."
                            429  -> "Cobalt rate limit — try again shortly."
                            else -> "Cobalt HTTP ${response.code}."
                        }
                    )
                }
                if (body.isBlank()) {
                    return@withContext MediaResult(false, error = "Cobalt returned empty response.")
                }
                // Guard: wrong port returns HTML page
                if (body.trimStart().startsWith("<")) {
                    return@withContext MediaResult(
                        false,
                        error = "Cobalt returned HTML — check server URL/port in build.gradle."
                    )
                }

                val json = JSONObject(body)
                when (json.optString("status")) {
                    "tunnel", "redirect" -> {
                        val mediaUrl = json.optString("url")
                        if (mediaUrl.isBlank()) {
                            MediaResult(false, error = "Cobalt: no media URL in response.")
                        } else {
                            val ext      = if (audioOnly) "mp3" else "mp4"
                            val filename = json.optString("filename")
                                .ifBlank { "LinkShield_${System.currentTimeMillis()}.$ext" }
                            MediaResult(
                                success  = true,
                                url      = mediaUrl,
                                filename = filename,
                                mimeType = if (audioOnly) "audio/mpeg" else guessMime(filename)
                            )
                        }
                    }
                    "picker" -> {
                        val picker = json.optJSONArray("picker")
                        if (picker == null || picker.length() == 0) {
                            MediaResult(false, error = "Cobalt: empty picker.")
                        } else {
                            var chosen = picker.optJSONObject(0)
                            for (i in 0 until picker.length()) {
                                val item = picker.optJSONObject(i)
                                if (item?.optString("type") == "video") { chosen = item; break }
                            }
                            val url = chosen?.optString("url").orEmpty()
                            if (url.isBlank()) MediaResult(false, error = "Cobalt: picker had no URL.")
                            else MediaResult(
                                success  = true,
                                url      = url,
                                filename = "LinkShield_${System.currentTimeMillis()}.mp4",
                                mimeType = "video/mp4"
                            )
                        }
                    }
                    "local-processing" ->
                        MediaResult(false, error = "Cobalt requires local processing — configure server to return tunnel/redirect.")
                    "error" -> {
                        val errObj  = json.optJSONObject("error")
                        val code    = errObj?.optString("code").orEmpty()
                        val ctxObj  = errObj?.optJSONObject("context")
                        val service = ctxObj?.optString("service").orEmpty()
                        val limit   = ctxObj?.optInt("limit", -1)?.takeIf { it >= 0 }
                        val details = buildList {
                            if (service.isNotBlank()) add("service=$service")
                            if (limit != null) add("limit=$limit")
                        }.joinToString(", ")
                        MediaResult(
                            false,
                            error = "Cobalt error${if (code.isNotBlank()) " [$code]" else ""}${if (details.isNotBlank()) " ($details)" else ""}."
                        )
                    }
                    else -> MediaResult(
                        false,
                        error = "Unexpected Cobalt status: '${json.optString("status", "unknown")}'."
                    )
                }
            }
        } catch (_: SocketTimeoutException) {
            MediaResult(false, error = "Cobalt timed out — is server at ${BuildConfig.COBALT_BASE_URL} running?")
        } catch (e: Exception) {
            MediaResult(false, error = e.localizedMessage ?: "Network error.")
        }
    }

    private fun guessMime(filename: String): String =
        when (filename.substringAfterLast('.', "").lowercase()) {
            "mp3"  -> "audio/mpeg"
            "m4a"  -> "audio/mp4"
            "ogg"  -> "audio/ogg"
            "wav"  -> "audio/wav"
            "webm" -> "video/webm"
            "gif"  -> "image/gif"
            else   -> "video/mp4"
        }
}
