# LinkShield Sandbox - Corrected V4

Fixes included:
- Cobalt request uses current API-compatible fields; audioBitrate is sent as a string.
- Grabber passes the selected resolution to Cobalt.
- Cobalt 400/404/405 responses automatically try the legacy /api/json endpoint.
- Cobalt error responses preserve useful server details.
- VPN now fails closed if libtun2socks.so is absent; it will NOT establish a full-device TUN and black-hole all traffic.
- ZIP import workflow chooses the newest ZIP instead of an older alphabetically-first archive.

Important VPN note:
The repository currently does not contain libtun2socks.so. Therefore this build intentionally refuses to activate the full-device VPN until a real packet-routing engine is bundled. This prevents the reported "VPN on = internet jam" condition. The Tor SOCKS daemon alone cannot route Android's VPN TUN traffic.
