package com.linkshield.sandbox.ui.grabber

import android.content.Context
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

 data class GrabberInfoResult(
    val success: Boolean,
    val sourceUrl: String,
    val playableUrl: String?,
    val title: String,
    val extension: String,
    val mimeType: String,
    val thumbnail: String,
    val error: String? = null
)

data class GrabberDownloadResult(
    val success: Boolean,
    val error: String? = null
)

/**
 * Grabber backend. YouTube uses the local yt-dlp/FFmpeg engine; other
 * platforms retain the existing Cobalt extraction path.
 */
object GrabberEngine {

    suspend fun fetchMediaInfo(
        context: Context,
        pageUrl: String,
        resolution: String = "1080p",
        audioOnly: Boolean = false
    ): GrabberInfoResult = withContext(Dispatchers.IO) {
        if (YouTubeGrabber.isYouTube(pageUrl)) {
            return@withContext YouTubeGrabber.fetchInfo(context, pageUrl).fold(
                onSuccess = { info ->
                    GrabberInfoResult(
                        success = true,
                        sourceUrl = pageUrl,
                        playableUrl = null,
                        title = info.title,
                        extension = if (audioOnly) "mp3" else "mp4",
                        mimeType = if (audioOnly) "audio/mpeg" else "video/mp4",
                        thumbnail = info.thumbnail
                    )
                },
                onFailure = { e ->
                    GrabberInfoResult(
                        success = false,
                        sourceUrl = pageUrl,
                        playableUrl = null,
                        title = "",
                        extension = if (audioOnly) "mp3" else "mp4",
                        mimeType = if (audioOnly) "audio/mpeg" else "video/mp4",
                        thumbnail = "",
                        error = "YouTube extraction failed: ${e.message ?: "yt-dlp could not extract this video."}"
                    )
                }
            )
        }

        val repo = MediaExtractorRepository(context.applicationContext)
        val list = repo.extract(mediaUrl = pageUrl, title = "", audioOnly = audioOnly, resolution = resolution)
        if (list.isNotEmpty()) {
            val item = list.first()
            val ext = if (audioOnly || item.isAudio) "mp3" else "mp4"
            GrabberInfoResult(true, pageUrl, item.url, item.title, ext, item.mimeType, "")
        } else {
            GrabberInfoResult(false, pageUrl, null, "", "mp4", "video/mp4", "", "Unable to fetch media. Check the source URL.")
        }
    }

    suspend fun downloadMedia(
        context: Context,
        pageUrl: String,
        resolution: String = "1080p",
        audioOnly: Boolean = false,
        onProgress: (Float) -> Unit
    ): GrabberDownloadResult = withContext(Dispatchers.IO) {
        if (YouTubeGrabber.isYouTube(pageUrl)) {
            val result = YouTubeGrabber.download(context, pageUrl, resolution, audioOnly, onProgress)
            return@withContext GrabberDownloadResult(result.success, result.error)
        }

        val result = fetchMediaInfo(context, pageUrl, resolution, audioOnly)
        if (result.success && !result.playableUrl.isNullOrBlank()) {
            onProgress(1f)
            GrabberDownloadResult(true)
        } else {
            GrabberDownloadResult(false, result.error ?: "Media extraction failed")
        }
    }
}
