# YouTube engine fix

- YouTube URLs are now routed through youtubedl-android/yt-dlp instead of Cobalt.
- FFmpeg is enabled for MP4 stream merging and MP3 extraction.
- Facebook/Instagram/TikTok and other existing non-YouTube sources continue through the existing Cobalt path.
- YouTube metadata is fetched with yt-dlp; the Download button runs yt-dlp directly and publishes the result to Downloads/LinkShield using MediaStore.
- Cobalt is not called for YouTube, so a Cobalt HTTP 400 on YouTube cannot block the YouTube path.

Dependency: io.github.junkfood02.youtubedl-android 0.18.1 (library + ffmpeg).
