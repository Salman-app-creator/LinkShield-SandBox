package com.linkshield.sandbox.api

import android.app.DownloadManager
import android.content.Context
import android.net.Uri
import android.os.Environment
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaTypeOrNull
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONObject
import java.io.IOException
import java.util.concurrent.TimeUnit
import com.linkshield.sandbox.dns.DnsManager

class CobaltApiService(private val context: Context, dnsManager: DnsManager) {
    private val client = dnsManager.getClient().newBuilder()
        .connectTimeout(30, TimeUnit.SECONDS)
        .readTimeout(90, TimeUnit.SECONDS)
        .build()
    private val downloadManager = context.getSystemService(Context.DOWNLOAD_SERVICE) as DownloadManager

    companion object {
        const val API_BASE = "https://api.cobalt.tools/"
    }

    data class MediaResult(
        val success: Boolean,
        val url: String? = null,
        val filename: String? = null,
        val mimeType: String? = null,
        val error: String? = null,
        val isDirectDownload: Boolean = false
    )

    suspend fun fetchMediaUrl(
        pageUrl: String,
        downloadMode: String = "auto",
        videoQuality: String = "720"
    ): MediaResult = withContext(Dispatchers.IO) {
        if (pageUrl.isBlank()) {
            return@withContext MediaResult(false, error = "Media URL is empty")
        }

        // Cobalt v10+ uses POST / with the new request schema. The old public
        // /api/json endpoint was retired, so never send the legacy payload.
        val cobaltResult = runCatching {
            fetchFromCobalt(
                pageUrl = pageUrl,
                downloadMode = downloadMode,
                videoQuality = videoQuality
            )
        }.getOrElse { error ->
            MediaResult(false, error = "Cobalt unavailable: ${error.message ?: "request failed"}")
        }

        if (cobaltResult.success) {
            return@withContext cobaltResult
        }

        // The official hosted Cobalt instance is protected and is not a
        // reliable anonymous API for third-party apps. Fall back to the
        // yt-dlp engine already bundled with LinkShield so Grabber remains
        // functional when Cobalt rejects/blocks the request.
        runCatching {
            fetchWithYoutubeDl(
                pageUrl = pageUrl,
                downloadMode = downloadMode,
                videoQuality = videoQuality
            )
        }.getOrElse { fallbackError ->
            val primary = cobaltResult.error ?: "Cobalt request failed"
            MediaResult(
                false,
                error = "$primary. Local extractor also failed: ${fallbackError.message ?: "unknown error"}"
            )
        }
    }

    private fun fetchFromCobalt(
        pageUrl: String,
        downloadMode: String,
        videoQuality: String
    ): MediaResult {
        val jsonBody = JSONObject().apply {
            put("url", pageUrl)
            put("videoQuality", videoQuality)
            put("audioFormat", "mp3")
            put("downloadMode", if (downloadMode == "audio") "audio" else "auto")
            put("youtubeVideoCodec", "h264")
            put("disableMetadata", false)
            put("twitterGif", true)
            put("tiktokFullAudio", false)
        }

        val requestBuilder = Request.Builder()
            .url(runCatching { com.linkshield.sandbox.BuildConfig.COBALT_API_URL }.getOrDefault(API_BASE).trimEnd('/') + "/")
            .addHeader("Accept", "application/json")
            .addHeader("Content-Type", "application/json")
            .addHeader("User-Agent", "LinkShieldSandbox/2.1")
            .post(jsonBody.toString().toRequestBody("application/json".toMediaTypeOrNull()))

        // Optional key support for a private/self-hosted Cobalt instance.
        // The app can still use an unprotected instance without this header.
        val apiKey = runCatching { com.linkshield.sandbox.BuildConfig.COBALT_API_KEY }.getOrDefault("")
        if (apiKey.isNotBlank()) {
            requestBuilder.addHeader("Authorization", "Api-Key $apiKey")
        }

        return client.newCall(requestBuilder.build()).execute().use { response ->
            val body = response.body?.string().orEmpty()
            if (!response.isSuccessful) {
                val serverError = runCatching {
                    JSONObject(body).optJSONObject("error")?.optString("code").orEmpty()
                }.getOrDefault("")
                return MediaResult(
                    false,
                    error = if (serverError.isNotBlank()) {
                        "Cobalt API error: $serverError"
                    } else {
                        "Cobalt API error: HTTP ${response.code}"
                    }
                )
            }
            if (body.isBlank()) {
                return MediaResult(false, error = "Cobalt returned an empty response")
            }

            val json = JSONObject(body)
            when (json.optString("status")) {
                "redirect", "tunnel", "stream" -> {
                    val url = json.optString("url")
                    if (url.isBlank()) {
                        MediaResult(false, error = "Cobalt returned an empty media URL")
                    } else {
                        val filename = json.optString("filename").ifBlank { "download" }
                        MediaResult(
                            true,
                            url = url,
                            filename = filename,
                            mimeType = mimeFromFilename(filename, url),
                            isDirectDownload = json.optString("status") == "tunnel"
                        )
                    }
                }
                "picker" -> {
                    val picker = json.optJSONArray("picker")
                    val first = picker?.optJSONObject(0)
                    val url = first?.optString("url").orEmpty()
                    if (url.isBlank()) {
                        MediaResult(false, error = "Cobalt returned no selectable media")
                    } else {
                        MediaResult(true, url = url, filename = "download.mp4", mimeType = "video/mp4")
                    }
                }
                "local-processing" -> {
                    MediaResult(false, error = "Cobalt requires local media processing")
                }
                "error" -> {
                    val errorObject = json.optJSONObject("error")
                    MediaResult(
                        false,
                        error = errorObject?.optString("code")?.ifBlank { null }
                            ?: "Cobalt rejected the URL"
                    )
                }
                else -> MediaResult(false, error = "Unexpected Cobalt response")
            }
        }
    }

    private fun fetchWithYoutubeDl(
        pageUrl: String,
        downloadMode: String,
        videoQuality: String
    ): MediaResult {
        runCatching {
            com.yausername.youtubedl_android.YoutubeDL.getInstance().init(context.applicationContext)
        }

        val request = com.yausername.youtubedl_android.YoutubeDLRequest(pageUrl).apply {
            addOption("--no-playlist")
            addOption("--socket-timeout", "30")
            if (downloadMode == "audio") {
                addOption("-f", "bestaudio/best")
            } else {
                val height = videoQuality.toIntOrNull() ?: 720
                addOption("-f", "best[height<=$height]/best")
            }
        }

        val info = com.yausername.youtubedl_android.YoutubeDL
            .getInstance()
            .getInfo(request)

        val url = info.url?.takeIf { it.isNotBlank() }
            ?: throw IOException("Extractor returned no direct media URL")
        val filename = (info.title ?: "LinkShield_download")
            .replace(Regex("[\\\\/:*?\"<>|]"), "_")
            .take(160)
            .ifBlank { "LinkShield_download" }

        return MediaResult(
            true,
            url = url,
            filename = filename + if (downloadMode == "audio") ".mp3" else ".mp4",
            mimeType = if (downloadMode == "audio") "audio/mpeg" else "video/mp4",
            isDirectDownload = true
        )
    }

    fun startDownload(url: String, filename: String, mimeType: String = "video/mp4"): Long {
        val safeName = filename.ifBlank { "LinkShield_download" }
        val request = DownloadManager.Request(Uri.parse(url))
            .setTitle(safeName)
            .setDescription("Downloading via LinkShield")
            .setMimeType(mimeType)
            .setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED)
            .setDestinationInExternalPublicDir(Environment.DIRECTORY_DOWNLOADS, "LinkShield/$safeName")
            .setAllowedOverMetered(true)
            .setAllowedOverRoaming(true)
        return downloadManager.enqueue(request)
    }

    fun isDirectFileLink(url: String): Boolean {
        val clean = url.substringBefore("?").substringBefore("#").lowercase()
        return listOf(".mp4", ".mp3", ".m4a", ".webm", ".mkv", ".pdf", ".zip", ".jpg", ".png").any { clean.endsWith(it) }
    }

    private fun mimeFromFilename(filename: String, url: String): String {
        val value = (filename + " " + url).lowercase()
        return when {
            ".mp3" in value -> "audio/mpeg"
            ".m4a" in value -> "audio/mp4"
            ".aac" in value -> "audio/aac"
            ".ogg" in value -> "audio/ogg"
            ".webm" in value -> "video/webm"
            ".m3u8" in value -> "application/vnd.apple.mpegurl"
            ".mpd" in value -> "application/dash+xml"
            ".mp4" in value -> "video/mp4"
            else -> "video/mp4"
        }
    }
}
