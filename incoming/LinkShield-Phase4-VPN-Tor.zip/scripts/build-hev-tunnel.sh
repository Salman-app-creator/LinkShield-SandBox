#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
HEV_VERSION="2.17.1"
HEV_DIR="$ROOT/app/build/hev-socks5-tunnel"
NDK_BUILD="${ANDROID_NDK_HOME:-${ANDROID_NDK_ROOT:-}}/ndk-build"
if [[ ! -x "$NDK_BUILD" ]]; then
  echo "Android NDK not found. Set ANDROID_NDK_HOME/ANDROID_NDK_ROOT." >&2
  exit 1
fi
if [[ ! -d "$HEV_DIR" ]]; then
  git clone --depth 1 --branch "$HEV_VERSION" --recursive \
    https://github.com/heiher/hev-socks5-tunnel.git "$HEV_DIR"
fi
cat > "$HEV_DIR/Application.mk" <<APP
APP_OPTIM := release
APP_PLATFORM := android-29
APP_ABI := armeabi-v7a arm64-v8a x86 x86_64
APP_CFLAGS := -O3 -DPKGNAME=com/linkshield/sandbox/vpn -DCLSNAME=HevTunnelBridge
APP_SUPPORT_FLEXIBLE_PAGE_SIZES := true
NDK_TOOLCHAIN_VERSION := clang
APP
"$NDK_BUILD" -C "$HEV_DIR" NDK_PROJECT_PATH="$HEV_DIR" \
  APP_BUILD_SCRIPT="$HEV_DIR/Android.mk" NDK_APPLICATION_MK="$HEV_DIR/Application.mk" \
  NDK_OUT="$ROOT/app/build/hev-obj" NDK_LIBS_OUT="$ROOT/app/build/hev-libs"
mkdir -p "$ROOT/app/src/main/jniLibs"
cp -R "$ROOT/app/build/hev-libs/." "$ROOT/app/src/main/jniLibs/"
echo "Hev tunnel libraries copied to app/src/main/jniLibs"
