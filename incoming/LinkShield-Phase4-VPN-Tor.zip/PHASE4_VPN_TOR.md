# LinkShield Phase 4 — Real VPN/Tor routing

## Goal

Replace the previous false-positive VPN path with an actual Android `VpnService` -> TUN -> HevSocks5Tunnel -> Tor SOCKS5 data path.

## Changes

1. Added `HevTunnelBridge.kt`, a JNI wrapper matching the upstream Hev Android API.
2. Gradle pins HevSocks5Tunnel **2.17.1** and builds it with `ndk-build` for `armeabi-v7a`, `arm64-v8a`, `x86`, and `x86_64`.
3. `TorVpnService` now creates the TUN interface and starts Hev only after Tor's local SOCKS port is ready.
4. The app is excluded from its own VPN using `Builder.addDisallowedApplication(packageName)` to prevent the Tor/Hev control sockets from looping back into the TUN.
5. `CONNECTED` is published only after Hev reports that the native tunnel is running. Missing native routing is a hard failure instead of a fake connected state.
6. Hev is stopped before the TUN file descriptor is closed to avoid native teardown races.
7. The VPN ViewModel now observes service-backed state instead of optimistically showing `CONNECTED` immediately after starting the service.
8. Unexpected native tunnel termination is detected and surfaced as an error.

## Data path

`Android apps -> LinkShield VpnService TUN -> HevSocks5Tunnel -> 127.0.0.1:9050 -> Tor -> Internet`

## Build requirement

Phase 4 needs an Android NDK because the upstream Hev native library is built during Gradle `preBuild`. The ZIP intentionally does not ship an unverified native binary.

## Testing requirement

A device smoke test must verify actual external traffic and DNS behavior. A listening Tor SOCKS port alone is not proof that device traffic is traversing the VPN.

## UI freeze

No Compose/VPN screen layout file was changed. Only backend/service/native build/state wiring was changed.
