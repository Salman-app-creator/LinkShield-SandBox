package com.linkshield.sandbox.vpn


/**
 * Thin JNI contract for the upstream hev-socks5-tunnel Android build.
 * The native library is built from the pinned upstream tag by Gradle.
 */
object HevTunnelBridge {
    private var loadError: Throwable? = null

    init {
        try {
            System.loadLibrary("hev-socks5-tunnel")
        } catch (t: Throwable) {
            loadError = t
        }
    }

    fun isAvailable(): Boolean = loadError == null

    fun loadError(): Throwable? = loadError

    private external fun TProxyStartService(configPath: String, fd: Int): Boolean
    private external fun TProxyStopService(): Boolean
    private external fun TProxyIsRunning(): Boolean
    private external fun TProxyGetStats(): LongArray

    @Synchronized
    fun start(configPath: String, tunFd: Int): Boolean {
        check(isAvailable()) { "Hev tunnel native library is unavailable: ${loadError?.message}" }
        return TProxyStartService(configPath, tunFd)
    }

    @Synchronized
    fun stop(): Boolean {
        if (!isAvailable()) return false
        return TProxyStopService()
    }

    fun isRunning(): Boolean = isAvailable() && TProxyIsRunning()

    data class Stats(
        val txPackets: Long,
        val txBytes: Long,
        val rxPackets: Long,
        val rxBytes: Long
    )

    fun stats(): Stats {
        val s = if (isAvailable()) TProxyGetStats() else LongArray(0)
        return Stats(
            txPackets = s.getOrElse(0) { 0L },
            txBytes = s.getOrElse(1) { 0L },
            rxPackets = s.getOrElse(2) { 0L },
            rxBytes = s.getOrElse(3) { 0L }
        )
    }
}
