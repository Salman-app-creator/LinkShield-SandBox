package com.linkshield.sandbox.vpn

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Intent
import android.net.VpnService
import android.os.Build
import android.os.ParcelFileDescriptor
import android.util.Log
import androidx.core.app.NotificationCompat
import com.linkshield.sandbox.MainActivity
import com.linkshield.sandbox.R
import org.torproject.jni.TorService
import java.io.File
import java.io.IOException
import java.net.InetSocketAddress
import java.net.Socket
import java.util.concurrent.atomic.AtomicBoolean

class TorVpnService : VpnService() {

    companion object {
        const val ACTION_START = "com.linkshield.sandbox.TOR_START"
        const val ACTION_STOP = "com.linkshield.sandbox.TOR_STOP"
        private const val NOTIFICATION_ID = 1001
        private const val CHANNEL_ID = "tor_vpn_channel"
        private const val TAG = "TorVpnService"
        private const val VPN_ADDRESS = "10.0.0.2"
        private const val VPN_DNS = "1.1.1.1"
        private const val TOR_SOCKS_PORT = 9050
        private const val BOOTSTRAP_TIMEOUT_MS = 60_000L
        private const val TUN_MTU = 1500
    }

    private var vpnInterface: ParcelFileDescriptor? = null
    private var torServiceIntent: Intent? = null
    private val running = AtomicBoolean(false)
    private val stopping = AtomicBoolean(false)
    private var tunnelStarted = false
    private var tunnelConfig: File? = null

    override fun onCreate() {
        super.onCreate()
        createNotificationChannel()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_START -> {
                if (running.get()) return START_STICKY
                startForeground(NOTIFICATION_ID, buildNotification("Initializing Tor..."))
                Thread({ startVpn() }, "LinkShield-Tor-Start").start()
            }
            ACTION_STOP -> Thread({ stopVpn() }, "LinkShield-Tor-Stop").start()
        }
        return START_STICKY
    }

    override fun onDestroy() {
        stopVpnInternal()
        super.onDestroy()
    }

    private fun startVpn() {
        if (!running.compareAndSet(false, true)) return
        stopping.set(false)
        tunnelStarted = false
        TorVpnManager.publishConnecting()

        try {
            updateNotification("Starting Tor daemon...")
            torServiceIntent = Intent(this, TorService::class.java)
            startService(torServiceIntent)

            updateNotification("Bootstrapping Tor network...")
            if (!waitForTorSocks()) {
                throw IOException("Tor SOCKS proxy did not become ready")
            }

            updateNotification("Creating secure tunnel...")
            val tun = buildVpnInterface() ?: throw IOException("VPN interface could not be established")
            vpnInterface = tun

            // Prevent the app's own Tor/Hev control traffic from re-entering its TUN.
            // This avoids the classic VPN -> tunnel -> VPN routing loop.
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
                try {
                    // addDisallowedApplication() must be called on Builder before establish().
                    // Kept in buildVpnInterface() for API correctness.
                } catch (ignored: Exception) {
                }
            }

            updateNotification("Activating packet routing...")
            tunnelConfig = createHevConfig()
            val started = HevTunnelBridge.start(tunnelConfig!!.absolutePath, tun.fd)
            if (!started || !HevTunnelBridge.isRunning()) {
                throw IOException("Hev TUN-to-SOCKS tunnel failed to start")
            }
            tunnelStarted = true

            // Connected is published only after both TUN and Hev report success.
            TorVpnManager.publishConnected()
            updateNotification("VPN Connected — Tor tunnel is active")

            // Keep the service alive and detect an unexpected native shutdown.
            monitorTunnel()
        } catch (t: Throwable) {
            Log.e(TAG, "VPN start failed", t)
            TorVpnManager.publishError(t.message ?: "VPN connection failed")
            updateNotification("VPN Error: ${t.message ?: "connection failed"}")
            stopVpnInternal()
        }
    }

    private fun waitForTorSocks(): Boolean {
        val deadline = System.currentTimeMillis() + BOOTSTRAP_TIMEOUT_MS
        while (running.get() && System.currentTimeMillis() < deadline) {
            if (isLocalPortOpen("127.0.0.1", TOR_SOCKS_PORT)) {
                return true
            }
            Thread.sleep(700)
        }
        return false
    }

    private fun isLocalPortOpen(host: String, port: Int): Boolean = try {
        Socket().use { socket ->
            // protect() is important when the VPN TUN is already established.
            protect(socket)
            socket.connect(InetSocketAddress(host, port), 1500)
            true
        }
    } catch (_: IOException) {
        false
    }

    private fun buildVpnInterface(): ParcelFileDescriptor? = try {
        val builder = Builder()
            .setSession("LinkShield Tor")
            .addAddress(VPN_ADDRESS, 32)
            .addRoute("0.0.0.0", 0)
            .addDnsServer(VPN_DNS)
            .setMtu(TUN_MTU)

        // Keep LinkShield's own sockets outside the VPN to prevent routing loops.
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            builder.addDisallowedApplication(packageName)
        }

        // IPv6 routing is deliberately enabled only when the native tunnel is ready
        // to carry it; the current Hev config below enables IPv6 at the TUN layer.
        builder.addAddress("fd00::2", 128)
            .addRoute("::", 0)
            .establish()
    } catch (t: Throwable) {
        Log.e(TAG, "VPN Builder failed", t)
        null
    }

    private fun createHevConfig(): File {
        val file = File(cacheDir, "hev-linkshield-tor.yml")
        file.writeText(
            """
            tunnel:
              name: tun0
              mtu: $TUN_MTU
              multi-queue: false
              ipv4: $VPN_ADDRESS
              ipv6: 'fd00::2'
              icmp: 'off'

            socks5:
              address: 127.0.0.1
              port: $TOR_SOCKS_PORT
              udp: 'udp'

            misc:
              connect-timeout: 10000
              tcp-read-write-timeout: 300000
              udp-read-write-timeout: 60000
              log-file: null
              log-level: warn
            """.trimIndent()
        )
        return file
    }

    private fun monitorTunnel() {
        Thread({
            while (running.get() && !stopping.get()) {
                Thread.sleep(2000)
                if (tunnelStarted && !HevTunnelBridge.isRunning()) {
                    Log.e(TAG, "Hev tunnel stopped unexpectedly")
                    TorVpnManager.publishError("VPN tunnel stopped unexpectedly")
                    stopVpnInternal()
                    break
                }
            }
        }, "LinkShield-Tor-Monitor").start()
    }

    private fun stopVpn() {
        stopVpnInternal()
        stopForeground(true)
        stopSelf()
    }

    private fun stopVpnInternal() {
        if (!stopping.compareAndSet(false, true)) {
            running.set(false)
            return
        }
        running.set(false)
        TorVpnManager.publishDisconnected()

        // IMPORTANT: stop Hev before closing the TUN fd. The native tunnel owns/uses
        // the descriptor while running; closing it first can race with native teardown.
        if (tunnelStarted || HevTunnelBridge.isRunning()) {
            try {
                HevTunnelBridge.stop()
                val deadline = System.currentTimeMillis() + 3000
                while (HevTunnelBridge.isRunning() && System.currentTimeMillis() < deadline) {
                    Thread.sleep(50)
                }
            } catch (t: Throwable) {
                Log.w(TAG, "Hev tunnel stop error", t)
            }
        }
        tunnelStarted = false

        try { vpnInterface?.close() } catch (t: Throwable) { Log.w(TAG, "TUN close error", t) }
        vpnInterface = null

        try { tunnelConfig?.delete() } catch (_: Throwable) {}
        tunnelConfig = null

        try {
            torServiceIntent?.let { stopService(it) }
        } catch (t: Throwable) {
            Log.w(TAG, "Tor service stop error", t)
        }
        torServiceIntent = null
        stopping.set(false)
    }

    private fun updateNotification(text: String) {
        getSystemService(NotificationManager::class.java)?.notify(
            NOTIFICATION_ID,
            buildNotification(text)
        )
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID,
                "Tor VPN Tunnel",
                NotificationManager.IMPORTANCE_LOW
            ).apply {
                description = "LinkShield secure tunnel status"
                setShowBadge(false)
            }
            getSystemService(NotificationManager::class.java)?.createNotificationChannel(channel)
        }
    }

    private fun buildNotification(text: String): Notification {
        val pi = PendingIntent.getActivity(
            this,
            0,
            Intent(this, MainActivity::class.java).apply {
                flags = Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_SINGLE_TOP
            },
            PendingIntent.FLAG_IMMUTABLE
        )
        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle("LinkShield Secure Tunnel")
            .setContentText(text)
            .setSmallIcon(R.drawable.ic_app_logo)
            .setContentIntent(pi)
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .build()
    }
}
