package com.linkshield.sandbox.ui.vpn

import android.app.Application
import android.content.Intent
import android.net.VpnService
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.linkshield.sandbox.vpn.TorVpnManager
import com.linkshield.sandbox.vpn.VpnConnectionState
import com.linkshield.sandbox.vpn.isActive
import com.linkshield.sandbox.vpn.isBusy
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.launch

class VpnViewModel(application: Application) : AndroidViewModel(application) {

    private val torManager = TorVpnManager(application)
    val vpnState: StateFlow<VpnConnectionState> = TorVpnManager.state

    fun getVpnPermissionIntent(): Intent? = VpnService.prepare(getApplication())

    fun onToggleVpn(onPermissionRequired: (Intent) -> Unit) {
        val current = vpnState.value
        if (current.isBusy) return
        if (current.isActive) {
            disconnect()
            return
        }
        val permissionIntent = getVpnPermissionIntent()
        if (permissionIntent != null) onPermissionRequired(permissionIntent)
        else onPermissionGranted()
    }

    fun onPermissionGranted() {
        viewModelScope.launch {
            val result = torManager.connect()
            if (result.isFailure) {
                TorVpnManager.publishError(
                    result.exceptionOrNull()?.message ?: "Connection failed"
                )
            }
        }
    }

    fun disconnect() {
        TorVpnManager.publishDisconnected()
        viewModelScope.launch { torManager.disconnect() }
    }

    fun clearError() {
        if (vpnState.value is VpnConnectionState.Error) {
            TorVpnManager.publishDisconnected()
        }
    }
}
