package com.linkshield.sandbox.vpn

import android.content.Context
import android.content.Intent
import android.net.VpnService
import android.os.Build
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

class TorVpnManager(private val context: Context) {

    companion object {
        private val _state = MutableStateFlow<VpnConnectionState>(VpnConnectionState.Disconnected)
        val state: StateFlow<VpnConnectionState> = _state.asStateFlow()

        @Volatile
        private var _isConnected = false

        fun setConnected(value: Boolean) {
            _isConnected = value
            if (!value && _state.value is VpnConnectionState.Connected) {
                _state.value = VpnConnectionState.Disconnected
            }
        }

        fun publishConnecting() {
            _isConnected = false
            _state.value = VpnConnectionState.Connecting
        }

        fun publishConnected() {
            _isConnected = true
            _state.value = VpnConnectionState.Connected()
        }

        fun publishDisconnected() {
            _isConnected = false
            _state.value = VpnConnectionState.Disconnected
        }

        fun publishError(message: String) {
            _isConnected = false
            _state.value = VpnConnectionState.Error(message)
        }
    }

    fun connect(): Result<Unit> = try {
        if (VpnService.prepare(context) != null) {
            Result.failure(SecurityException("VPN permission required"))
        } else {
            val intent = Intent(context, TorVpnService::class.java).apply {
                action = TorVpnService.ACTION_START
            }
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                context.startForegroundService(intent)
            } else {
                context.startService(intent)
            }
            Result.success(Unit)
        }
    } catch (t: Throwable) {
        publishError(t.message ?: "Unable to start VPN service")
        Result.failure(t)
    }

    fun disconnect(): Result<Unit> = try {
        val intent = Intent(context, TorVpnService::class.java).apply {
            action = TorVpnService.ACTION_STOP
        }
        context.stopService(intent)
        publishDisconnected()
        Result.success(Unit)
    } catch (t: Throwable) {
        publishError(t.message ?: "Unable to stop VPN service")
        Result.failure(t)
    }

    fun isConnected(): Boolean = _isConnected
}
