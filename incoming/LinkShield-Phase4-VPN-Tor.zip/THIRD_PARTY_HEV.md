# Phase 4 — HevSocks5Tunnel third-party component

LinkShield Phase 4 uses the upstream `heiher/hev-socks5-tunnel` project as the TUN-to-SOCKS5 bridge.

- Pinned version: **2.17.1**
- License: **MIT**
- Upstream: https://github.com/heiher/hev-socks5-tunnel
- Android build: `ndk-build`, all four Android ABIs.

The repository does not contain opaque precompiled `.so` files. Gradle fetches the pinned source tag and builds the JNI shared library during `preBuild`.
