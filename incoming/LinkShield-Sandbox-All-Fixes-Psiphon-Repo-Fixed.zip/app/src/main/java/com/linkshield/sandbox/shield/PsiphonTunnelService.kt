package com.linkshield.sandbox.shield

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Intent
import android.os.Build
import android.os.IBinder
import android.util.Log
import androidx.core.app.NotificationCompat
import ca.psiphon.PsiphonTunnel

/**
 * Keeps the Psiphon tunnel alive in the background. The service uses Psiphon's
 * local HTTP proxy/port-forward mode so the app's WebViews can be routed through
 * the tunnel without claiming to be a device-wide VPN.
 */
class PsiphonTunnelService : Service(), PsiphonTunnel.HostService {
    private var tunnel: PsiphonTunnel? = null

    override fun onCreate() {
        super.onCreate()
        createChannel()
        startForeground(NOTIFICATION_ID, notification("Connecting to Psiphon…"))
        tunnel = PsiphonTunnel.newPsiphonTunnel(this)
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_STOP -> stopTunnel()
            else -> startTunnel()
        }
        return START_STICKY
    }

    private fun startTunnel() {
        val instance = tunnel ?: PsiphonTunnel.newPsiphonTunnel(this).also { tunnel = it }
        Thread({
            runCatching { instance.startTunneling("") }
                .onFailure {
                    Log.e(TAG, "Psiphon failed to start", it)
                    updateNotification("Psiphon connection failed")
                }
        }, "PsiphonStart").start()
    }

    private fun stopTunnel() {
        val instance = tunnel
        Thread({ instance?.stop() }, "PsiphonStop").start()
        stopForeground(STOP_FOREGROUND_REMOVE)
        stopSelf()
    }

    override fun onDestroy() {
        tunnel?.let { instance -> Thread({ instance.stop() }, "PsiphonDestroy").start() }
        tunnel = null
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun getContext() = this

    override fun getPsiphonConfig(): String = try {
        resources.openRawResource(com.linkshield.sandbox.R.raw.psiphon_config)
            .bufferedReader(Charsets.UTF_8).use { it.readText() }
    } catch (e: Exception) {
        Log.e(TAG, "Unable to load Psiphon config", e)
        ""
    }

    override fun onListeningHttpProxyPort(port: Int) {
        if (port <= 0) return
        getSharedPreferences(PREFS, MODE_PRIVATE).edit().putInt(KEY_HTTP_PORT, port).apply()
        ShieldManager(this).applyPsiphonHttpProxy(port)
        updateNotification("Psiphon connected • proxy :$port")
    }

    override fun onConnected() {
        updateNotification("Psiphon tunnel connected")
        getSharedPreferences(PREFS, MODE_PRIVATE).edit().putBoolean(KEY_CONNECTED, true).apply()
    }

    override fun onConnecting() { updateNotification("Connecting to Psiphon…") }

    override fun onExiting() {
        getSharedPreferences(PREFS, MODE_PRIVATE).edit().putBoolean(KEY_CONNECTED, false).apply()
    }

    override fun onDiagnosticMessage(message: String) { Log.d(TAG, message) }

    override fun onSocksProxyPortInUse(port: Int) {}
    override fun onHttpProxyPortInUse(port: Int) {}

    private fun updateNotification(text: String) {
        getSystemService(NotificationManager::class.java)?.notify(NOTIFICATION_ID, notification(text))
    }

    private fun notification(text: String): Notification =
        NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(com.linkshield.sandbox.R.drawable.ic_app_logo)
            .setContentTitle("LinkShield Shield")
            .setContentText(text)
            .setOngoing(true)
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .build()

    private fun createChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            getSystemService(NotificationManager::class.java)?.createNotificationChannel(
                NotificationChannel(CHANNEL_ID, "LinkShield Shield", NotificationManager.IMPORTANCE_LOW)
            )
        }
    }

    companion object {
        const val ACTION_START = "com.linkshield.sandbox.shield.START_PSIPHON"
        const val ACTION_STOP = "com.linkshield.sandbox.shield.STOP_PSIPHON"
        private const val CHANNEL_ID = "linkshield_psiphon"
        private const val NOTIFICATION_ID = 4101
        private const val TAG = "PsiphonTunnelService"
        private const val PREFS = "psiphon_state"
        private const val KEY_HTTP_PORT = "http_proxy_port"
        private const val KEY_CONNECTED = "connected"
    }
}
