package com.linkshield.sandbox.license

import android.content.Context
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.distinctUntilChanged
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch

private val Context.proDataStore by preferencesDataStore(name = "linkshield_pro_state")

/** Single reactive source of truth for the Pro activation state. */
class ProStateRepository(private val context: Context, legacyPro: Boolean = false) {
    private val isProKey = booleanPreferencesKey("is_pro_user")

    init {
        if (legacyPro) {
            CoroutineScope(SupervisorJob() + Dispatchers.IO).launch { setProUser(true) }
        }
    }

    val isProUser: Flow<Boolean> = context.applicationContext.proDataStore.data
        .map { it[isProKey] ?: false }
        .distinctUntilChanged()

    suspend fun setProUser(value: Boolean) {
        context.applicationContext.proDataStore.edit { it[isProKey] = value }
    }
}
