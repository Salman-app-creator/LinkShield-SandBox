package com.linkshield.sandbox.ui.grabber

// REPO PATH: app/src/main/java/com/linkshield/sandbox/ui/grabber/LinkShieldGrabberScreen.kt
// ← REPLACE existing file
//
// ROOT CAUSE FIX — Trial period showing even after license activation:
//
// OLD signature:
//   fun LinkShieldGrabberScreen(onBackToBrowser, onUpgradeClick)
//   → Screen was creating its own LicenseManager() instance LOCALLY
//   → This local instance never got refreshed after Pro activation
//   → Result: Always showed "trial" even with valid key
//
// NEW signature:
//   fun LinkShieldGrabberScreen(onBackToBrowser, onUpgradeClick, isProUser, trialDaysLeft)
//   → Live license state flows IN from UnblockShieldScreen (which refreshes on tab switch)
//   → Screen just reads the passed-in values — no stale local instance
//
// UI_FREEZE_CONTRACT respected:
//   • No new @Composable functions
//   • No layout / color / typography changes
//   • Only state wiring corrected

import android.app.DownloadManager
import android.content.Context
import android.widget.Toast
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Download
import androidx.compose.material.icons.filled.PlayCircle
import androidx.compose.material.icons.filled.Upgrade
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.linkshield.sandbox.api.CobaltApiService
import com.linkshield.sandbox.ui.grabber.GrabberEngine
import com.linkshield.sandbox.ui.grabber.MediaFormat
import com.linkshield.sandbox.ui.grabber.DownloadState
import kotlinx.coroutines.flow.collect
import com.linkshield.sandbox.dns.DnsManager
import kotlinx.coroutines.launch
import coil.compose.AsyncImage
import coil.request.ImageRequest
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.graphics.Color
import androidx.compose.foundation.background

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun LinkShieldGrabberScreen(
    onBackToBrowser: () -> Unit,
    onUpgradeClick: () -> Unit,
    // ── FIX: receive live license state from parent (UnblockShieldScreen) ──
    isProUser: Boolean = false,
    trialDaysLeft: Int = 7
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()

    var inputUrl by rememberSaveable { mutableStateOf("") }
    var audioOnly by rememberSaveable { mutableStateOf(false) }
    var selectedResolution by rememberSaveable { mutableStateOf("1080p") }
    var fetched by rememberSaveable { mutableStateOf(false) }
    var isLoading by rememberSaveable { mutableStateOf(false) }
    var errorMsg by rememberSaveable { mutableStateOf<String?>(null) }

    // Download result state
    var mediaUrl by rememberSaveable { mutableStateOf("") }
    var mediaFilename by rememberSaveable { mutableStateOf("") }
    var mediaMime by rememberSaveable { mutableStateOf("video/mp4") }
    var thumbnailUrl by rememberSaveable { mutableStateOf("") }

    val resolutions = listOf("360p", "480p", "720p", "1080p", "4K")

    // ── FIX: use passed-in isProUser instead of creating stale local instance
    val dnsManager = remember { DnsManager(context) }
    // DnsManager pro flag is synced by LicenseManager.activatePro()
    // isProUser from parent is the canonical source; dnsManager is fallback
    val effectivelyPro = isProUser || dnsManager.isProUser()
    val remainingDownloads = if (effectivelyPro) Int.MAX_VALUE else dnsManager.getRemainingDownloads()

    // Cobalt API service (lazy-init, single instance)
    val cobaltService = remember {
        CobaltApiService(context, DnsManager(context.applicationContext))
    }

    Column(
        Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 14.dp, vertical = 10.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        // Title row
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = onBackToBrowser, modifier = Modifier.size(40.dp)) {
                Icon(Icons.Default.ArrowBack, "Back to browser")
            }
            Text(
                "Grabber",
                style = MaterialTheme.typography.titleLarge,
                fontWeight = FontWeight.Bold,
                modifier = Modifier.weight(1f)
            )
        }

        // ── License badge — now reflects actual Pro status ──────────────────
        Card(
            Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(14.dp),
            colors = CardDefaults.cardColors(
                containerColor = MaterialTheme.colorScheme.tertiaryContainer
            )
        ) {
            Row(
                Modifier.fillMaxWidth().padding(12.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(Modifier.weight(1f)) {
                    if (effectivelyPro) {
                        // FIX: this now correctly shows PRO after key activation
                        Text(
                            "👑 PRO Unlimited",
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.primary
                        )
                    } else if (trialDaysLeft > 0) {
                        Text(
                            "[ $remainingDownloads Free Downloads Remaining ]",
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            "Trial: $trialDaysLeft days left • Upgrade for unlimited",
                            fontSize = 12.sp
                        )
                    } else {
                        Text(
                            "Trial Ended",
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.error
                        )
                        Text("Upgrade to Pro for unlimited downloads", fontSize = 12.sp)
                    }
                }
                if (!effectivelyPro) {
                    TextButton(onClick = onUpgradeClick) {
                        Icon(Icons.Default.Upgrade, null, Modifier.size(17.dp))
                        Spacer(Modifier.width(3.dp))
                        Text("Upgrade")
                    }
                }
            }
        }

        // URL input
        OutlinedTextField(
            value = inputUrl,
            onValueChange = {
                inputUrl = it
                fetched = false
                errorMsg = null
            },
            modifier = Modifier.fillMaxWidth(),
            singleLine = true,
            placeholder = { Text("Paste video link here...") },
            leadingIcon = { Icon(Icons.Default.PlayCircle, null) },
            trailingIcon = {
                if (inputUrl.isNotEmpty()) {
                    IconButton(onClick = { inputUrl = ""; fetched = false }) {
                        Icon(Icons.Default.ArrowBack, "Clear", Modifier.size(18.dp))
                    }
                }
            },
            shape = RoundedCornerShape(12.dp),
            isError = errorMsg != null
        )
        errorMsg?.let {
            Text(it, color = MaterialTheme.colorScheme.error, fontSize = 12.sp)
        }

        // Preview area with thumbnail
        Card(
            Modifier.fillMaxWidth().height(180.dp),
            shape = RoundedCornerShape(14.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
        ) {
            Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                if (thumbnailUrl.isNotBlank()) {
                    AsyncImage(
                        model = ImageRequest.Builder(context).data(thumbnailUrl).crossfade(true).build(),
                        contentDescription = "Thumbnail",
                        modifier = Modifier.fillMaxSize(),
                        contentScale = ContentScale.Crop
                    )
                    Box(
                        Modifier.fillMaxSize().background(Color.Black.copy(alpha = 0.5f), RoundedCornerShape(14.dp)),
                        contentAlignment = Alignment.BottomStart
                    ) {
                        Column(Modifier.padding(10.dp)) {
                            Text(
                                if (fetched) "✅ Ready to download" else "🎬 Tap Fetch",
                                color = Color.White, fontWeight = FontWeight.SemiBold, fontSize = 13.sp
                            )
                            if (fetched && mediaFilename.isNotBlank())
                                Text(mediaFilename, fontSize = 11.sp, color = Color.White.copy(alpha = 0.8f))
                        }
                    }
                } else {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Icon(Icons.Default.PlayCircle, null, Modifier.size(54.dp), tint = MaterialTheme.colorScheme.primary)
                        Spacer(Modifier.height(8.dp))
                        Text(
                            when {
                                isLoading -> "Fetching media..."
                                fetched -> "Ready to download"
                                else -> "Paste URL and tap Fetch"
                            },
                            fontWeight = FontWeight.SemiBold
                        )
                        if (fetched && mediaFilename.isNotBlank())
                            Text(mediaFilename, fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                }
            }
        }

        Text("Options:", fontWeight = FontWeight.Bold)

        Row(verticalAlignment = Alignment.CenterVertically) {
            Checkbox(checked = audioOnly, onCheckedChange = { audioOnly = it })
            Text("Audio Only (MP3)", fontSize = 13.sp)
        }

        if (!audioOnly) {
            Text(
                "Select Resolution:",
                fontSize = 12.sp,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            Row(
                Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                resolutions.forEach { res ->
                    FilterChip(
                        selected = (selectedResolution == res),
                        onClick  = { selectedResolution = res },
                        label    = { Text(res, fontSize = 12.sp) },
                        shape    = RoundedCornerShape(8.dp)
                    )
                }
            }
        }

        if (fetched) {
            Text(
                "Quality: ${if (audioOnly) "MP3 Audio" else "$selectedResolution • MP4"}",
                color = MaterialTheme.colorScheme.primary,
                fontWeight = FontWeight.SemiBold
            )
        }

        Spacer(Modifier.height(4.dp))

        // Fetch / Download button
        Button(
            onClick = {
                if (!fetched) {
                    // ── FETCH phase ─────────────────────────────────────────
                    if (inputUrl.isBlank()) {
                        errorMsg = "Enter a URL first"
                        return@Button
                    }
                    if (!effectivelyPro && remainingDownloads <= 0) {
                        errorMsg = "Download limit reached. Upgrade to Pro."
                        return@Button
                    }
                    isLoading = true
                    errorMsg  = null

                    scope.launch {
                        thumbnailUrl = extractYoutubeThumbnail(inputUrl)
                        val result = GrabberEngine.fetchMetadata(inputUrl)
                        isLoading = false
                        result.fold(
                            onSuccess = { metadata ->
                                mediaFilename = metadata.title.ifBlank { "LinkShield_download" }
                                mediaMime = if (audioOnly) "audio/mpeg" else "video/mp4"
                                fetched = true
                                if (!effectivelyPro) dnsManager.consumeDownload()
                            },
                            onFailure = { errorMsg = error.message ?: "Failed to extract media" }
                        )
                    }
                } else {
                    // ── DOWNLOAD phase ──────────────────────────────────────
                    if (mediaUrl.isBlank()) {
                        errorMsg = "No media URL available"
                        return@Button
                    }
                    isLoading = true
                    errorMsg = null
                    val outputDir = java.io.File(context.getExternalFilesDir(android.os.Environment.DIRECTORY_DOWNLOADS), "LinkShield")
                    val target = if (audioOnly) "MP3" else selectedResolution
                    val format = MediaFormat(
                        id = if (audioOnly) "mp3" else "v${target.replace("p", "").replace("4K", "2160")}",
                        label = target, ext = if (audioOnly) "mp3" else "mp4",
                        isAudioOnly = audioOnly, requiresMerge = !audioOnly && target in listOf("1080p", "4K")
                    )
                    scope.launch {
                        var finished = false
                        GrabberEngine.download(context, inputUrl, format, outputDir).collect { state ->
                            when (state) {
                                is DownloadState.Progress -> { isLoading = true }
                                is DownloadState.Success -> {
                                    isLoading = false; finished = true; fetched = false
                                    Toast.makeText(context, "Downloaded: ${state.file.name}", Toast.LENGTH_LONG).show()
                                }
                                is DownloadState.Error -> { isLoading = false; errorMsg = state.message }
                                else -> Unit
                            }
                        }
                        if (!finished && errorMsg == null) isLoading = false
                    }
                }
            },
            enabled  = inputUrl.isNotBlank() && !isLoading,
            modifier = Modifier.fillMaxWidth().height(52.dp),
            shape    = RoundedCornerShape(12.dp)
        ) {
            Icon(Icons.Default.Download, null)
            Spacer(Modifier.width(8.dp))
            Text(
                when {
                    isLoading -> "Fetching..."
                    fetched   -> "Download"
                    else      -> "Fetch Media"
                },
                fontWeight = FontWeight.Bold
            )
        }
    }
}

private fun extractYoutubeThumbnail(url: String): String {
    val clean = url.trim().lowercase()
    return when {
        "youtube.com/watch" in clean || "youtu.be/" in clean -> {
            val videoId = when {
                "youtu.be/" in clean -> url.substringAfter("youtu.be/").substringBefore("?").substringBefore("&").take(11)
                "v=" in clean -> url.substringAfter("v=").substringBefore("&").substringBefore("#").take(11)
                else -> ""
            }
            if (videoId.isNotBlank()) "https://img.youtube.com/vi/$videoId/hqdefault.jpg" else ""
        }
        else -> ""
    }
}
