package com.linkshield.sandbox.shield

enum class ShieldMode(val title: String, val subtitle: String) {
    STANDARD("Standard Secure Sandbox", "Direct HTTP/HTTPS + AdGuard Engine"),
    CUSTOM_DNS("Custom Secure DNS", "Cloudflare / AdGuard / Google DNS"),
    PSIPHON("Shielded VPN", "Psiphon Tunnel Core — restricted-sites unblocker")
}
