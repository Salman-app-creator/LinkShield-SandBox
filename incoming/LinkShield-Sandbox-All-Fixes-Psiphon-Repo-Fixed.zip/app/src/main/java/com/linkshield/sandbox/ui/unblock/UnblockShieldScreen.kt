package com.linkshield.sandbox.ui.unblock

import android.app.Activity
import android.webkit.WebView
import android.widget.Toast
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Download
import androidx.compose.material.icons.filled.Public
import androidx.compose.material.icons.filled.Star
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import com.linkshield.sandbox.dns.DohProvider
import com.linkshield.sandbox.license.LicenseManager
import com.linkshield.sandbox.shield.ShieldManager
import com.linkshield.sandbox.shield.ShieldMode
import com.linkshield.sandbox.ui.browser.SandboxBrowserScreen
import com.linkshield.sandbox.ui.grabber.LinkShieldGrabberScreen
import com.linkshield.sandbox.ui.upgrade.UpgradeScreen
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.launch
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import java.net.URLEncoder

private enum class MainTab(val label: String) { BROWSE("Shield"), GRAB("Grabber"), UPGRADE("Upgrade") }

@Composable
fun UnblockShieldScreen(initialUrl: String = "", isDarkTheme: Boolean = true, onThemeToggle: (Boolean) -> Unit = {}) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val licenseManager = remember { LicenseManager(context.applicationContext) }
    val shieldManager = remember { ShieldManager(context.applicationContext) }

    val isProUser by licenseManager.isProUserFlow.collectAsStateWithLifecycle(initialValue = licenseManager.isProUser())
    val shieldMode by shieldManager.mode.collectAsStateWithLifecycle()
    val dnsProvider by shieldManager.dnsProvider.collectAsStateWithLifecycle()
    val trialDays = licenseManager.getTrialDaysRemaining()

    var selectedTab by rememberSaveable { mutableStateOf(MainTab.BROWSE.name) }
    var url by rememberSaveable { mutableStateOf(normalizeUrl(initialUrl).ifBlank { "https://www.google.com" }) }
    var browserUrl by rememberSaveable { mutableStateOf(url) }
    var canBack by remember { mutableStateOf(false) }
    var canForward by remember { mutableStateOf(false) }
    var isLoading by remember { mutableStateOf(false) }
    var webView by remember { mutableStateOf<WebView?>(null) }
    var webViewGeneration by remember { mutableIntStateOf(0) }

    LaunchedEffect(shieldMode) { shieldManager.applyWebViewMode() }

    val tab = runCatching { MainTab.valueOf(selectedTab) }.getOrDefault(MainTab.BROWSE)

    BackHandler {
        when {
            tab == MainTab.BROWSE && canBack -> webView?.goBack()
            tab != MainTab.BROWSE -> selectedTab = MainTab.BROWSE.name
            else -> (context as? Activity)?.finish()
        }
    }

    Scaffold(contentWindowInsets = WindowInsets(0), bottomBar = {
        NavigationBar {
            MainTab.values().forEach { item ->
                NavigationBarItem(selected = tab == item, onClick = { selectedTab = item.name }, icon = { Icon(when(item) { MainTab.BROWSE -> Icons.Default.Public; MainTab.GRAB -> Icons.Default.Download; MainTab.UPGRADE -> Icons.Default.Star }, item.label) }, label = { Text(item.label) })
            }
        }
    }) { padding ->
        Box(Modifier.fillMaxSize().padding(padding)) {
            when (tab) {
                MainTab.BROWSE -> SandboxBrowserScreen(
                    generation = webViewGeneration, startUrl = browserUrl, currentUrl = url, onUrlChange = { url = it },
                    shieldMode = shieldMode, dnsProvider = dnsProvider,
                    onShieldModeSelected = { shieldManager.selectMode(it) },
                    onDnsProviderSelected = { shieldManager.selectDnsProvider(it) },
                    trialDaysLeft = trialDays, isProUser = isProUser, isDarkTheme = isDarkTheme, onThemeToggle = onThemeToggle,
                    canGoBack = canBack, canGoForward = canForward, onBack = { webView?.goBack() }, onForward = { webView?.goForward() }, onReload = { webView?.reload() },
                    onNavigate = { val target = normalizeUrl(url); if (target.isNotBlank()) { url = target; browserUrl = target; webView?.loadUrl(target) } }, isLoading = isLoading,
                    onReady = { webView = it }, onUrlChanged = { browserUrl = it; url = it }, onLoading = { isLoading = it }, onNavigation = { b,f -> canBack=b; canForward=f },
                    onRendererGone = { webView=null; webViewGeneration++ }
                )
                MainTab.GRAB -> LinkShieldGrabberScreen(onBackToBrowser = { selectedTab = MainTab.BROWSE.name }, onUpgradeClick = { selectedTab = MainTab.UPGRADE.name }, isProUser = isProUser, trialDaysLeft = trialDays)
                MainTab.UPGRADE -> UpgradeScreen(licenseManager = licenseManager, modifier = Modifier.fillMaxSize())
            }
        }
    }
}

private fun normalizeUrl(value: String): String {
    val trimmed = value.trim()
    if (trimmed.isBlank()) return ""
    val hasProtocol = trimmed.startsWith("http://", true) || trimmed.startsWith("https://", true)
    val hasDomainDot = trimmed.contains(".") && !trimmed.contains(" ")
    return when { hasProtocol -> trimmed; hasDomainDot -> "https://$trimmed"; else -> "https://www.google.com/search?q=${URLEncoder.encode(trimmed, "UTF-8")}" }
}
