package com.linkshield.sandbox

import android.app.role.RoleManager
import android.content.Intent
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.ActivityResultLauncher
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.runtime.*
import androidx.compose.ui.platform.LocalContext
import com.linkshield.sandbox.disclaimer.DisclaimerManager
import com.linkshield.sandbox.ui.screens.DisclaimerScreen
import com.linkshield.sandbox.ui.screens.EnableShieldScreen
import com.linkshield.sandbox.ui.screens.checkIsDefaultBrowser
import com.linkshield.sandbox.ui.theme.LinkShieldTheme
import com.linkshield.sandbox.ui.theme.ThemeManager
import com.linkshield.sandbox.ui.unblock.UnblockShieldScreen
import com.linkshield.sandbox.update.UpdateChecker
import com.linkshield.sandbox.update.UpdateDialog
import kotlinx.coroutines.flow.MutableStateFlow

class MainActivity : ComponentActivity() {
    private val interceptedUrlFlow = MutableStateFlow<String?>(null)
    private val browserRoleResultFlow = MutableStateFlow(false)

    private val browserRoleLauncher: ActivityResultLauncher<Intent> =
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) {
            val selected = checkIsDefaultBrowser(this)
            browserRoleResultFlow.value = selected
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        interceptedUrlFlow.value = intent?.getStringExtra("url")
        val disclaimerManager = DisclaimerManager(this)
        val themeManager = ThemeManager(this)

        setContent {
            val interceptedUrl by interceptedUrlFlow.collectAsState()
            val browserRoleSelected by browserRoleResultFlow.collectAsState()
            val context = LocalContext.current
            var isDarkTheme by remember { mutableStateOf(themeManager.isDarkTheme()) }
            var hasAccepted by remember { mutableStateOf(disclaimerManager.hasAccepted()) }
            var hasBrowserSet by remember { mutableStateOf(disclaimerManager.hasBrowserSet() || checkIsDefaultBrowser(context)) }
            var showUpdateDialog by remember { mutableStateOf(false) }
            var updateInfo by remember { mutableStateOf<com.linkshield.sandbox.update.UpdateInfo?>(null) }

            LaunchedEffect(Unit) { runCatching { UpdateChecker(context).checkForUpdate().getOrNull()?.let { if (it.updateAvailable) { updateInfo=it; showUpdateDialog=true } } } }
            LaunchedEffect(browserRoleSelected) { if (browserRoleSelected) { disclaimerManager.markBrowserSet(); hasBrowserSet=true } }

            LinkShieldTheme(darkTheme = isDarkTheme) {
                if (showUpdateDialog && updateInfo != null) UpdateDialog(updateInfo = updateInfo!!, onDismiss = { showUpdateDialog=false })
                when {
                    !hasAccepted -> DisclaimerScreen(onAccept = { disclaimerManager.accept(); hasAccepted=true })
                    !hasBrowserSet -> EnableShieldScreen(onBrowserSet = { disclaimerManager.markBrowserSet(); hasBrowserSet=true }, onRequestBrowserRole = { launchBrowserRoleRequest() })
                    else -> UnblockShieldScreen(initialUrl = interceptedUrl.orEmpty(), isDarkTheme = isDarkTheme, onThemeToggle = { dark -> themeManager.setTheme(if (dark) ThemeManager.THEME_DARK else ThemeManager.THEME_LIGHT); isDarkTheme=dark })
                }
            }
        }
    }

    private fun launchBrowserRoleRequest() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            val roleManager = getSystemService(RoleManager::class.java)
            if (roleManager != null && roleManager.isRoleAvailable(RoleManager.ROLE_BROWSER) && !roleManager.isRoleHeld(RoleManager.ROLE_BROWSER)) {
                browserRoleLauncher.launch(roleManager.createRequestRoleIntent(RoleManager.ROLE_BROWSER))
                return
            }
        }
        runCatching { startActivity(Intent(Settings.ACTION_MANAGE_DEFAULT_APPS_SETTINGS)) }
            .onFailure { runCatching { startActivity(Intent(Settings.ACTION_SETTINGS)) } }
    }

    override fun onNewIntent(intent: Intent?) {
        super.onNewIntent(intent)
        intent?.getStringExtra("url")?.let { interceptedUrlFlow.value=it }
    }
}
