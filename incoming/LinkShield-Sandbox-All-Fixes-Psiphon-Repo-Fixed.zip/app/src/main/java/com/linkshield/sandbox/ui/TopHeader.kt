package com.linkshield.sandbox.ui.components

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.ArrowForward
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.platform.LocalSoftwareKeyboardController
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.linkshield.sandbox.R
import com.linkshield.sandbox.dns.DohProvider
import com.linkshield.sandbox.shield.ShieldMode

@Composable
fun TopHeader(
    currentUrl: String = "", onUrlChange: (String) -> Unit = {},
    shieldMode: ShieldMode = ShieldMode.STANDARD,
    dnsProvider: DohProvider = DohProvider.CLOUDFLARE,
    onShieldModeSelected: (ShieldMode) -> Unit = {},
    onDnsProviderSelected: (DohProvider) -> Unit = {},
    trialDaysLeft: Int = 30, isDarkTheme: Boolean = false, onThemeToggle: (Boolean) -> Unit = {},
    canGoBack: Boolean = false, canGoForward: Boolean = false, onBack: () -> Unit = {}, onForward: () -> Unit = {},
    onReload: () -> Unit = {}, onNavigate: () -> Unit = {}, isLoading: Boolean = false, isProUser: Boolean = false
) {
    var dropdownExpanded by remember { mutableStateOf(false) }
    val keyboardController = LocalSoftwareKeyboardController.current

    Row(Modifier.fillMaxWidth().background(MaterialTheme.colorScheme.surface).statusBarsPadding().padding(horizontal = 8.dp, vertical = 6.dp), verticalAlignment = Alignment.CenterVertically) {
        Image(painterResource(R.drawable.ic_app_logo), "App Logo", Modifier.size(56.dp).clip(CircleShape))
        Spacer(Modifier.width(10.dp))
        Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween) {
                Box {
                    OutlinedButton(onClick = { dropdownExpanded = true }, contentPadding = PaddingValues(horizontal = 8.dp, vertical = 0.dp), modifier = Modifier.height(30.dp), shape = RoundedCornerShape(15.dp)) {
                        Text("🛡️ ${shieldMode.title} 🔻", fontSize = 10.sp, maxLines = 1)
                    }
                    DropdownMenu(expanded = dropdownExpanded, onDismissRequest = { dropdownExpanded = false }) {
                        ShieldMode.values().forEach { mode ->
                            DropdownMenuItem(
                                text = { Column { Text(mode.title, fontSize = 12.sp); Text(mode.subtitle, fontSize = 10.sp, color = MaterialTheme.colorScheme.onSurfaceVariant) } },
                                leadingIcon = { RadioButton(selected = shieldMode == mode, onClick = null) },
                                onClick = { onShieldModeSelected(mode); dropdownExpanded = false }
                            )
                            if (mode == ShieldMode.CUSTOM_DNS) {
                                DropdownMenuItem(
                                    text = { Text("DNS: ${dnsProvider.displayName}", fontSize = 11.sp) },
                                    onClick = { dropdownExpanded = false }
                                )
                                DohProvider.values().filter { it == DohProvider.CLOUDFLARE || it == DohProvider.ADGUARD || it == DohProvider.GOOGLE }.forEach { provider ->
                                    DropdownMenuItem(
                                        text = { Text("  ${provider.displayName}", fontSize = 11.sp) },
                                        leadingIcon = { RadioButton(selected = dnsProvider == provider, onClick = null) },
                                        onClick = { onDnsProviderSelected(provider); onShieldModeSelected(ShieldMode.CUSTOM_DNS); dropdownExpanded = false }
                                    )
                                }
                            }
                        }
                    }
                }
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(2.dp)) {
                    Text("☀️", fontSize = 10.sp); Switch(checked = isDarkTheme, onCheckedChange = onThemeToggle, modifier = Modifier.scale(0.6f)); Text("🌙", fontSize = 10.sp)
                }
                Surface(color = if (isProUser) Color(0xFFFFD700) else MaterialTheme.colorScheme.primaryContainer, shape = RoundedCornerShape(10.dp)) {
                    Text(if (isProUser) "👑 PRO" else "⏳ Trial: ${trialDaysLeft}d", color = if (isProUser) Color.Black else MaterialTheme.colorScheme.onSurface, style = MaterialTheme.typography.labelSmall, fontSize = 10.sp, modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp))
                }
            }
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                IconButton(onClick = onBack, enabled = canGoBack, modifier = Modifier.size(32.dp)) { Icon(Icons.AutoMirrored.Filled.ArrowBack, "Back", Modifier.size(18.dp)) }
                IconButton(onClick = onForward, enabled = canGoForward, modifier = Modifier.size(32.dp)) { Icon(Icons.AutoMirrored.Filled.ArrowForward, "Forward", Modifier.size(18.dp)) }
                IconButton(onClick = onReload, modifier = Modifier.size(32.dp)) { Icon(Icons.Default.Refresh, "Reload", Modifier.size(18.dp)) }
                val textColor = if (isDarkTheme) Color.White else Color(0xFF1E293B)
                val barBgColor = if (isDarkTheme) Color(0xFF1E293B) else Color(0xFFF1F5F9)
                val borderColor = if (isDarkTheme) Color(0xFF334155) else Color(0xFFCBD5E1)
                Row(Modifier.weight(1f).height(34.dp).background(barBgColor, RoundedCornerShape(17.dp)).border(1.dp, borderColor, RoundedCornerShape(17.dp)).padding(start = 10.dp, end = 4.dp), verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.Lock, "SSL Secure", Modifier.size(14.dp), tint = if (isLoading) MaterialTheme.colorScheme.primary else textColor)
                    Spacer(Modifier.width(6.dp))
                    BasicTextField(value = currentUrl, onValueChange = onUrlChange, singleLine = true, textStyle = TextStyle(color = textColor, fontSize = 12.sp), cursorBrush = SolidColor(MaterialTheme.colorScheme.primary), keyboardOptions = KeyboardOptions(imeAction = ImeAction.Go), keyboardActions = KeyboardActions(onGo = { keyboardController?.hide(); onNavigate() }), modifier = Modifier.weight(1f))
                    if (currentUrl.isNotEmpty()) IconButton(onClick = { onUrlChange("") }, modifier = Modifier.size(26.dp)) { Icon(Icons.Default.Close, "Clear", Modifier.size(14.dp)) }
                }
                Button(onClick = { keyboardController?.hide(); onNavigate() }, modifier = Modifier.height(34.dp), contentPadding = PaddingValues(horizontal = 10.dp), shape = RoundedCornerShape(17.dp)) { Text("GO", fontSize = 11.sp) }
            }
        }
    }
}
