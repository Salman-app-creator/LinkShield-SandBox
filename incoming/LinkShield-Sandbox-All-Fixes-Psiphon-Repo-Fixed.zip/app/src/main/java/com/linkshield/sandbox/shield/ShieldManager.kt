package com.linkshield.sandbox.shield

import android.content.Context
import android.content.Intent
import android.os.Build
import androidx.webkit.ProxyConfig
import androidx.webkit.ProxyController
import androidx.webkit.WebViewFeature
import com.linkshield.sandbox.dns.DnsManager
import com.linkshield.sandbox.dns.DohProvider
import java.util.concurrent.Executors
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

/** Coordinates the selected in-app shield mode. */
class ShieldManager(private val context: Context) {
    private val appContext = context.applicationContext
    private val dnsManager = DnsManager(appContext)
    private val proxyExecutor = Executors.newSingleThreadExecutor()

    private val _mode = MutableStateFlow(loadMode())
    val mode: StateFlow<ShieldMode> = _mode.asStateFlow()

    private val _dnsProvider = MutableStateFlow(dnsManager.getCurrentProvider())
    val dnsProvider: StateFlow<DohProvider> = _dnsProvider.asStateFlow()

    fun selectMode(mode: ShieldMode) {
        if (mode == _mode.value) return
        when (mode) {
            ShieldMode.STANDARD -> {
                stopPsiphon()
                dnsManager.disableDoh()
                clearWebViewProxy()
            }
            ShieldMode.CUSTOM_DNS -> {
                stopPsiphon()
                dnsManager.enableDoh(_dnsProvider.value)
                clearWebViewProxy()
            }
            ShieldMode.PSIPHON -> {
                dnsManager.disableDoh()
                startPsiphon()
            }
        }
        saveMode(mode)
        _mode.value = mode
    }

    fun selectDnsProvider(provider: DohProvider) {
        _dnsProvider.value = provider
        dnsManager.enableDoh(provider)
    }

    fun applyWebViewMode() {
        if (_mode.value != ShieldMode.PSIPHON) clearWebViewProxy()
    }

    fun clearWebViewProxy() {
        if (!WebViewFeature.isFeatureSupported(WebViewFeature.PROXY_OVERRIDE)) return
        runCatching {
            ProxyController.getInstance().clearProxyOverride(
                proxyExecutor, Runnable {}
            )
        }
    }

    fun applyPsiphonHttpProxy(port: Int) {
        if (port <= 0 || !WebViewFeature.isFeatureSupported(WebViewFeature.PROXY_OVERRIDE)) return
        val config = ProxyConfig.Builder()
            .addProxyRule("http://127.0.0.1:$port")
            .build()
        runCatching {
            ProxyController.getInstance().setProxyOverride(
                config, proxyExecutor, Runnable {}
            )
        }
    }

    private fun startPsiphon() {
        val intent = Intent(appContext, PsiphonTunnelService::class.java)
            .setAction(PsiphonTunnelService.ACTION_START)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) appContext.startForegroundService(intent)
        else appContext.startService(intent)
    }

    private fun stopPsiphon() {
        appContext.startService(
            Intent(appContext, PsiphonTunnelService::class.java)
                .setAction(PsiphonTunnelService.ACTION_STOP)
        )
    }

    private fun loadMode(): ShieldMode = runCatching {
        ShieldMode.valueOf(
            appContext.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
                .getString(KEY_MODE, ShieldMode.STANDARD.name)!!
        )
    }.getOrDefault(ShieldMode.STANDARD)

    private fun saveMode(mode: ShieldMode) {
        appContext.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .edit().putString(KEY_MODE, mode.name).apply()
    }

    companion object {
        private const val PREFS = "shield_mode"
        private const val KEY_MODE = "mode"
    }
}
