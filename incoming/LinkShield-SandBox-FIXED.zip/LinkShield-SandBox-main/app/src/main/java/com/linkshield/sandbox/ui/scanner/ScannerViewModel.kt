package com.linkshield.sandbox.ui.scanner

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.linkshield.sandbox.scanner.SafeBrowsingScanner
import com.linkshield.sandbox.scanner.ThreatResult
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

/**
 * ScannerViewModel.kt
 *
 * Manages the URL scan lifecycle and exposes [scanState] to the UI.
 *
 * State machine:
 *   Idle → Scanning → Safe / Threat / ScanError
 *                         ↓
 *                     (user action: proceed/block)
 *                         ↓
 *                       Idle
 */
class ScannerViewModel : ViewModel() {

    private val scanner = SafeBrowsingScanner()

    // ── State ─────────────────────────────────────────────────────────────────

    private val _scanState = MutableStateFlow<ThreatResult?>(null)

    /**
     * Current scan result. Null = idle (no scan active).
     * Observed by LinkScannerDialog and LinkInterceptorActivity.
     */
    val scanState: StateFlow<ThreatResult?> = _scanState.asStateFlow()

    // ── Actions ───────────────────────────────────────────────────────────────

    /**
     * Begin scanning [url].
     * Sets state to Scanning immediately for instant UI feedback,
     * then runs the two-stage scan asynchronously.
     */
    fun scan(url: String) {
        _scanState.value = ThreatResult.Scanning(url)

        viewModelScope.launch {
            _scanState.value = scanner.scan(url)
        }
    }

    /** Reset state (e.g. when user navigates away or dismisses dialog). */
    fun reset() {
        _scanState.value = null
    }

    /** Force-override to Safe (user chose "Proceed Anyway" on a warning). */
    fun forceAllow(url: String) {
        _scanState.value = ThreatResult.Safe(url)
    }
}
