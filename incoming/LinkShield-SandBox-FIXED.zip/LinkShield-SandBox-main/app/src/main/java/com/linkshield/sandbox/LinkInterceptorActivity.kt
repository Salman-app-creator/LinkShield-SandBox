package com.linkshield.sandbox

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.linkshield.sandbox.scanner.ThreatResult
import com.linkshield.sandbox.scanner.isSafe
import com.linkshield.sandbox.ui.scanner.LinkScannerDialog
import com.linkshield.sandbox.ui.scanner.ScannerViewModel
import com.linkshield.sandbox.ui.theme.LinkShieldTheme

/**
 * LinkInterceptorActivity.kt
 *
 * Entry point for all external links clicked on the device.
 * Registered in AndroidManifest.xml with http/https intent filters.
 *
 * Flow:
 *  1. Receive URL from Intent
 *  2. Show scanning dialog immediately
 *  3. Run SafeBrowsingScanner (local heuristics + Google Safe Browsing)
 *  4a. Safe   → forward to MainActivity with URL → opens in WebView
 *  4b. Threat → show threat warning, let user decide
 *  4c. Error  → show incomplete scan warning, let user decide
 */
class LinkInterceptorActivity : ComponentActivity() {

    private val viewModel: ScannerViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        val url = extractUrl(intent)

        if (url.isNullOrBlank()) {
            // No URL to scan — nothing to do
            finish()
            return
        }

        // Start scan immediately
        viewModel.scan(url)

        setContent {
            LinkShieldTheme(darkTheme = true) {
                val scanState by viewModel.scanState.collectAsStateWithLifecycle()

                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .background(Color.Black.copy(alpha = 0.6f))
                ) {
                    scanState?.let { result ->
                        // Auto-open on safe result (LaunchedEffect inside SafeCard handles timing)
                        LaunchedEffect(result) {
                            if (result is ThreatResult.Safe) {
                                openInSandbox(result.url)
                            }
                        }

                        LinkScannerDialog(
                            result    = result,
                            onProceed = {
                                // User chose "Open Anyway" on a threat/error
                                openInSandbox(url)
                            },
                            onBlock = {
                                // User chose to go back — just close this activity
                                viewModel.reset()
                                finish()
                            },
                            onDismiss = {
                                if (result !is ThreatResult.Scanning) finish()
                            }
                        )
                    }
                }
            }
        }
    }

    override fun onNewIntent(intent: Intent?) {
        super.onNewIntent(intent)
        val url = extractUrl(intent)
        if (!url.isNullOrBlank()) {
            viewModel.scan(url)
        }
    }

    // ── Helpers ───────────────────────────────────────────────────────────────

    /** Extract URL from the incoming Intent (VIEW action with http/https data). */
    private fun extractUrl(intent: Intent?): String? {
        if (intent?.action != Intent.ACTION_VIEW) return null
        val data = intent.data ?: return null
        return data.toString().takeIf { it.isNotBlank() }
    }

    /**
     * Forward the URL to MainActivity which owns the WebView.
     * Uses FLAG_ACTIVITY_CLEAR_TOP so we don't stack activities.
     */
    private fun openInSandbox(url: String) {
        val mainIntent = Intent(this, MainActivity::class.java).apply {
            action = Intent.ACTION_VIEW
            data   = Uri.parse(url)
            putExtra("url", url)
            flags  = Intent.FLAG_ACTIVITY_CLEAR_TOP or
                     Intent.FLAG_ACTIVITY_SINGLE_TOP
        }
        startActivity(mainIntent)
        finish()
    }
}
