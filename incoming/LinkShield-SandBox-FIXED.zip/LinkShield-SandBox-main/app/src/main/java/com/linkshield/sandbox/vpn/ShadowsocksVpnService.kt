package com.linkshield.sandbox.vpn

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.net.VpnService
import android.os.Build
import android.os.ParcelFileDescriptor
import android.util.Log
import androidx.core.app.NotificationCompat
import com.linkshield.sandbox.MainActivity
import com.linkshield.sandbox.R
import io.github.jigsaw_code.outline_sdk.transport.shadowsocks.ShadowsocksClient
import io.github.jigsaw_code.outline_sdk.vpn.OutlineVpnTunnel
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch

/**
 * ShadowsocksVpnService.kt
 *
 * Core Android VpnService that:
 *  1. Builds a TUN interface via VpnService.Builder
 *  2. Creates a Shadowsocks transport client (Outline SDK)
 *  3. Starts the Outline tunnel to forward TUN traffic → Shadowsocks proxy
 *  4. Manages a foreground notification for Android 8+ compliance
 *  5. Broadcasts state changes back to VpnStateHolder (observed by ViewModel)
 *
 * Lifecycle:
 *   startService(ACTION_CONNECT)    → builds TUN + starts tunnel
 *   startService(ACTION_DISCONNECT) → stops tunnel + closes TUN fd
 */
class ShadowsocksVpnService : VpnService() {

    companion object {
        private const val TAG = "ShadowsocksVpnService"

        // Intent actions
        const val ACTION_CONNECT    = "com.linkshield.sandbox.VPN_CONNECT"
        const val ACTION_DISCONNECT = "com.linkshield.sandbox.VPN_DISCONNECT"

        // Notification
        private const val NOTIFICATION_ID      = 1001
        private const val NOTIFICATION_CHANNEL = "linkshield_vpn_channel"

        // ── Convenience helpers called from ViewModel ─────────────────────────

        fun startConnect(context: Context) {
            val intent = Intent(context, ShadowsocksVpnService::class.java)
                .setAction(ACTION_CONNECT)
            context.startForegroundService(intent)
        }

        fun startDisconnect(context: Context) {
            val intent = Intent(context, ShadowsocksVpnService::class.java)
                .setAction(ACTION_DISCONNECT)
            context.startService(intent)
        }
    }

    // ── Fields ────────────────────────────────────────────────────────────────

    private val serviceScope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private var tunnelJob: Job? = null

    private var tunInterface: ParcelFileDescriptor? = null
    private var outlineTunnel: OutlineVpnTunnel?    = null

    // ── Service lifecycle ─────────────────────────────────────────────────────

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_CONNECT    -> handleConnect()
            ACTION_DISCONNECT -> handleDisconnect()
        }
        return START_STICKY
    }

    override fun onDestroy() {
        super.onDestroy()
        teardown()
    }

    override fun onRevoke() {
        // Called by Android when the user revokes VPN permission from Settings
        super.onRevoke()
        Log.w(TAG, "VPN permission revoked by user")
        teardown()
        VpnStateHolder.setState(
            VpnConnectionState.Error("VPN permission was revoked. Please reconnect.")
        )
    }

    // ── Connect ───────────────────────────────────────────────────────────────

    private fun handleConnect() {
        if (VpnStateHolder.state.value is VpnConnectionState.Connected) {
            Log.d(TAG, "Already connected — ignoring connect request")
            return
        }

        VpnStateHolder.setState(VpnConnectionState.Connecting)
        startForeground(NOTIFICATION_ID, buildNotification("Connecting…"))

        tunnelJob = serviceScope.launch {
            runCatching {
                // 1. Build the TUN interface
                val tun = buildTunInterface()
                    ?: error("Failed to establish TUN interface")
                tunInterface = tun

                // 2. Create Shadowsocks transport client (Outline SDK)
                val shadowsocksClient = ShadowsocksClient.create(
                    host     = ShadowsocksConfig.HOST,
                    port     = ShadowsocksConfig.PORT,
                    password = ShadowsocksConfig.PASSWORD,
                    method   = ShadowsocksConfig.METHOD
                )

                // 3. Build and start the Outline tunnel
                //    OutlineVpnTunnel connects the TUN fd to the Shadowsocks client
                val tunnel = OutlineVpnTunnel.create(
                    vpnService  = this@ShadowsocksVpnService,
                    tunFd       = tun.fd,
                    client      = shadowsocksClient
                )
                outlineTunnel = tunnel
                tunnel.start()

                // ── Connected ──────────────────────────────────────────────
                Log.i(TAG, "Tunnel started — connected to ${ShadowsocksConfig.HOST}")
                VpnStateHolder.setState(
                    VpnConnectionState.Connected(
                        serverIp   = ShadowsocksConfig.HOST,
                        startTimeMs = System.currentTimeMillis()
                    )
                )
                updateNotification("Connected · ${ShadowsocksConfig.HOST}")

            }.onFailure { error ->
                Log.e(TAG, "Tunnel start failed: ${error.message}", error)
                teardown()
                VpnStateHolder.setState(
                    VpnConnectionState.Error(
                        error.message ?: "Failed to connect to VPN server"
                    )
                )
                stopForeground(STOP_FOREGROUND_REMOVE)
                stopSelf()
            }
        }
    }

    // ── Disconnect ────────────────────────────────────────────────────────────

    private fun handleDisconnect() {
        VpnStateHolder.setState(VpnConnectionState.Disconnecting)
        teardown()
        VpnStateHolder.setState(VpnConnectionState.Disconnected)
        stopForeground(STOP_FOREGROUND_REMOVE)
        stopSelf()
    }

    // ── TUN Interface Builder ─────────────────────────────────────────────────

    /**
     * Builds the virtual TUN network interface.
     *
     * This intercepts all device traffic and funnels it into our
     * Shadowsocks tunnel.
     */
    private fun buildTunInterface(): ParcelFileDescriptor? {
        return try {
            Builder()
                .setSession(ShadowsocksConfig.PROFILE_NAME)
                .setMtu(ShadowsocksConfig.TUN_MTU)
                // Assign VPN's local IP address
                .addAddress(
                    ShadowsocksConfig.TUN_ADDRESS,
                    ShadowsocksConfig.TUN_PREFIX_LEN
                )
                // Route ALL traffic through the VPN
                .addRoute(
                    ShadowsocksConfig.TUN_ROUTE,
                    ShadowsocksConfig.TUN_ROUTE_LEN
                )
                // DNS servers used inside the VPN tunnel
                .addDnsServer(ShadowsocksConfig.TUN_DNS_PRIMARY)
                .addDnsServer(ShadowsocksConfig.TUN_DNS_SECONDARY)
                // Exclude OUR own app from the VPN so we can reach the
                // Shadowsocks server directly (bypasses routing loop)
                .addDisallowedApplication(packageName)
                // Block IPv6 to prevent leaks (IPv4-only Shadowsocks server)
                .addRoute("::", 0)
                .establish()
        } catch (e: Exception) {
            Log.e(TAG, "TUN interface build failed: ${e.message}", e)
            null
        }
    }

    // ── Teardown ──────────────────────────────────────────────────────────────

    private fun teardown() {
        tunnelJob?.cancel()
        tunnelJob = null

        runCatching { outlineTunnel?.stop() }
        outlineTunnel = null

        runCatching { tunInterface?.close() }
        tunInterface = null

        Log.d(TAG, "VPN teardown complete")
    }

    // ── Notifications ─────────────────────────────────────────────────────────

    private fun buildNotification(contentText: String): Notification {
        createNotificationChannel()

        val openAppIntent = PendingIntent.getActivity(
            this, 0,
            Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )

        val disconnectIntent = PendingIntent.getService(
            this, 1,
            Intent(this, ShadowsocksVpnService::class.java)
                .setAction(ACTION_DISCONNECT),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )

        return NotificationCompat.Builder(this, NOTIFICATION_CHANNEL)
            .setContentTitle("LinkShield VPN")
            .setContentText(contentText)
            .setSmallIcon(R.drawable.ic_vpn_key)       // Add this drawable to your resources
            .setOngoing(true)
            .setContentIntent(openAppIntent)
            .addAction(
                R.drawable.ic_vpn_off,                  // Add this drawable to your resources
                "Disconnect",
                disconnectIntent
            )
            .build()
    }

    private fun updateNotification(text: String) {
        val manager = getSystemService(NotificationManager::class.java)
        manager.notify(NOTIFICATION_ID, buildNotification(text))
    }

    private fun createNotificationChannel() {
        val channel = NotificationChannel(
            NOTIFICATION_CHANNEL,
            "LinkShield VPN Status",
            NotificationManager.IMPORTANCE_LOW
        ).apply {
            description     = "Shows VPN connection status"
            setShowBadge(false)
        }
        getSystemService(NotificationManager::class.java)
            .createNotificationChannel(channel)
    }
}
