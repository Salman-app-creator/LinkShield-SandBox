package com.linkshield.sandbox.ui.scanner

import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.core.*
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.linkshield.sandbox.scanner.ThreatResult

// ── Color palette ─────────────────────────────────────────────────────────────

private object ScanColors {
    val bgDark        = Color(0xFF0A0E1A)
    val surface       = Color(0xFF111827)
    val surfaceCard   = Color(0xFF1A2235)
    val borderSubtle  = Color(0xFF1E293B)

    val cyan          = Color(0xFF00D4FF)
    val green         = Color(0xFF22C55E)
    val red           = Color(0xFFEF4444)
    val redDark       = Color(0xFF7F1D1D)
    val orange        = Color(0xFFF59E0B)

    val textPrimary   = Color(0xFFE2E8F0)
    val textSecondary = Color(0xFF94A3B8)
    val textMuted     = Color(0xFF475569)
}

// ── Main Dialog Entry Point ───────────────────────────────────────────────────

/**
 * LinkScannerDialog
 *
 * Shows the current scan state as a full-screen dark modal dialog.
 *
 * @param result        Current ThreatResult from ScannerViewModel.
 * @param onProceed     Called when user taps "Open Anyway" (on Threat/Error).
 * @param onBlock       Called when user taps "Go Back" / "Block".
 * @param onDismiss     Called on dialog dismiss attempt.
 */
@Composable
fun LinkScannerDialog(
    result: ThreatResult,
    onProceed: () -> Unit,
    onBlock: () -> Unit,
    onDismiss: () -> Unit
) {
    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(
            dismissOnBackPress    = result !is ThreatResult.Scanning,
            dismissOnClickOutside = false,
            usePlatformDefaultWidth = false
        )
    ) {
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(Color.Black.copy(alpha = 0.85f)),
            contentAlignment = Alignment.Center
        ) {
            AnimatedContent(
                targetState = result,
                label = "scanContent"
            ) { currentResult ->
                when (currentResult) {
                    is ThreatResult.Scanning  -> ScanningCard(currentResult.url)
                    is ThreatResult.Safe      -> SafeCard(currentResult.url, onProceed)
                    is ThreatResult.Threat    -> ThreatCard(currentResult, onProceed, onBlock)
                    is ThreatResult.ScanError -> ScanErrorCard(currentResult, onProceed, onBlock)
                }
            }
        }
    }
}

// ── Scanning Card ─────────────────────────────────────────────────────────────

@Composable
private fun ScanningCard(url: String) {
    val infiniteTransition = rememberInfiniteTransition(label = "scan")
    val rotation by infiniteTransition.animateFloat(
        initialValue  = 0f,
        targetValue   = 360f,
        animationSpec = infiniteRepeatable(tween(1000, easing = LinearEasing)),
        label         = "rotation"
    )
    val pulse by infiniteTransition.animateFloat(
        initialValue  = 0.6f,
        targetValue   = 1f,
        animationSpec = infiniteRepeatable(
            tween(700, easing = EaseInOutSine),
            RepeatMode.Reverse
        ),
        label = "pulse"
    )

    ScannerCard {
        Column(
            horizontalAlignment    = Alignment.CenterHorizontally,
            verticalArrangement   = Arrangement.spacedBy(20.dp)
        ) {
            // Spinning ring
            Box(
                contentAlignment = Alignment.Center,
                modifier = Modifier.size(80.dp)
            ) {
                Box(
                    modifier = Modifier
                        .size(80.dp)
                        .rotate(rotation)
                        .clip(CircleShape)
                        .background(
                            Brush.sweepGradient(
                                listOf(ScanColors.cyan, ScanColors.bgDark)
                            )
                        )
                )
                Box(
                    modifier = Modifier
                        .size(64.dp)
                        .clip(CircleShape)
                        .background(ScanColors.surface)
                )
                Text(
                    text     = "🔍",
                    fontSize = (28 * pulse).sp
                )
            }

            Text(
                "Scanning Link…",
                fontSize   = 18.sp,
                fontWeight = FontWeight.Bold,
                color      = ScanColors.textPrimary
            )
            Text(
                "Checking against Google Safe Browsing\nand local threat database",
                fontSize  = 13.sp,
                color     = ScanColors.textSecondary,
                textAlign = TextAlign.Center
            )
            UrlChip(url)
        }
    }
}

// ── Safe Card ─────────────────────────────────────────────────────────────────

@Composable
private fun SafeCard(url: String, onProceed: () -> Unit) {
    // Auto-proceed after 800ms for seamless UX
    LaunchedEffect(url) {
        kotlinx.coroutines.delay(800)
        onProceed()
    }

    ScannerCard {
        Column(
            horizontalAlignment  = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            Box(
                contentAlignment = Alignment.Center,
                modifier = Modifier
                    .size(72.dp)
                    .clip(CircleShape)
                    .background(ScanColors.green.copy(alpha = 0.15f))
                    .border(2.dp, ScanColors.green, CircleShape)
            ) {
                Text("✅", fontSize = 32.sp)
            }

            Text(
                "Link is Safe",
                fontSize   = 20.sp,
                fontWeight = FontWeight.Bold,
                color      = ScanColors.green
            )
            Text(
                "No threats detected. Opening now…",
                fontSize  = 13.sp,
                color     = ScanColors.textSecondary,
                textAlign = TextAlign.Center
            )
            UrlChip(url)

            LinearProgressIndicator(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(4.dp)),
                color            = ScanColors.green,
                trackColor       = ScanColors.borderSubtle
            )
        }
    }
}

// ── Threat Card ───────────────────────────────────────────────────────────────

@Composable
private fun ThreatCard(
    threat: ThreatResult.Threat,
    onProceed: () -> Unit,
    onBlock: () -> Unit
) {
    ScannerCard {
        Column(
            horizontalAlignment  = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // Warning icon
            Box(
                contentAlignment = Alignment.Center,
                modifier = Modifier
                    .size(72.dp)
                    .clip(CircleShape)
                    .background(ScanColors.red.copy(alpha = 0.15f))
                    .border(2.dp, ScanColors.red, CircleShape)
            ) {
                Text("⛔", fontSize = 32.sp)
            }

            Text(
                "Threat Detected",
                fontSize   = 20.sp,
                fontWeight = FontWeight.Bold,
                color      = ScanColors.red
            )

            // Threat type badge
            Surface(
                color = ScanColors.red.copy(alpha = 0.2f),
                shape = RoundedCornerShape(8.dp)
            ) {
                Text(
                    text     = threat.threatType.uppercase(),
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    color    = ScanColors.red,
                    modifier = Modifier.padding(horizontal = 12.dp, vertical = 4.dp)
                )
            }

            UrlChip(threat.url)

            // Detail card
            if (threat.details.isNotBlank()) {
                Surface(
                    color  = ScanColors.surfaceCard,
                    shape  = RoundedCornerShape(12.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .border(1.dp, ScanColors.red.copy(alpha = 0.3f), RoundedCornerShape(12.dp))
                ) {
                    Column(modifier = Modifier.padding(14.dp)) {
                        Text(
                            "Detected by: ${threat.source}",
                            fontSize   = 11.sp,
                            color      = ScanColors.textMuted,
                            fontWeight = FontWeight.Medium
                        )
                        Spacer(Modifier.height(6.dp))
                        Text(
                            threat.details,
                            fontSize = 13.sp,
                            color    = ScanColors.textSecondary
                        )
                    }
                }
            }

            // Buttons
            Row(
                modifier              = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                // Go Back — primary action (safe choice)
                Button(
                    onClick = onBlock,
                    colors  = ButtonDefaults.buttonColors(containerColor = ScanColors.green),
                    shape   = RoundedCornerShape(12.dp),
                    modifier = Modifier.weight(1f)
                ) {
                    Text("← Go Back", fontWeight = FontWeight.Bold, color = Color.Black)
                }

                // Proceed Anyway — secondary (risky)
                OutlinedButton(
                    onClick = onProceed,
                    shape   = RoundedCornerShape(12.dp),
                    border  = androidx.compose.foundation.BorderStroke(
                        1.dp, ScanColors.red.copy(alpha = 0.6f)
                    ),
                    modifier = Modifier.weight(1f)
                ) {
                    Text(
                        "Open Anyway",
                        fontSize = 12.sp,
                        color    = ScanColors.red
                    )
                }
            }

            Text(
                "⚠️ Opening this link may compromise your security.",
                fontSize  = 11.sp,
                color     = ScanColors.textMuted,
                textAlign = TextAlign.Center
            )
        }
    }
}

// ── Scan Error Card ───────────────────────────────────────────────────────────

@Composable
private fun ScanErrorCard(
    error: ThreatResult.ScanError,
    onProceed: () -> Unit,
    onBlock: () -> Unit
) {
    ScannerCard {
        Column(
            horizontalAlignment  = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            Box(
                contentAlignment = Alignment.Center,
                modifier = Modifier
                    .size(72.dp)
                    .clip(CircleShape)
                    .background(ScanColors.orange.copy(alpha = 0.15f))
                    .border(2.dp, ScanColors.orange, CircleShape)
            ) {
                Text("⚠️", fontSize = 32.sp)
            }

            Text(
                "Scan Incomplete",
                fontSize   = 20.sp,
                fontWeight = FontWeight.Bold,
                color      = ScanColors.orange
            )
            Text(
                error.reason,
                fontSize  = 13.sp,
                color     = ScanColors.textSecondary,
                textAlign = TextAlign.Center
            )
            UrlChip(error.url)

            Row(
                modifier              = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Button(
                    onClick = onBlock,
                    colors  = ButtonDefaults.buttonColors(
                        containerColor = ScanColors.surfaceCard
                    ),
                    shape    = RoundedCornerShape(12.dp),
                    modifier = Modifier.weight(1f)
                ) {
                    Text("← Go Back", color = ScanColors.textPrimary)
                }
                Button(
                    onClick = onProceed,
                    colors  = ButtonDefaults.buttonColors(
                        containerColor = ScanColors.orange
                    ),
                    shape    = RoundedCornerShape(12.dp),
                    modifier = Modifier.weight(1f)
                ) {
                    Text("Open Anyway", fontWeight = FontWeight.Bold, color = Color.Black)
                }
            }
        }
    }
}

// ── Shared Composables ────────────────────────────────────────────────────────

@Composable
private fun ScannerCard(content: @Composable ColumnScope.() -> Unit) {
    Surface(
        shape  = RoundedCornerShape(20.dp),
        color  = ScanColors.surface,
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 20.dp)
            .border(1.dp, ScanColors.borderSubtle, RoundedCornerShape(20.dp))
    ) {
        Column(
            modifier             = Modifier.padding(24.dp),
            horizontalAlignment  = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(0.dp),
            content              = content
        )
    }
}

@Composable
private fun UrlChip(url: String) {
    Surface(
        color  = ScanColors.surfaceCard,
        shape  = RoundedCornerShape(8.dp),
        modifier = Modifier.fillMaxWidth()
    ) {
        Text(
            text     = url,
            fontSize = 11.sp,
            color    = ScanColors.cyan,
            maxLines = 2,
            overflow = TextOverflow.Ellipsis,
            modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp)
        )
    }
}
