package com.linkshield.sandbox.vpn

import android.content.Context
import com.wireguard.android.backend.Backend
import com.wireguard.android.backend.GoBackend
import com.wireguard.android.backend.Tunnel
import com.wireguard.config.Config
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

/**
 * WireGuardVpnController.kt
 *
 * Low-level wrapper around the WireGuard GoBackend.
 * Responsible for starting and stopping the kernel tunnel via the
 * wireguard-android library.
 *
 * Called exclusively by WireGuardVpnManager — do not access from UI.
 */
class WireGuardVpnController(private val context: Context) {

    companion object {
        private const val TUNNEL_NAME = "LinkShieldVPN"
    }

    // ── GoBackend (lazy — avoids blocking main thread on init) ────────────────

    private val backend: Backend by lazy {
        GoBackend(context.applicationContext)
    }

    // ── Simple Tunnel implementation ──────────────────────────────────────────

    private val tunnel = object : Tunnel {
        override fun getName(): String = TUNNEL_NAME

        override fun onStateChange(newState: Tunnel.State) {
            // State is tracked by WireGuardVpnState, not here.
        }
    }

    // ── Public API ────────────────────────────────────────────────────────────

    /**
     * Bring the WireGuard tunnel up with the given parsed Config.
     * Must be called from an IO coroutine context.
     */
    suspend fun connect(config: Config): Result<Unit> =
        withContext(Dispatchers.IO) {
            runCatching {
                backend.setState(tunnel, Tunnel.State.UP, config)
            }
        }

    /**
     * Tear down the WireGuard tunnel.
     * Must be called from an IO coroutine context.
     */
    suspend fun disconnect(): Result<Unit> =
        withContext(Dispatchers.IO) {
            runCatching {
                backend.setState(tunnel, Tunnel.State.DOWN, null)
            }
        }

    /** Returns true if the tunnel is currently UP according to the backend. */
    fun isConnected(): Boolean =
        runCatching {
            backend.getState(tunnel) == Tunnel.State.UP
        }.getOrDefault(false)
}
