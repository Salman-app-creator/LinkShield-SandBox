package com.linkshield.sandbox.vpn

import android.content.Context
import androidx.security.crypto.EncryptedSharedPreferences
import androidx.security.crypto.MasterKey
import com.wireguard.config.Config
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.BufferedReader
import java.io.StringReader

/**
 * WireGuardVpnRepository.kt
 *
 * Handles persistence and retrieval of the WireGuard tunnel configuration.
 * Config is stored in EncryptedSharedPreferences so private keys are
 * never stored in plaintext on disk.
 *
 * Called by WireGuardVpnManager — do not access directly from UI.
 */
class WireGuardVpnRepository(private val context: Context) {

    companion object {
        private const val PREFS_FILE  = "wg_config_prefs"
        private const val KEY_CONFIG  = "wireguard_config"
    }

    // ── EncryptedSharedPreferences ────────────────────────────────────────────

    private val prefs by lazy {
        val masterKey = MasterKey.Builder(context)
            .setKeyScheme(MasterKey.KeyScheme.AES256_GCM)
            .build()

        EncryptedSharedPreferences.create(
            context,
            PREFS_FILE,
            masterKey,
            EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,
            EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM
        )
    }

    // ── Public API ────────────────────────────────────────────────────────────

    /** Returns true if a saved config exists. */
    fun hasConfig(): Boolean = true  // Hardcoded config always available

    /**
     * Load and parse the WireGuard config.
     * Uses saved config if available, otherwise returns the built-in
     * LinkShield VPN config (hardcoded — no import required).
     */
    suspend fun loadConfig(): Result<Config> = withContext(Dispatchers.IO) {
        runCatching {
            // Try saved config first
            val raw = prefs.getString(KEY_CONFIG, null)
                ?: BUILT_IN_CONFIG          // Fallback to built-in config

            Config.parse(BufferedReader(StringReader(raw)))
        }
    }

    companion object {
        // Built-in WireGuard config — replace [Peer] section with your server details
        // Interface section uses a placeholder keypair — set your real keys here
        private const val BUILT_IN_CONFIG = """
[Interface]
PrivateKey = OH1Y55pIvy330HQrKaEz4q53to+RtrF8jLVK85kLY1k=
Address = 10.66.66.3/32,fd42:42:42::3/128
DNS = 1.1.1.1,1.0.0.1

[Peer]
PublicKey = cKyQuobdhp7+twoNW0muNo1mEB/4+IRS+LP51GQuxC4=
PresharedKey = KF/W4IBCsLpN33tq6BEBLnkBQjbl+aznxffKQqafQ8g=
Endpoint = 141.148.223.177:54536
AllowedIPs = 0.0.0.0/0,::/0
PersistentKeepalive = 25
"""
    }

    /**
     * Encrypt and persist the raw WireGuard config text.
     * Pass the content of a standard .conf file.
     */
    suspend fun saveConfig(configText: String): Result<Unit> =
        withContext(Dispatchers.IO) {
            runCatching {
                // Validate the config before saving
                Config.parse(BufferedReader(StringReader(configText)))

                prefs.edit()
                    .putString(KEY_CONFIG, configText)
                    .apply()
            }
        }

    /** Remove the stored config (e.g. on logout / reset). */
    suspend fun deleteConfig(): Unit = withContext(Dispatchers.IO) {
        prefs.edit().remove(KEY_CONFIG).apply()
    }
}
