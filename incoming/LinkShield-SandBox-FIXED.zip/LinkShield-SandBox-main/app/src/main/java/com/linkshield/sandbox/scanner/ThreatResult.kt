package com.linkshield.sandbox.scanner

/**
 * ThreatResult.kt
 *
 * Sealed class representing every possible outcome of a URL safety scan.
 * Produced by SafeBrowsingScanner, consumed by ScannerViewModel and
 * LinkScannerDialog.
 */
sealed class ThreatResult {

    /** URL passed all checks — safe to open in WebView. */
    data class Safe(val url: String) : ThreatResult()

    /**
     * URL flagged as malicious.
     *
     * @param url         The scanned URL.
     * @param threatType  Human-readable threat category (e.g. "Phishing",
     *                    "Malware", "Unwanted Software").
     * @param source      Which scanner detected it: "Local" or "Google Safe Browsing".
     * @param details     Optional extra detail for the warning dialog.
     */
    data class Threat(
        val url: String,
        val threatType: String,
        val source: String,
        val details: String = ""
    ) : ThreatResult()

    /**
     * Scan could not complete — API error or network failure.
     * UI should offer "Proceed anyway" or "Go back" options.
     *
     * @param url     The scanned URL.
     * @param reason  Why the scan failed.
     */
    data class ScanError(
        val url: String,
        val reason: String
    ) : ThreatResult()

    /** Scan is currently in progress. Used as initial/loading state. */
    data class Scanning(val url: String) : ThreatResult()
}

// ── Convenience extensions ────────────────────────────────────────────────────

val ThreatResult.url: String
    get() = when (this) {
        is ThreatResult.Safe      -> url
        is ThreatResult.Threat    -> url
        is ThreatResult.ScanError -> url
        is ThreatResult.Scanning  -> url
    }

val ThreatResult.isSafe: Boolean
    get() = this is ThreatResult.Safe

val ThreatResult.isBlocked: Boolean
    get() = this is ThreatResult.Threat
