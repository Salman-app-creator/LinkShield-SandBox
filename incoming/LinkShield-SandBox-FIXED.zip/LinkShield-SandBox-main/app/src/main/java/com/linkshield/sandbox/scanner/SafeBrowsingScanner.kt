package com.linkshield.sandbox.scanner

import android.util.Log
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URI
import java.net.URL

/**
 * SafeBrowsingScanner.kt
 *
 * Two-stage URL safety scanner:
 *
 * Stage 1 — Local Heuristics (instant, offline):
 *   • Raw IP address as host (no legitimate site uses this)
 *   • Suspicious TLDs known for abuse
 *   • Excessive subdomains (typosquatting)
 *   • Known phishing keywords in hostname
 *   • URL shorteners (can hide destination)
 *   • Homograph/unicode spoofing in hostname
 *   • Overly long URLs (common in phishing)
 *
 * Stage 2 — Google Safe Browsing API v4 (async, requires API key):
 *   • MALWARE, SOCIAL_ENGINEERING (phishing), UNWANTED_SOFTWARE,
 *     POTENTIALLY_HARMFUL_APPLICATION
 *
 * Usage:
 *   val scanner = SafeBrowsingScanner(apiKey = "YOUR_KEY")
 *   val result  = scanner.scan("https://example.com")
 */
class SafeBrowsingScanner(
    private val apiKey: String = SAFE_BROWSING_API_KEY
) {

    companion object {
        private const val TAG = "SafeBrowsingScanner"

        // ── Replace with your Google Cloud Console API key ────────────────────
        // Enable "Safe Browsing API" at https://console.cloud.google.com
        // Free tier: 10,000 queries/day
        const val SAFE_BROWSING_API_KEY = "AIzaSyCV71sWSuHkjqjsFa0CPOnomgF5LWGW394"

        private const val SAFE_BROWSING_URL =
            "https://safebrowsing.googleapis.com/v4/threatMatches:find"

        private const val CONNECT_TIMEOUT = 8_000
        private const val READ_TIMEOUT    = 10_000

        // ── Suspicious TLDs — high abuse rate ─────────────────────────────────
        private val SUSPICIOUS_TLDS = setOf(
            ".tk", ".ml", ".ga", ".cf", ".gq",   // Freenom — most abused
            ".xyz", ".top", ".club", ".online",
            ".site", ".icu", ".cam", ".vip",
            ".work", ".men", ".loan", ".download",
            ".stream", ".bid", ".trade", ".racing"
        )

        // ── Known URL shorteners — hide real destination ───────────────────────
        private val URL_SHORTENERS = setOf(
            "bit.ly", "tinyurl.com", "goo.gl", "t.co",
            "ow.ly", "buff.ly", "rebrand.ly", "short.io",
            "cutt.ly", "tiny.cc", "is.gd", "v.gd",
            "bitly.com", "bl.ink"
        )

        // ── Phishing keyword patterns in hostname ─────────────────────────────
        private val PHISHING_KEYWORDS = listOf(
            "paypa1", "paypаl",       // homograph paypal
            "g00gle", "g0ogle",
            "arnazon", "arnaz0n",     // amazon typo
            "faceb00k", "facebo0k",
            "-login", "-signin", "-secure", "-verify",
            "-account", "-update", "-confirm",
            "-banking", "-wallet", "-crypto"
        )
    }

    // ── Public API ────────────────────────────────────────────────────────────

    /**
     * Full two-stage scan.
     * Returns immediately if local heuristics flag the URL.
     * Otherwise proceeds to Google Safe Browsing API.
     *
     * Must be called from a coroutine — does IO on Dispatchers.IO.
     */
    suspend fun scan(rawUrl: String): ThreatResult = withContext(Dispatchers.IO) {
        val url = rawUrl.trim()

        if (url.isBlank()) {
            return@withContext ThreatResult.ScanError(url, "Empty URL")
        }

        // Stage 1 — instant local check
        val localResult = checkLocal(url)
        if (localResult != null) {
            Log.w(TAG, "Local heuristic blocked: $url — ${localResult.threatType}")
            return@withContext localResult
        }

        // Stage 2 — Google Safe Browsing
        if (apiKey == SAFE_BROWSING_API_KEY || apiKey.isBlank()) {
            // No API key configured — skip remote check, allow URL
            Log.d(TAG, "Safe Browsing API key not set — skipping remote check")
            return@withContext ThreatResult.Safe(url)
        }

        return@withContext checkGoogleSafeBrowsing(url)
    }

    /**
     * Local heuristics only — synchronous, no network.
     * Useful for pre-check before showing any UI.
     */
    fun checkLocalOnly(rawUrl: String): ThreatResult {
        val url = rawUrl.trim()
        return checkLocal(url) ?: ThreatResult.Safe(url)
    }

    // ── Stage 1: Local Heuristics ─────────────────────────────────────────────

    private fun checkLocal(url: String): ThreatResult.Threat? {
        val parsed = runCatching { URI(url) }.getOrNull()
            ?: return ThreatResult.Threat(
                url        = url,
                threatType = "Invalid URL",
                source     = "Local",
                details    = "URL could not be parsed — possibly malformed or obfuscated."
            )

        val host   = parsed.host?.lowercase() ?: return null
        val scheme = parsed.scheme?.lowercase() ?: ""

        // 1. Non-HTTP scheme (data:, javascript:, etc.)
        if (scheme !in setOf("http", "https", "")) {
            return ThreatResult.Threat(
                url        = url,
                threatType = "Dangerous Scheme",
                source     = "Local",
                details    = "The URL uses the '$scheme:' scheme which can execute code or leak data."
            )
        }

        // 2. Raw IP address as host
        if (host.matches(Regex("""\d{1,3}(\.\d{1,3}){3}"""))) {
            return ThreatResult.Threat(
                url        = url,
                threatType = "Suspicious Host",
                source     = "Local",
                details    = "The site uses a raw IP address ($host) instead of a domain name, " +
                             "which is unusual for legitimate websites."
            )
        }

        // 3. Suspicious TLD
        SUSPICIOUS_TLDS.forEach { tld ->
            if (host.endsWith(tld)) {
                return ThreatResult.Threat(
                    url        = url,
                    threatType = "Suspicious Domain",
                    source     = "Local",
                    details    = "The domain '$host' uses the '$tld' TLD, which is heavily " +
                                 "associated with phishing and spam."
                )
            }
        }

        // 4. Excessive subdomains (typosquatting / phishing pattern)
        val parts = host.split(".")
        if (parts.size > 5) {
            return ThreatResult.Threat(
                url        = url,
                threatType = "Suspicious URL Structure",
                source     = "Local",
                details    = "The URL has an unusually large number of subdomains (${parts.size}), " +
                             "a common phishing technique."
            )
        }

        // 5. Phishing keywords in hostname
        PHISHING_KEYWORDS.forEach { keyword ->
            if (keyword in host) {
                return ThreatResult.Threat(
                    url        = url,
                    threatType = "Phishing Pattern",
                    source     = "Local",
                    details    = "The domain '$host' contains the pattern '$keyword', " +
                                 "commonly used in phishing attacks to impersonate trusted brands."
                )
            }
        }

        // 6. URL shortener — warn but don't hard-block (configurable)
        if (URL_SHORTENERS.any { host == it || host.endsWith(".$it") }) {
            return ThreatResult.Threat(
                url        = url,
                threatType = "URL Shortener",
                source     = "Local",
                details    = "This URL passes through '$host', a URL shortener service. " +
                             "The real destination is hidden — proceed only if you trust the sender."
            )
        }

        // 7. Unicode/homograph in hostname
        if (host.any { it.code > 127 }) {
            return ThreatResult.Threat(
                url        = url,
                threatType = "Homograph Attack",
                source     = "Local",
                details    = "The domain contains non-ASCII characters that can visually " +
                             "impersonate legitimate domains."
            )
        }

        // 8. Extremely long URL
        if (url.length > 2000) {
            return ThreatResult.Threat(
                url        = url,
                threatType = "Suspicious URL Length",
                source     = "Local",
                details    = "This URL is unusually long (${url.length} characters), " +
                             "a common technique to hide malicious parameters."
            )
        }

        return null  // passed all local checks
    }

    // ── Stage 2: Google Safe Browsing API v4 ──────────────────────────────────

    private fun checkGoogleSafeBrowsing(url: String): ThreatResult {
        return try {
            val requestBody = buildSafeBrowsingRequest(url)

            val connection = URL("$SAFE_BROWSING_URL?key=$apiKey")
                .openConnection() as HttpURLConnection

            connection.apply {
                requestMethod    = "POST"
                connectTimeout   = CONNECT_TIMEOUT
                readTimeout      = READ_TIMEOUT
                doOutput         = true
                setRequestProperty("Content-Type", "application/json")
                setRequestProperty("Accept", "application/json")
            }

            connection.outputStream.use { os ->
                os.write(requestBody.toByteArray(Charsets.UTF_8))
            }

            val responseCode = connection.responseCode

            if (responseCode != 200) {
                Log.w(TAG, "Safe Browsing API returned HTTP $responseCode")
                // Non-blocking — if API fails, don't block the user
                return ThreatResult.ScanError(
                    url    = url,
                    reason = "Safe Browsing API unavailable (HTTP $responseCode)"
                )
            }

            val responseBody = connection.inputStream
                .bufferedReader()
                .readText()

            connection.disconnect()

            parseSafeBrowsingResponse(url, responseBody)

        } catch (e: Exception) {
            Log.e(TAG, "Safe Browsing API error: ${e.message}", e)
            ThreatResult.ScanError(
                url    = url,
                reason = "Network error during safety scan: ${e.message}"
            )
        }
    }

    private fun buildSafeBrowsingRequest(url: String): String {
        return JSONObject().apply {
            put("client", JSONObject().apply {
                put("clientId",      "linkshield-sandbox")
                put("clientVersion", "2.1.0")
            })
            put("threatInfo", JSONObject().apply {
                put("threatTypes", JSONArray().apply {
                    put("MALWARE")
                    put("SOCIAL_ENGINEERING")
                    put("UNWANTED_SOFTWARE")
                    put("POTENTIALLY_HARMFUL_APPLICATION")
                })
                put("platformTypes",  JSONArray().apply { put("ANDROID") })
                put("threatEntryTypes", JSONArray().apply { put("URL") })
                put("threatEntries", JSONArray().apply {
                    put(JSONObject().apply { put("url", url) })
                })
            })
        }.toString()
    }

    private fun parseSafeBrowsingResponse(url: String, body: String): ThreatResult {
        return try {
            val json    = JSONObject(body)
            val matches = json.optJSONArray("matches")

            if (matches == null || matches.length() == 0) {
                ThreatResult.Safe(url)
            } else {
                val match      = matches.getJSONObject(0)
                val threatType = match.optString("threatType", "Unknown Threat")

                val humanReadable = when (threatType) {
                    "MALWARE"                       -> "Malware"
                    "SOCIAL_ENGINEERING"            -> "Phishing / Social Engineering"
                    "UNWANTED_SOFTWARE"             -> "Unwanted Software"
                    "POTENTIALLY_HARMFUL_APPLICATION" -> "Harmful App"
                    else                            -> threatType
                }

                ThreatResult.Threat(
                    url        = url,
                    threatType = humanReadable,
                    source     = "Google Safe Browsing",
                    details    = "Google's database confirmed this URL distributes $humanReadable. " +
                                 "This site may steal your data or damage your device."
                )
            }
        } catch (e: Exception) {
            Log.e(TAG, "Failed to parse Safe Browsing response: ${e.message}")
            ThreatResult.Safe(url)  // Parse failure → don't block
        }
    }
}
