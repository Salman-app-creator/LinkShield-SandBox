package com.linkshield.sandbox.vpn

import android.content.Context

/** Legacy compatibility shell. */
class WireGuardConfigProvider(context: Context) {
    fun getConfig(): Result<String> = Result.failure(IllegalStateException("WireGuard is no longer used"))
}
