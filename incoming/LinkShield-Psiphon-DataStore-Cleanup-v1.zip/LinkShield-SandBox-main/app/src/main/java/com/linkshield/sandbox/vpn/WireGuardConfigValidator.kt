package com.linkshield.sandbox.vpn

/** Retained for source compatibility; Psiphon no longer consumes WireGuard configs. */
object WireGuardConfigValidator {
    fun validate(configText: String): Result<Unit> =
        if (configText.isNotBlank()) Result.success(Unit)
        else Result.failure(IllegalArgumentException("WireGuard configuration is empty"))
}
