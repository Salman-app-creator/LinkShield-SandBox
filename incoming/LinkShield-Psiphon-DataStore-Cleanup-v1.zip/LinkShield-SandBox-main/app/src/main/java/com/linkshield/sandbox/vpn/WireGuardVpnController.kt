package com.linkshield.sandbox.vpn

import android.content.Context
import com.linkshield.sandbox.vpn.psiphon.PsiphonVpnManager

/** Legacy source-compatible controller; delegates to Psiphon. */
class WireGuardVpnController(context: Context) {
    private val delegate = PsiphonVpnManager(context.applicationContext)
    suspend fun connect(configText: String): Result<Unit> = delegate.connect()
    suspend fun disconnect(): Result<Unit> = delegate.disconnect()
    fun isConnected(): Boolean = delegate.isConnected()
    fun version(): String = "Psiphon"
}
