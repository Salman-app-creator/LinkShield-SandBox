package com.linkshield.sandbox.vpn

import android.content.Context

/** Legacy compatibility shell. */
class WireGuardVpnRepository(context: Context) {
    fun loadConfig(): Result<String> = Result.failure(IllegalStateException("WireGuard is no longer used"))
    suspend fun saveConfig(configText: String): Result<Unit> =
        Result.failure(IllegalStateException("WireGuard is no longer used"))
    fun deleteConfig() = Unit
    fun hasConfig(): Boolean = false
}
