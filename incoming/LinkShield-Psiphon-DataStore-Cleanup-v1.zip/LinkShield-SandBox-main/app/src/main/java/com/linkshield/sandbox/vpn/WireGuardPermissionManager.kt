package com.linkshield.sandbox.vpn

import android.app.Activity
import android.content.Intent
import android.net.VpnService

/** Legacy permission helper retained without the WireGuard SDK. */
class WireGuardPermissionManager(private val activity: Activity) {
    fun prepare(): Intent? = VpnService.prepare(activity)
}
