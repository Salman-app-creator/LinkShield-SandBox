package com.linkshield.sandbox.vpn

import android.content.Context

/** Legacy repository shell retained so old callers compile after the Psiphon migration. */
class WireGuardConfigRepository(context: Context) {
    fun loadConfig(): Result<String> = Result.failure(IllegalStateException("WireGuard is no longer used"))
    fun saveConfig(configText: String): Result<Unit> =
        Result.failure(IllegalStateException("WireGuard is no longer used"))
    fun deleteConfig() = Unit
    fun hasConfig(): Boolean = false
}
