package com.linkshield.sandbox.ui.grabber

// REPO PATH: app/src/main/java/com/linkshield/sandbox/ui/grabber/YouTubeGrabber.kt

import android.content.ContentValues
import android.content.Context
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.provider.MediaStore
import android.util.Log
import com.yausername.youtubedl_android.FFmpeg
import com.yausername.youtubedl_android.YoutubeDL
import com.yausername.youtubedl_android.YoutubeDLRequest
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import java.util.concurrent.atomic.AtomicBoolean

/** Result of the YouTube probe/fetch stage. */
data class YouTubeResult(
    val success: Boolean,
    val url: String? = null,
    val filename: String? = null,
    val mimeType: String? = null,
    val title: String? = null,
    val error: String? = null
)

data class YouTubeDownloadResult(
    val success: Boolean,
    val filename: String? = null,
    val error: String? = null
)

/**
 * YouTube-only backend.
 *
 * IMPORTANT:
 * - YouTube is NOT sent to Cobalt.
 * - Fetch/probe does not use DownloadManager.
 * - Actual YouTube downloads are performed by yt-dlp itself so FFmpeg can
 *   merge DASH video + audio. This is required for real 1080p/4K downloads.
 */
object YouTubeGrabber {

    private const val TAG = "YouTubeGrabber"
    private const val PROCESS_ID = "linkshield-youtube-download"
    private val initialized = AtomicBoolean(false)
    private val updateAttempted = AtomicBoolean(false)

    fun initialize(context: Context) {
        if (initialized.get()) return
        synchronized(this) {
            if (initialized.get()) return
            YoutubeDL.getInstance().init(context.applicationContext)
            initialized.set(true)
            Log.i(TAG, "yt-dlp initialized")
        }
    }

    fun isYouTubeUrl(rawUrl: String): Boolean {
        val host = try {
            Uri.parse(rawUrl.trim()).host?.lowercase().orEmpty()
        } catch (_: Throwable) {
            ""
        }
        return host == "youtube.com" || host.endsWith(".youtube.com") ||
            host == "youtu.be" || host.endsWith(".youtu.be")
    }

    fun extractVideoId(rawUrl: String): String? {
        return try {
            val uri = Uri.parse(rawUrl.trim())
            val host = uri.host?.lowercase().orEmpty()
            when {
                host == "youtu.be" -> uri.lastPathSegment
                host == "youtube.com" || host.endsWith(".youtube.com") ->
                    uri.getQueryParameter("v")
                        ?: uri.path?.substringAfter("/shorts/")?.substringBefore("/")
                else -> null
            }
        } catch (_: Throwable) {
            null
        }
    }

    private fun qualityValue(resolution: String): Int = when (resolution.uppercase().trim()) {
        "4K", "2160P" -> 2160
        "1440P" -> 1440
        "1080P" -> 1080
        "720P" -> 720
        "480P" -> 480
        "360P" -> 360
        else -> 1080
    }

    /**
     * Only verifies that yt-dlp can extract the video. It deliberately does
     * not return a stream URL for the UI to feed into DownloadManager because
     * that would lose the separate audio stream at 1080p/4K.
     */
    suspend fun extract(
        context: Context,
        pageUrl: String,
        resolution: String = "1080p",
        audioOnly: Boolean = false
    ): YouTubeResult = withContext(Dispatchers.IO) {
        if (!isYouTubeUrl(pageUrl)) {
            return@withContext YouTubeResult(false, error = "Not a YouTube URL")
        }

        try {
            initialize(context)
            FFmpeg.getInstance().init(context.applicationContext)
            val request = buildProbeRequest(pageUrl, qualityValue(resolution), audioOnly)
            val info = YoutubeDL.getInstance().getInfo(request)
            val title = runCatching { info.title }.getOrNull()?.takeIf { it.isNotBlank() }
            val streamUrl = runCatching { info.url }.getOrNull()?.takeIf { it.isNotBlank() }

            YouTubeResult(
                success = true,
                // This URL is only informational. The screen uses the original
                // YouTube page URL for the actual yt-dlp download.
                url = streamUrl,
                filename = "YouTube_${System.currentTimeMillis()}.${if (audioOnly) "mp3" else "mp4"}",
                mimeType = if (audioOnly) "audio/mpeg" else "video/mp4",
                title = title
            )
        } catch (first: Throwable) {
            Log.w(TAG, "Default YouTube extractor failed: ${first.message}")

            // Newer yt-dlp versions can sometimes get a usable set of formats
            // from android_vr when the default client set is unavailable.
            try {
                val request = buildProbeRequest(
                    pageUrl,
                    qualityValue(resolution),
                    audioOnly,
                    playerClient = "android_vr"
                )
                val info = YoutubeDL.getInstance().getInfo(request)
                val title = runCatching { info.title }.getOrNull()?.takeIf { it.isNotBlank() }
                YouTubeResult(
                    success = true,
                    url = runCatching { info.url }.getOrNull(),
                    filename = "YouTube_${System.currentTimeMillis()}.${if (audioOnly) "mp3" else "mp4"}",
                    mimeType = if (audioOnly) "audio/mpeg" else "video/mp4",
                    title = title
                )
            } catch (second: Throwable) {
                // If the bundled extractor is old, refresh it once and retry
                // using the normal client selection. This is intentionally
                // one-shot so every failed tap does not trigger an update.
                val updated = updateYtDlpOnce(context)
                if (updated) {
                    try {
                        val info = YoutubeDL.getInstance().getInfo(
                            buildProbeRequest(pageUrl, qualityValue(resolution), audioOnly)
                        )
                        YouTubeResult(
                            success = true,
                            url = runCatching { info.url }.getOrNull(),
                            filename = "YouTube_${System.currentTimeMillis()}.${if (audioOnly) "mp3" else "mp4"}",
                            mimeType = if (audioOnly) "audio/mpeg" else "video/mp4",
                            title = runCatching { info.title }.getOrNull()
                        )
                    } catch (third: Throwable) {
                        YouTubeResult(false, error = friendlyError(third))
                    }
                } else {
                    YouTubeResult(false, error = friendlyError(second))
                }
            }
        }
    }

    /**
     * Real YouTube download. yt-dlp selects separate video/audio streams and
     * FFmpeg merges them into one MP4. This is the critical fix for 1080p/4K.
     */
    suspend fun download(
        context: Context,
        pageUrl: String,
        resolution: String = "1080p",
        audioOnly: Boolean = false,
        onProgress: (Float) -> Unit = {}
    ): YouTubeDownloadResult = withContext(Dispatchers.IO) {
        if (!isYouTubeUrl(pageUrl)) {
            return@withContext YouTubeDownloadResult(false, error = "Not a YouTube URL")
        }

        val appContext = context.applicationContext
        val tempDir = File(appContext.getExternalFilesDir(Environment.DIRECTORY_DOWNLOADS), "youtube")
        if (!tempDir.exists() && !tempDir.mkdirs()) {
            return@withContext YouTubeDownloadResult(false, error = "Unable to create temporary download folder")
        }

        return@withContext try {
            initialize(appContext)
            FFmpeg.getInstance().init(appContext)

            val request = buildDownloadRequest(
                pageUrl = pageUrl,
                quality = qualityValue(resolution),
                audioOnly = audioOnly,
                outputDir = tempDir
            )

            var response = runCatching {
                YoutubeDL.getInstance().execute(request, PROCESS_ID) { progress, _, _ ->
                    onProgress(progress.coerceIn(0f, 100f) / 100f)
                }
            }.getOrElse { first ->
                Log.w(TAG, "YouTube download failed: ${first.message}")
                // Retry once after refreshing yt-dlp. This also covers a stale
                // extractor after YouTube changes its player implementation.
                if (updateYtDlpOnce(appContext)) {
                    YoutubeDL.getInstance().execute(request, PROCESS_ID) { progress, _, _ ->
                        onProgress(progress.coerceIn(0f, 100f) / 100f)
                    }
                } else {
                    throw first
                }
            }

            val outputFile = findNewestCompletedFile(tempDir)
                ?: throw IllegalStateException(
                    response.err?.trim()?.takeIf { it.isNotBlank() }
                        ?: "yt-dlp completed without producing a file"
                )

            val finalName = sanitizeFilename(outputFile.name)
            publishToDownloads(appContext, outputFile, finalName, audioOnly)
            onProgress(1f)

            YouTubeDownloadResult(true, filename = finalName)
        } catch (t: Throwable) {
            Log.e(TAG, "YouTube download failed", t)
            YouTubeDownloadResult(false, error = friendlyError(t))
        } finally {
            runCatching { YoutubeDL.getInstance().destroyProcessById(PROCESS_ID) }
            tempDir.listFiles()?.forEach { file ->
                if (file.isFile) runCatching { file.delete() }
            }
        }
    }

    private fun buildProbeRequest(
        pageUrl: String,
        quality: Int,
        audioOnly: Boolean,
        playerClient: String? = null
    ): YoutubeDLRequest = YoutubeDLRequest(pageUrl).apply {
        addOption("--no-playlist")
        addOption("--no-warnings")
        addOption("--no-check-certificates")
        if (!playerClient.isNullOrBlank()) {
            addOption("--extractor-args", "youtube:player_client=$playerClient")
        }
        addOption(
            "-f",
            if (audioOnly) {
                "bestaudio/best"
            } else {
                "bestvideo*[height<=?$quality]+bestaudio/b[height<=?$quality]/bestvideo*+bestaudio/b"
            }
        )
    }

    private fun buildDownloadRequest(
        pageUrl: String,
        quality: Int,
        audioOnly: Boolean,
        outputDir: File
    ): YoutubeDLRequest = YoutubeDLRequest(pageUrl).apply {
        addOption("--no-playlist")
        addOption("--no-warnings")
        addOption("--no-check-certificates")
        addOption("--no-mtime")
        addOption("--retries", "5")
        addOption("--fragment-retries", "5")
        addOption("--merge-output-format", "mp4")
        addOption(
            "-o",
            File(outputDir, "%(title).180B [%(id)s].%(ext)s").absolutePath
        )

        if (audioOnly) {
            addOption("-f", "bestaudio/best")
            addOption("-x")
            addOption("--audio-format", "mp3")
            addOption("--audio-quality", "128K")
        } else {
            // Do NOT use best[height<=X][ext=mp4]. That selector only accepts
            // a single already-muxed stream and is the direct cause of the
            // current "Requested format is not available" error.
            addOption(
                "-f",
                "bestvideo*[height<=?$quality]+bestaudio/b[height<=?$quality]/bestvideo*+bestaudio/b"
            )
        }
    }

    private fun findNewestCompletedFile(dir: File): File? {
        return dir.listFiles()
            ?.filter { it.isFile && !it.name.endsWith(".part") && it.length() > 0L }
            ?.maxByOrNull { it.lastModified() }
    }

    private fun publishToDownloads(
        context: Context,
        source: File,
        filename: String,
        audioOnly: Boolean
    ) {
        val mime = if (audioOnly) "audio/mpeg" else "video/mp4"

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            val values = ContentValues().apply {
                put(MediaStore.Downloads.DISPLAY_NAME, filename)
                put(MediaStore.Downloads.MIME_TYPE, mime)
                put(MediaStore.Downloads.RELATIVE_PATH, "${Environment.DIRECTORY_DOWNLOADS}/LinkShield")
                put(MediaStore.Downloads.IS_PENDING, 1)
            }

            val resolver = context.contentResolver
            val uri = resolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values)
                ?: throw IllegalStateException("Unable to create Downloads entry")

            try {
                resolver.openOutputStream(uri)?.use { output ->
                    FileInputStream(source).use { input -> input.copyTo(output, DEFAULT_BUFFER_SIZE) }
                } ?: throw IllegalStateException("Unable to open Downloads output stream")

                values.clear()
                values.put(MediaStore.Downloads.IS_PENDING, 0)
                resolver.update(uri, values, null, null)
            } catch (t: Throwable) {
                resolver.delete(uri, null, null)
                throw t
            }
        } else {
            val downloadsDir = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS)
            val targetDir = File(downloadsDir, "LinkShield")
            if (!targetDir.exists() && !targetDir.mkdirs()) {
                throw IllegalStateException("Unable to create Downloads/LinkShield")
            }
            val target = uniqueFile(File(targetDir, filename))
            FileInputStream(source).use { input ->
                FileOutputStream(target).use { output -> input.copyTo(output, DEFAULT_BUFFER_SIZE) }
            }
        }
    }

    private fun uniqueFile(file: File): File {
        if (!file.exists()) return file
        val base = file.nameWithoutExtension
        val ext = file.extension
        var i = 2
        while (true) {
            val candidate = File(file.parentFile, "$base ($i).$ext")
            if (!candidate.exists()) return candidate
            i++
        }
    }

    private fun sanitizeFilename(name: String): String {
        return name.replace(Regex("[/\\\\:*?\"<>|]"), "_")
            .trim()
            .ifBlank { "LinkShield_YouTube_${System.currentTimeMillis()}.mp4" }
    }

    private fun updateYtDlpOnce(context: Context): Boolean {
        if (!updateAttempted.compareAndSet(false, true)) return false
        return try {
            YoutubeDL.getInstance().updateYoutubeDL(
                context.applicationContext,
                YoutubeDL.UpdateChannel.STABLE
            )
            true
        } catch (t: Throwable) {
            Log.w(TAG, "yt-dlp update failed: ${t.message}")
            false
        }
    }

    private fun friendlyError(t: Throwable): String {
        val raw = t.message.orEmpty().trim()
        return when {
            raw.contains("Requested format is not available", ignoreCase = true) ->
                "YouTube format extraction failed. yt-dlp could not find a compatible stream."
            raw.contains("Sign in", ignoreCase = true) ->
                "YouTube requires additional verification for this video."
            raw.contains("403", ignoreCase = true) ->
                "YouTube rejected the media request (HTTP 403)."
            raw.isNotBlank() -> raw.take(500)
            else -> "YouTube extraction failed. Try again later."
        }
    }
}
