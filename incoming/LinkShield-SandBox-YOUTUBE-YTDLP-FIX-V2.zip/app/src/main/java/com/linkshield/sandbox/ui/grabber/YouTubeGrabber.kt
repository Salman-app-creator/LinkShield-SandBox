package com.linkshield.sandbox.ui.grabber

import android.content.ContentValues
import android.content.Context
import android.os.Environment
import android.os.Build
import android.provider.MediaStore
import com.yausername.youtubedl_android.YoutubeDL
import com.yausername.youtubedl_android.YoutubeDLRequest
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import java.util.Locale

/**
 * YouTube-only backend.
 *
 * We deliberately do not send YouTube URLs to Cobalt. yt-dlp handles YouTube
 * extraction and FFmpeg handles audio/video merging and MP3 conversion.
 */
object YouTubeGrabber {

    data class Info(
        val title: String,
        val thumbnail: String,
        val durationSeconds: Long = 0L
    )

    data class DownloadResult(
        val success: Boolean,
        val fileName: String = "",
        val error: String? = null
    )

    fun isYouTube(url: String): Boolean {
        return try {
            val host = android.net.Uri.parse(url.trim()).host?.lowercase(Locale.US).orEmpty()
            host == "youtu.be" || host == "youtube.com" || host.endsWith(".youtube.com")
        } catch (_: Exception) {
            false
        }
    }

    suspend fun fetchInfo(context: Context, url: String): Result<Info> = withContext(Dispatchers.IO) {
        runCatching {
            init(context)
            val video = YoutubeDL.getInstance().getInfo(url)
            val title = readString(video, "getTitle", "title").ifBlank { "YouTube Video" }
            val thumbnail = readString(video, "getThumbnail", "thumbnail")
                .ifBlank { extractYoutubeThumbnail(url) }
            val duration = readLong(video, "getDuration", "duration")
            Info(title = title, thumbnail = thumbnail, durationSeconds = duration)
        }
    }

    suspend fun download(
        context: Context,
        url: String,
        resolution: String,
        audioOnly: Boolean,
        onProgress: (Float) -> Unit
    ): DownloadResult = withContext(Dispatchers.IO) {
        try {
            init(context)

            val workDir = File(context.getExternalFilesDir(Environment.DIRECTORY_DOWNLOADS), "yt-dlp")
            if (!workDir.exists() && !workDir.mkdirs()) {
                return@withContext DownloadResult(false, error = "Unable to create temporary download folder.")
            }

            val stamp = System.currentTimeMillis()
            val ext = if (audioOnly) "mp3" else "mp4"
            val template = File(workDir, "LinkShield_${stamp}.%(ext)s").absolutePath

            val request = YoutubeDLRequest(url)
            request.addOption("--no-playlist")
            request.addOption("--no-mtime")
            request.addOption("--newline")
            request.addOption("--no-warnings")
            request.addOption("-o", template)

            if (audioOnly) {
                request.addOption("-f", "bestaudio/best")
                request.addOption("--extract-audio")
                request.addOption("--audio-format", "mp3")
                request.addOption("--audio-quality", "0")
            } else {
                val height = when (resolution.lowercase(Locale.US)) {
                    "4k", "2160p" -> 2160
                    "1440p" -> 1440
                    "1080p" -> 1080
                    "720p" -> 720
                    "480p" -> 480
                    "360p" -> 360
                    else -> 1080
                }
                // Prefer MP4/H264 video + M4A audio, then fall back to any
                // compatible format. FFmpeg merges separate streams.
                request.addOption(
                    "-f",
                    "bestvideo[height<=${height}][ext=mp4]+bestaudio[ext=m4a]/bestvideo[height<=${height}]+bestaudio/best[height<=${height}]/best"
                )
                request.addOption("--merge-output-format", "mp4")
            }

            YoutubeDL.getInstance().execute(request) { progress, _ ->
                onProgress((progress.coerceIn(0f, 100f)) / 100f)
            }

            val resultFile = workDir.listFiles()
                ?.filter { it.isFile && it.lastModified() >= stamp }
                ?.maxByOrNull { it.lastModified() }
                ?: workDir.listFiles()?.filter { it.isFile && it.name.startsWith("LinkShield_${stamp}") }?.maxByOrNull { it.lastModified() }

            if (resultFile == null || !resultFile.exists() || resultFile.length() <= 0L) {
                return@withContext DownloadResult(false, error = "yt-dlp completed without producing a media file.")
            }

            val baseName = sanitizeFileName(resultFile.name.substringBeforeLast('.')).removePrefix("LinkShield_")
            val finalName = "LinkShield_${baseName}.$ext"
            val mime = if (audioOnly) "audio/mpeg" else "video/mp4"
            publishToDownloads(context, resultFile, finalName, mime)
            resultFile.delete()
            onProgress(1f)
            DownloadResult(true, finalName)
        } catch (e: Exception) {
            DownloadResult(false, error = e.message ?: "YouTube download failed.")
        }
    }

    private fun init(context: Context) {
        YoutubeDL.getInstance().init(context.applicationContext)
        // FFmpeg is bundled separately and is required for MP4 stream merging
        // and MP3 extraction.
        com.yausername.youtubedl_android.FFmpeg.getInstance().init(context.applicationContext)
    }

    private fun publishToDownloads(context: Context, source: File, name: String, mime: String) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            val resolver = context.contentResolver
            val values = ContentValues().apply {
                put(MediaStore.MediaColumns.DISPLAY_NAME, name)
                put(MediaStore.MediaColumns.MIME_TYPE, mime)
                put(MediaStore.MediaColumns.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS + "/LinkShield")
                put(MediaStore.MediaColumns.IS_PENDING, 1)
            }
            val uri = resolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values)
                ?: throw IllegalStateException("Unable to create Downloads entry.")
            try {
                resolver.openOutputStream(uri)?.use { output ->
                    source.inputStream().use { input -> input.copyTo(output) }
                } ?: throw IllegalStateException("Unable to open Downloads output stream.")
                val done = ContentValues().apply {
                    put(MediaStore.MediaColumns.IS_PENDING, 0)
                }
                resolver.update(uri, done, null, null)
            } catch (e: Exception) {
                resolver.delete(uri, null, null)
                throw e
            }
        } else {
            @Suppress("DEPRECATION")
            val downloads = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS)
            val targetDir = File(downloads, "LinkShield")
            if (!targetDir.exists() && !targetDir.mkdirs()) {
                throw IllegalStateException("Unable to create Downloads/LinkShield folder.")
            }
            val target = File(targetDir, name)
            source.inputStream().use { input -> target.outputStream().use { output -> input.copyTo(output) } }
        }
    }

    private fun sanitizeFileName(value: String): String {
        return value.replace(Regex("[^A-Za-z0-9._-]+"), "_").trim('_').ifBlank { "video" }
    }

    private fun readString(target: Any, vararg names: String): String {
        for (name in names) {
            runCatching {
                val method = target.javaClass.methods.firstOrNull { it.name == name && it.parameterCount == 0 }
                val value = method?.invoke(target)?.toString().orEmpty()
                if (value.isNotBlank()) return value
            }
        }
        return ""
    }

    private fun readLong(target: Any, vararg names: String): Long {
        for (name in names) {
            runCatching {
                val method = target.javaClass.methods.firstOrNull { it.name == name && it.parameterCount == 0 }
                val value = method?.invoke(target)
                if (value is Number) return value.toLong()
            }
        }
        return 0L
    }

    private fun extractYoutubeThumbnail(url: String): String {
        return try {
            val uri = android.net.Uri.parse(url.trim())
            val host = uri.host?.lowercase(Locale.US).orEmpty()
            val id = when {
                host == "youtu.be" -> uri.lastPathSegment
                host == "youtube.com" || host.endsWith(".youtube.com") ->
                    uri.getQueryParameter("v") ?: uri.path?.substringAfter("/shorts/")?.substringBefore("/")
                else -> null
            }
            if (!id.isNullOrBlank()) "https://img.youtube.com/vi/$id/hqdefault.jpg" else ""
        } catch (_: Exception) { "" }
    }
}
