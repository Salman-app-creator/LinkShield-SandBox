# youtubedl-android uses reflection/packaged runtime components.
-keep class com.yausername.** { *; }
-keep class org.apache.commons.compress.** { *; }
