package com.linkshield.sandbox.ui.vpn

// REPO PATH: app/src/main/java/com/linkshield/sandbox/ui/vpn/VpnViewModel.kt

import android.app.Application
import android.content.Intent
import android.net.VpnService
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.linkshield.sandbox.vpn.TorVpnManager
import com.linkshield.sandbox.vpn.VpnConnectionState
import com.linkshield.sandbox.vpn.isActive
import com.linkshield.sandbox.vpn.isBusy
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

class VpnViewModel(application: Application) : AndroidViewModel(application) {

    private val torManager = TorVpnManager(application)

    private val _vpnState = MutableStateFlow<VpnConnectionState>(VpnConnectionState.Disconnected)
    val vpnState: StateFlow<VpnConnectionState> = _vpnState.asStateFlow()

    fun getVpnPermissionIntent(): Intent? = VpnService.prepare(getApplication())

    fun onToggleVpn(onPermissionRequired: (Intent) -> Unit) {
        val current = _vpnState.value
        if (current.isBusy) return
        if (current.isActive) { disconnect(); return }
        val permIntent = getVpnPermissionIntent()
        if (permIntent != null) onPermissionRequired(permIntent)
        else onPermissionGranted()
    }

    fun onPermissionGranted() {
        _vpnState.value = VpnConnectionState.Connecting
        viewModelScope.launch {
            val result = torManager.connect()
            if (result.isFailure) {
                _vpnState.value = VpnConnectionState.Error(
                    result.exceptionOrNull()?.message ?: "Could not start VPN service"
                )
                return@launch
            }

            // FIX: Immediately "Connected" set karna band karo.
            // torManager.connect() sirf service start karta hai — Tor
            // bootstrap aur packet forwarding abhi shuru nahi hote.
            // TorVpnManager.isConnected() sirf true hota hai jab
            // TorVpnService mein startPacketForwarding() actually chal raha ho.
            val timeoutMs = 100_000L  // 100s — Tor slow ho sakta hai
            val deadline  = System.currentTimeMillis() + timeoutMs

            while (System.currentTimeMillis() < deadline) {
                if (torManager.isConnected()) {
                    _vpnState.value = VpnConnectionState.Connected()
                    return@launch
                }
                delay(1_000L)
            }

            // Timeout — real tunnel nahi bana
            _vpnState.value = VpnConnectionState.Error(
                "Tor connect nahi hua. Internet check karo aur dobara try karo."
            )
            torManager.disconnect()
        }
    }

    fun disconnect() {
        _vpnState.value = VpnConnectionState.Disconnecting
        viewModelScope.launch {
            torManager.disconnect()
            _vpnState.value = VpnConnectionState.Disconnected
        }
    }

    fun clearError() {
        if (_vpnState.value is VpnConnectionState.Error)
            _vpnState.value = VpnConnectionState.Disconnected
    }
}
