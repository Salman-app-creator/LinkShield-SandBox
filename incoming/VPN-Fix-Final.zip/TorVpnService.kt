package com.linkshield.sandbox.vpn

// REPO PATH: app/src/main/java/com/linkshield/sandbox/vpn/TorVpnService.kt

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Intent
import android.net.VpnService
import android.os.Build
import android.os.ParcelFileDescriptor
import android.util.Log
import androidx.core.app.NotificationCompat
import com.linkshield.sandbox.MainActivity
import com.linkshield.sandbox.R
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.launch
import org.torproject.jni.TorService
import java.io.FileInputStream
import java.io.IOException
import java.net.InetSocketAddress
import java.net.Socket

class TorVpnService : VpnService() {

    companion object {
        const val ACTION_START = "com.linkshield.sandbox.TOR_START"
        const val ACTION_STOP  = "com.linkshield.sandbox.TOR_STOP"
        private const val NOTIFICATION_ID      = 1001
        private const val CHANNEL_ID           = "tor_vpn_channel"
        private const val TAG                  = "TorVpnService"
        private const val VPN_ADDRESS          = "10.0.0.2"
        private const val VPN_DNS              = "9.9.9.9"
        private const val TOR_SOCKS_HOST       = "127.0.0.1"
        private const val TOR_SOCKS_PORT       = 9050
        private const val BOOTSTRAP_TIMEOUT_MS = 90_000L
        private const val PORT_POLL_MS         = 800L
        private const val PORT_CONNECT_TIMEOUT = 1500
    }

    private var vpnInterface: ParcelFileDescriptor? = null
    private var torServiceIntent: Intent? = null
    private val serviceScope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    @Volatile private var isRunning = false

    override fun onCreate() {
        super.onCreate()
        createNotificationChannel()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_START -> {
                if (isRunning) return START_STICKY
                startForeground(NOTIFICATION_ID, buildNotification("Initializing Tor..."))
                serviceScope.launch { startVpn() }
            }
            ACTION_STOP -> serviceScope.launch { stopVpn() }
        }
        return START_STICKY
    }

    override fun onDestroy() {
        stopVpnInternal()
        serviceScope.cancel()
        super.onDestroy()
    }

    private fun startVpn() {
        try {
            isRunning = true
            TorVpnManager.setConnected(false)

            // Step 1: Start Tor daemon
            updateNotification("Starting Tor daemon...")
            torServiceIntent = Intent(this, TorService::class.java)
            startService(torServiceIntent)

            // Step 2: Wait for Tor SOCKS port
            updateNotification("Bootstrapping Tor network...")
            if (!waitForTorBootstrap()) {
                throw IOException("Tor bootstrap timed out after ${BOOTSTRAP_TIMEOUT_MS / 1000}s")
            }

            // Step 3: Build VPN TUN interface
            updateNotification("Creating VPN interface...")
            vpnInterface = buildVpnInterface()
                ?: throw IOException("Android rejected VPN interface")

            // Step 4: Start Java packet forwarding loop
            // No native binary needed — pure Java SOCKS5 forwarding
            updateNotification("Starting traffic routing...")
            startPacketForwarding(vpnInterface!!.fd)

            // Step 5: Only set connected AFTER forwarding is actually running
            TorVpnManager.setConnected(true)
            updateNotification("🔒 VPN Connected — Traffic routed through Tor")

        } catch (e: Exception) {
            Log.e(TAG, "VPN start failed: ${e.message}", e)
            TorVpnManager.setConnected(false)
            updateNotification("❌ ${e.message ?: "VPN failed"}")
            stopVpnInternal()
        }
    }

    private fun waitForTorBootstrap(): Boolean {
        val deadline = System.currentTimeMillis() + BOOTSTRAP_TIMEOUT_MS
        while (System.currentTimeMillis() < deadline) {
            if (isPortOpen(TOR_SOCKS_HOST, TOR_SOCKS_PORT)) {
                Thread.sleep(1500)
                return true
            }
            Thread.sleep(PORT_POLL_MS)
        }
        return false
    }

    private fun isPortOpen(host: String, port: Int): Boolean {
        return try {
            Socket().use { s ->
                s.connect(InetSocketAddress(host, port), PORT_CONNECT_TIMEOUT)
                true
            }
        } catch (_: IOException) { false }
    }

    private fun buildVpnInterface(): ParcelFileDescriptor? {
        return try {
            val builder = Builder()
                .setSession("LinkShield Tor VPN")
                .addAddress(VPN_ADDRESS, 32)
                .addRoute("0.0.0.0", 0)
                .addRoute("::", 0)
                .addDnsServer(VPN_DNS)
                .setMtu(1500)
                .setBlocking(true)

            // KEY FIX: Apni app ka traffic VPN se exclude karo
            // Warna Cobalt API calls Tor se jaati hain aur fail hoti hain
            // (Cobalt private IP pe hai jo Tor reach nahi kar sakta)
            try {
                builder.addDisallowedApplication(packageName)
                Log.i(TAG, "Own app excluded from VPN — Cobalt API will work normally")
            } catch (e: Exception) {
                Log.w(TAG, "Could not exclude own app: ${e.message}")
            }

            builder.establish()
        } catch (e: Exception) {
            Log.e(TAG, "VPN builder failed: ${e.message}", e)
            null
        }
    }

    /**
     * Java-based packet forwarding — TUN device se packets read karo,
     * SOCKS5 (Tor:9050) ke zariye forward karo.
     *
     * Koi native binary (libtun2socks.so) ki zaroorat nahi.
     *
     * Flow: App traffic → TUN fd → yeh loop → Tor SOCKS5:9050 → Internet
     */
    private fun startPacketForwarding(tunFd: Int) {
        serviceScope.launch(Dispatchers.IO) {
            val tunIn = FileInputStream("/proc/self/fd/$tunFd")
            val buf   = ByteArray(32767)

            Log.i(TAG, "Packet forwarding started — TUN fd=$tunFd → Tor SOCKS5 $TOR_SOCKS_HOST:$TOR_SOCKS_PORT")

            while (isRunning) {
                try {
                    val len = tunIn.read(buf)
                    if (len <= 0) continue

                    // Parse destination IP + port from IP packet header
                    val dest = parseDestination(buf, len) ?: continue

                    // Forward via SOCKS5 to Tor — each connection in separate coroutine
                    serviceScope.launch(Dispatchers.IO) {
                        forwardViaSocks5(dest.first, dest.second, buf.copyOf(len))
                    }

                } catch (e: Exception) {
                    if (isRunning) Log.w(TAG, "Packet read error: ${e.message}")
                }
            }

            try { tunIn.close() } catch (_: Exception) {}
            Log.i(TAG, "Packet forwarding stopped")
        }
    }

    /**
     * IPv4 TCP packet se destination IP aur port parse karo.
     * Non-TCP ya malformed packets ke liye null return karo.
     */
    private fun parseDestination(buf: ByteArray, len: Int): Pair<String, Int>? {
        return try {
            if (len < 20) return null

            // IP version check — sirf IPv4
            val ipVersion = (buf[0].toInt() and 0xFF) shr 4
            if (ipVersion != 4) return null

            // Protocol check — sirf TCP (6)
            val protocol = buf[9].toInt() and 0xFF
            if (protocol != 6) return null

            // IP header length
            val ihl = (buf[0].toInt() and 0x0F) * 4
            if (len < ihl + 4) return null

            val destIp = "${buf[16].toInt() and 0xFF}.${buf[17].toInt() and 0xFF}" +
                         ".${buf[18].toInt() and 0xFF}.${buf[19].toInt() and 0xFF}"
            val destPort = ((buf[ihl + 2].toInt() and 0xFF) shl 8) or
                           (buf[ihl + 3].toInt() and 0xFF)

            Pair(destIp, destPort)
        } catch (_: Exception) { null }
    }

    /**
     * SOCKS5 CONNECT ke zariye destination tak data forward karo.
     * RFC 1928 compliant.
     */
    private fun forwardViaSocks5(destIp: String, destPort: Int, data: ByteArray) {
        try {
            Socket().use { sock ->
                sock.connect(InetSocketAddress(TOR_SOCKS_HOST, TOR_SOCKS_PORT), 5000)
                sock.soTimeout = 15000
                val out = sock.getOutputStream()
                val inp = sock.getInputStream()

                // SOCKS5 handshake — NoAuth method
                out.write(byteArrayOf(0x05, 0x01, 0x00))
                out.flush()
                val authResp = ByteArray(2)
                inp.read(authResp)
                if (authResp[1] != 0x00.toByte()) return

                // SOCKS5 CONNECT request — IPv4
                val ipBytes = destIp.split(".")
                    .map { it.toInt().toByte() }
                    .toByteArray()
                val req = byteArrayOf(
                    0x05, 0x01, 0x00, 0x01,
                    *ipBytes,
                    (destPort shr 8).toByte(),
                    (destPort and 0xFF).toByte()
                )
                out.write(req)
                out.flush()

                val connResp = ByteArray(10)
                inp.read(connResp)
                if (connResp[1] != 0x00.toByte()) return

                // Data forward karo
                out.write(data)
                out.flush()
            }
        } catch (_: Exception) {
            // Silently drop — normal for some packets
        }
    }

    private fun stopVpn() {
        stopVpnInternal()
        @Suppress("DEPRECATION")
        stopForeground(true)
        stopSelf()
    }

    private fun stopVpnInternal() {
        isRunning = false
        TorVpnManager.setConnected(false)
        try { vpnInterface?.close() } catch (e: Exception) { Log.w(TAG, "TUN close: ${e.message}") }
        vpnInterface = null
        try { torServiceIntent?.let { stopService(it) }; torServiceIntent = null }
        catch (e: Exception) { Log.w(TAG, "Tor stop: ${e.message}") }
    }

    private fun updateNotification(text: String) {
        getSystemService(NotificationManager::class.java)
            ?.notify(NOTIFICATION_ID, buildNotification(text))
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val ch = NotificationChannel(
                CHANNEL_ID, "Tor VPN Tunnel", NotificationManager.IMPORTANCE_LOW
            ).apply { description = "LinkShield secure tunnel status"; setShowBadge(false) }
            getSystemService(NotificationManager::class.java)?.createNotificationChannel(ch)
        }
    }

    private fun buildNotification(text: String): Notification {
        val pi = PendingIntent.getActivity(
            this, 0,
            Intent(this, MainActivity::class.java).apply {
                flags = Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_SINGLE_TOP
            },
            PendingIntent.FLAG_IMMUTABLE
        )
        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle("LinkShield Secure Tunnel")
            .setContentText(text)
            .setSmallIcon(R.drawable.ic_app_logo)
            .setContentIntent(pi)
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .build()
    }
}
