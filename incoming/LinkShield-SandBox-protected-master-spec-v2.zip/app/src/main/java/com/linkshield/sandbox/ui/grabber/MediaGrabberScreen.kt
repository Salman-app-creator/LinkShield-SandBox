package com.linkshield.sandbox.ui.grabber

import android.content.Context
import android.widget.Toast
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Download
import androidx.compose.material.icons.filled.Link
import androidx.compose.material.icons.filled.Upgrade
import androidx.compose.material.icons.outlined.ContentPaste
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Checkbox
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalSoftwareKeyboardController
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.linkshield.sandbox.license.LicenseManager

@Composable
fun MediaGrabberScreen(
    viewModel: MediaExtractorViewModel = viewModel(),
    onUpgradeClick: () -> Unit = {}
) {
    val context = LocalContext.current
    val keyboard = LocalSoftwareKeyboardController.current
    val licenseManager = remember { LicenseManager(context.applicationContext) }
    val state by viewModel.state.collectAsState()
    var inputUrl by remember { mutableStateOf("") }
    var audioOnly by remember { mutableStateOf(false) }
    var highQuality by remember { mutableStateOf(true) }

    LaunchedEffect(state.error) {
        state.error?.let { Toast.makeText(context, it, Toast.LENGTH_LONG).show() }
    }

    fun extract() {
        if (inputUrl.isBlank()) return
        keyboard?.hide()
        viewModel.extract(inputUrl.trim(), audioOnly = audioOnly, highQuality = highQuality)
    }

    LazyColumn(
        modifier = Modifier.fillMaxSize().padding(12.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(14.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.tertiaryContainer)
            ) {
                Row(
                    Modifier.fillMaxWidth().padding(12.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(Modifier.weight(1f)) {
                        Text(
                            if (licenseManager.isProUser()) "PRO — Unlimited Downloads" else "${licenseManager.getRemainingDownloads()} Free Downloads Remaining",
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            if (licenseManager.isProUser()) "All grabber downloads are unlocked." else "Upgrade to Pro for Unlimited",
                            fontSize = 12.sp,
                            color = MaterialTheme.colorScheme.onTertiaryContainer
                        )
                    }
                    if (!licenseManager.isProUser()) {
                        TextButton(onClick = onUpgradeClick) {
                            Icon(Icons.Default.Upgrade, null, Modifier.size(17.dp))
                            Spacer(Modifier.width(3.dp))
                            Text("Upgrade")
                        }
                    }
                }
            }
        }

        item {
            OutlinedTextField(
                value = inputUrl,
                onValueChange = { inputUrl = it },
                modifier = Modifier.fillMaxWidth(),
                singleLine = true,
                label = { Text("Paste or Fetch Link...") },
                leadingIcon = { Icon(Icons.Default.Link, null) },
                trailingIcon = {
                    IconButton(onClick = {
                        val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as android.content.ClipboardManager
                        val clip = clipboard.primaryClip
                        if (clip != null && clip.itemCount > 0) inputUrl = clip.getItemAt(0).text?.toString().orEmpty()
                    }) { Icon(Icons.Outlined.ContentPaste, "Paste") }
                },
                keyboardOptions = KeyboardOptions(imeAction = ImeAction.Go),
                keyboardActions = KeyboardActions(onGo = { extract() })
            )
        }

        item {
            Button(
                onClick = { extract() },
                enabled = inputUrl.isNotBlank() && !state.isLoading,
                modifier = Modifier.fillMaxWidth().height(48.dp),
                shape = RoundedCornerShape(12.dp)
            ) {
                if (state.isLoading) {
                    CircularProgressIndicator(Modifier.size(20.dp), strokeWidth = 2.dp)
                    Spacer(Modifier.width(8.dp))
                    Text("Fetching...")
                } else {
                    Icon(Icons.Default.Download, null)
                    Spacer(Modifier.width(8.dp))
                    Text("Fetch Media")
                }
            }
        }

        if (state.options.isNotEmpty()) {
            item {
                Card(Modifier.fillMaxWidth(), shape = RoundedCornerShape(14.dp)) {
                    Column(Modifier.fillMaxWidth().padding(14.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        Text("Media Preview", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleMedium)
                        Text(
                            state.options.first().title.ifBlank { "Media ready" },
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                        Text(
                            state.options.first().displayLabel,
                            fontSize = 12.sp,
                            color = MaterialTheme.colorScheme.primary
                        )
                    }
                }
            }
        }

        item {
            Card(Modifier.fillMaxWidth(), shape = RoundedCornerShape(14.dp)) {
                Column(Modifier.padding(12.dp)) {
                    Text("Options", fontWeight = FontWeight.Bold)
                    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                        Checkbox(checked = audioOnly, onCheckedChange = { audioOnly = it })
                        Text("Audio Only", modifier = Modifier.weight(1f))
                        Checkbox(checked = highQuality, onCheckedChange = { highQuality = it })
                        Text("High Qual")
                    }
                }
            }
        }

        if (state.options.isNotEmpty()) {
            item {
                HorizontalDivider()
                Button(
                    onClick = {
                        val option = state.selected ?: return@Button
                        if (!licenseManager.canDownload()) {
                            Toast.makeText(context, licenseManager.getRestrictionReason(), Toast.LENGTH_LONG).show()
                            onUpgradeClick()
                            return@Button
                        }
                        val result = GrabberDownloadManager(context.applicationContext).download(option)
                        if (result != null) {
                            licenseManager.incrementDownloadCount()
                            Toast.makeText(context, "Download started", Toast.LENGTH_SHORT).show()
                        } else {
                            Toast.makeText(context, "Download failed", Toast.LENGTH_LONG).show()
                        }
                    },
                    enabled = state.selected != null,
                    modifier = Modifier.fillMaxWidth().height(52.dp),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Icon(Icons.Default.Download, null)
                    Spacer(Modifier.width(8.dp))
                    Text("Download")
                }
            }
        }
    }
}
