package com.linkshield.sandbox.ui.grabber

import android.content.Context
import android.net.Uri
import android.provider.MediaStore
import android.os.Build
import android.os.Environment
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.ContentPaste
import androidx.compose.material.icons.filled.Download
import androidx.compose.material.icons.filled.Link
import androidx.compose.material.icons.filled.PlayCircle
import androidx.compose.material.icons.filled.Upgrade
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Checkbox
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.linkshield.sandbox.api.CobaltApiService
import com.linkshield.sandbox.dns.DnsManager
import com.linkshield.sandbox.license.LicenseManager
import kotlinx.coroutines.launch

@Composable
fun LinkShieldGrabberScreen(
    onBackToBrowser: () -> Unit,
    onUpgradeClick: () -> Unit
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val license = remember { LicenseManager(context.applicationContext) }
    val cobalt = remember { CobaltApiService(context.applicationContext, DnsManager(context.applicationContext)) }

    var inputUrl by remember { mutableStateOf("") }
    var audioOnly by remember { mutableStateOf(false) }
    var highQuality by remember { mutableStateOf(true) }
    var loading by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf<String?>(null) }
    var result by remember { mutableStateOf<CobaltApiService.MediaResult?>(null) }
    var thumbnail by remember { mutableStateOf<String?>(null) }

    fun fetch() {
        val url = inputUrl.trim()
        if (url.isBlank() || loading) return
        loading = true
        error = null
        result = null
        thumbnail = youtubeThumbnail(url)
        scope.launch {
            val response = cobalt.fetchMediaUrl(
                pageUrl = url,
                downloadMode = if (audioOnly) "audio" else "auto",
                videoQuality = if (highQuality) "1080" else "720"
            )
            loading = false
            if (response.success) result = response else error = response.error ?: "No downloadable media found"
        }
    }

    LaunchedEffect(Unit) {
        // If a media link was captured in the browser, prefill it.
        MediaSnifferState.latestMedia.collect { media ->
            if (media != null && media.url.isNotBlank() && inputUrl.isBlank()) inputUrl = media.url
        }
    }

    Column(
        Modifier.fillMaxSize().padding(horizontal = 14.dp, vertical = 10.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = onBackToBrowser, modifier = Modifier.size(38.dp)) {
                Icon(Icons.Default.ArrowBack, "Back to current website")
            }
            Text("Grabber", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
        }

        Card(
            Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(14.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.tertiaryContainer)
        ) {
            Row(Modifier.fillMaxWidth().padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text(
                        if (license.isProUser()) "PRO — Unlimited Downloads" else "${license.getRemainingDownloads()} Free Downloads Remaining",
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        if (license.isProUser()) "Unlimited media downloads" else "Upgrade to Pro for Unlimited",
                        fontSize = 12.sp,
                        color = MaterialTheme.colorScheme.onTertiaryContainer
                    )
                }
                if (!license.isProUser()) {
                    TextButton(onClick = onUpgradeClick) {
                        Icon(Icons.Default.Upgrade, null, Modifier.size(17.dp))
                        Spacer(Modifier.width(3.dp))
                        Text("Upgrade")
                    }
                }
            }
        }

        OutlinedTextField(
            value = inputUrl,
            onValueChange = { inputUrl = it; error = null },
            modifier = Modifier.fillMaxWidth(),
            singleLine = true,
            label = { Text("Paste or Fetch Link...") },
            leadingIcon = { Icon(Icons.Default.Link, null) },
            trailingIcon = {
                IconButton(onClick = {
                    val cm = context.getSystemService(Context.CLIPBOARD_SERVICE) as android.content.ClipboardManager
                    inputUrl = cm.primaryClip?.getItemAt(0)?.text?.toString().orEmpty()
                }) { Icon(Icons.Default.ContentPaste, "Paste") }
            }
        )

        if (loading) {
            Button(onClick = {}, enabled = false, Modifier.fillMaxWidth().height(48.dp)) {
                CircularProgressIndicator(Modifier.size(19.dp), strokeWidth = 2.dp)
                Spacer(Modifier.width(8.dp))
                Text("Fetching media…")
            }
        } else {
            Button(onClick = { fetch() }, enabled = inputUrl.isNotBlank(), Modifier.fillMaxWidth().height(48.dp)) {
                Icon(Icons.Default.Download, null)
                Spacer(Modifier.width(8.dp))
                Text("Fetch Media")
            }
        }

        Card(
            Modifier.fillMaxWidth().height(145.dp),
            shape = RoundedCornerShape(14.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
        ) {
            Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                if (thumbnail != null) {
                    AsyncImage(
                        model = thumbnail,
                        contentDescription = "Media preview",
                        modifier = Modifier.fillMaxSize().clip(RoundedCornerShape(14.dp)),
                        contentScale = ContentScale.Crop
                    )
                }
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Icon(Icons.Default.PlayCircle, null, Modifier.size(46.dp), tint = MaterialTheme.colorScheme.primary)
                    Spacer(Modifier.height(4.dp))
                    Text(
                        result?.filename ?: "Media Preview Area",
                        fontSize = 12.sp,
                        fontWeight = FontWeight.SemiBold
                    )
                }
            }
        }

        Text("Options:", fontWeight = FontWeight.Bold)
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            Row(Modifier.weight(1f), verticalAlignment = Alignment.CenterVertically) {
                Checkbox(audioOnly, { audioOnly = it })
                Text("Audio Only", fontSize = 13.sp)
            }
            Row(verticalAlignment = Alignment.CenterVertically) {
                Checkbox(highQuality, { highQuality = it })
                Text("High Qual", fontSize = 13.sp)
            }
        }

        error?.let {
            Text(it, color = MaterialTheme.colorScheme.error, fontSize = 12.sp)
        }

        Spacer(Modifier.weight(1f))

        Button(
            onClick = {
                val media = result ?: return@Button
                if (!license.canDownload()) {
                    error = license.getRestrictionReason()
                    onUpgradeClick()
                    return@Button
                }
                scope.launch {
                    val saved = MediaFileDownloader.download(context, media.url.orEmpty(), media.filename.orEmpty(), media.mimeType.orEmpty())
                    if (saved) {
                        license.incrementDownloadCount()
                        error = null
                    } else {
                        error = "Download failed: the source did not return a media file."
                    }
                }
            },
            enabled = result?.url?.isNotBlank() == true,
            modifier = Modifier.fillMaxWidth().height(52.dp),
            shape = RoundedCornerShape(12.dp)
        ) {
            Icon(Icons.Default.Download, null)
            Spacer(Modifier.width(8.dp))
            Text("Download")
        }
    }
}

private fun youtubeThumbnail(url: String): String? {
    val uri = runCatching { Uri.parse(url) }.getOrNull() ?: return null
    val host = uri.host?.lowercase().orEmpty()
    val id = when {
        host == "youtu.be" -> uri.pathSegments.firstOrNull()
        host.contains("youtube.com") -> uri.getQueryParameter("v") ?: uri.pathSegments.dropWhile { it != "shorts" }.getOrNull(1)
        else -> null
    }
    return id?.takeIf { it.isNotBlank() }?.let { "https://i.ytimg.com/vi/$it/hqdefault.jpg" }
}

object MediaFileDownloader {
    suspend fun download(context: Context, url: String, filename: String, mimeType: String): Boolean = kotlinx.coroutines.withContext(kotlinx.coroutines.Dispatchers.IO) {
        if (!url.startsWith("http://") && !url.startsWith("https://")) return@withContext false
        val client = okhttp3.OkHttpClient.Builder().followRedirects(true).followSslRedirects(true).build()
        val request = okhttp3.Request.Builder().url(url).header("User-Agent", "Mozilla/5.0 LinkShieldSandbox/2.1").build()
        try {
            client.newCall(request).execute().use { response ->
                if (!response.isSuccessful) return@withContext false
                val body = response.body ?: return@withContext false
                val contentType = body.contentType()?.toString()?.lowercase().orEmpty()
                if (contentType.startsWith("text/html") || contentType.startsWith("text/plain")) return@withContext false
                val safeName = sanitizeFilename(filename, mimeType, url)
                if (Build.VERSION.SDK_INT >= 29) {
                    val values = android.content.ContentValues().apply {
                        put(MediaStore.Downloads.DISPLAY_NAME, safeName)
                        put(MediaStore.Downloads.MIME_TYPE, mimeType.ifBlank { contentType.ifBlank { "application/octet-stream" } })
                        put(MediaStore.Downloads.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS + "/LinkShield")
                        put(MediaStore.Downloads.IS_PENDING, 1)
                    }
                    val resolver = context.contentResolver
                    val uri = resolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values) ?: return@withContext false
                    try {
                        resolver.openOutputStream(uri)?.use { output -> body.byteStream().use { input -> input.copyTo(output) } } ?: return@withContext false
                        values.clear(); values.put(MediaStore.Downloads.IS_PENDING, 0)
                        resolver.update(uri, values, null, null)
                        true
                    } catch (e: Exception) {
                        resolver.delete(uri, null, null)
                        false
                    }
                } else {
                    val dir = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS + "/LinkShield")
                    if (!dir.exists()) dir.mkdirs()
                    val file = java.io.File(dir, safeName)
                    body.byteStream().use { input -> file.outputStream().use { output -> input.copyTo(output) } }
                    true
                }
            }
        } catch (_: Exception) { false }
    }

    private fun sanitizeFilename(filename: String, mimeType: String, url: String): String {
        var name = filename.substringAfterLast('/').substringBefore('?').substringBefore('#').ifBlank { "LinkShield_download" }
            .replace(Regex("[\\\\/:*?\"<>|]"), "_").trim()
        val ext = when {
            mimeType.contains("audio/mpeg") -> ".mp3"
            mimeType.contains("audio/mp4") -> ".m4a"
            mimeType.contains("video/mp4") -> ".mp4"
            mimeType.contains("webm") -> ".webm"
            mimeType.contains("ogg") -> ".ogg"
            else -> url.substringBefore('?').substringBefore('#').substringAfterLast('.').takeIf { it.length in 2..5 }?.let { ".$it" } ?: ".mp4"
        }
        if (!name.endsWith(ext, true)) name += ext
        return name
    }
}
