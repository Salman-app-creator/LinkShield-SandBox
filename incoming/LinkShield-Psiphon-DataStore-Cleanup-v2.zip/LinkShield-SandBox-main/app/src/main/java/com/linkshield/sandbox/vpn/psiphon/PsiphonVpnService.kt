package com.linkshield.sandbox.vpn.psiphon

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Context
import android.content.Intent
import android.os.Build
import android.os.IBinder
import android.util.Log
import androidx.core.app.NotificationCompat
import androidx.webkit.ProxyConfig
import androidx.webkit.ProxyController
import androidx.webkit.WebViewFeature
import ca.psiphon.PsiphonTunnel
import com.linkshield.sandbox.R
import com.linkshield.sandbox.vpn.VpnNotificationHelper
import java.util.concurrent.Executors

/** Foreground Psiphon service using the official Psiphon local HTTP proxy. */
class PsiphonVpnService : Service(), PsiphonTunnel.HostService {
    private val executor = Executors.newSingleThreadExecutor()
    private var tunnel: PsiphonTunnel? = null

    override fun onCreate() {
        super.onCreate()
        createChannel()
        startForeground(NOTIFICATION_ID, notification("Starting Psiphon…"))
        tunnel = PsiphonBootstrap.createTunnel(this)
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_STOP -> stopTunnel()
            else -> startTunnel()
        }
        return START_NOT_STICKY
    }

    private fun startTunnel() {
        val instance = tunnel ?: PsiphonBootstrap.createTunnel(this).also { tunnel = it }
        executor.execute {
            runCatching {
                instance.startTunneling("")
            }.onFailure {
                Log.e(TAG, "Psiphon failed to start", it)
                updateStateError(it.message ?: "Psiphon failed to start")
            }
        }
    }

    private fun stopTunnel() {
        val instance = tunnel
        executor.execute {
            runCatching { instance?.stop() }
            clearWebViewProxy()
            VpnNotificationHelper.cancel(this)
            stopForeground(STOP_FOREGROUND_REMOVE)
            stopSelf()
        }
    }

    override fun onDestroy() {
        runCatching { tunnel?.stop() }
        tunnel = null
        clearWebViewProxy()
        executor.shutdownNow()
        VpnNotificationHelper.cancel(this)
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun getContext(): Context = this

    override fun getPsiphonConfig(): String = PsiphonBootstrap.loadConfig(this)

    override fun onConnecting() {
        PsiphonVpnService.connected = false
        PsiphonVpnManager.markConnecting()
        updateNotification("Connecting to Psiphon…")
    }

    override fun onListeningHttpProxyPort(port: Int) {
        if (port <= 0) return
        applyWebViewProxy(port)
        updateNotification("Psiphon proxy ready")
    }

    override fun onConnected() {
        connected = true
        PsiphonVpnManager.markConnected()
        updateNotification("Psiphon tunnel connected")
    }

    override fun onExiting() {
        connected = false
        PsiphonVpnManager.markDisconnected()
        clearWebViewProxy()
        updateNotification("Psiphon disconnected")
    }

    override fun onDiagnosticMessage(message: String) {\n        Log.d(TAG, message)\n    }

    private fun applyWebViewProxy(port: Int) {
        if (!WebViewFeature.isFeatureSupported(WebViewFeature.PROXY_OVERRIDE)) return
        val config = ProxyConfig.Builder()
            .addProxyRule("http://127.0.0.1:$port")
            .build()
        runCatching {
            ProxyController.getInstance().setProxyOverride(config, executor, Runnable {})
        }.onFailure { Log.w(TAG, "Unable to apply WebView proxy", it) }
    }

    private fun clearWebViewProxy() {
        if (!WebViewFeature.isFeatureSupported(WebViewFeature.PROXY_OVERRIDE)) return
        runCatching {
            ProxyController.getInstance().clearProxyOverride(executor, Runnable {})
        }
    }

    private fun updateStateError(message: String) {
        connected = false
        PsiphonVpnManager.markError(message)
        clearWebViewProxy()
        updateNotification("Psiphon connection failed")
        Log.e(TAG, message)
    }

    private fun updateNotification(text: String) {
        getSystemService(NotificationManager::class.java)?.notify(NOTIFICATION_ID, notification(text))
    }

    private fun notification(text: String) =
        NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(R.drawable.ic_app_logo)
            .setContentTitle("LinkShield Shield")
            .setContentText(text)
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .build()

    private fun createChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            getSystemService(NotificationManager::class.java)?.createNotificationChannel(
                NotificationChannel(CHANNEL_ID, "LinkShield Shield", NotificationManager.IMPORTANCE_LOW)
            )
        }
    }

    companion object {
        const val ACTION_START = "com.linkshield.sandbox.vpn.psiphon.START"
        const val ACTION_STOP = "com.linkshield.sandbox.vpn.psiphon.STOP"
        private const val CHANNEL_ID = "linkshield_psiphon"
        private const val NOTIFICATION_ID = 4101
        private const val TAG = "PsiphonVpnService"
        @Volatile private var connected = false

        fun isRunning(): Boolean = connected
    }
}
