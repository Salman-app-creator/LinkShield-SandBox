package com.linkshield.sandbox.ui.components

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowDropDown
import androidx.compose.material.icons.filled.ArrowForward
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.ShieldMoon
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.Icon
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.linkshield.sandbox.R

/** Browser-only compact header. Maximum height: 52dp. */
@Composable
fun TopHeader(
    currentUrl: String,
    onUrlChange: (String) -> Unit,
    isShieldProtectionEnabled: Boolean,
    onShieldProtectionToggle: () -> Unit,
    isWireGuardEnabled: Boolean,
    onWireGuardToggle: () -> Unit,
    trialDaysLeft: Int,
    isDarkTheme: Boolean,
    onThemeToggle: (Boolean) -> Unit,
    canGoBack: Boolean,
    canGoForward: Boolean,
    onBack: () -> Unit,
    onForward: () -> Unit,
    onReload: () -> Unit,
    onNavigate: () -> Unit,
    isLoading: Boolean = false
) {
    var shieldMenu by rememberSaveable { mutableStateOf(false) }

    Surface(
        modifier = Modifier.fillMaxWidth().height(52.dp),
        tonalElevation = 2.dp
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 8.dp, vertical = 4.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Image(
                painter = painterResource(R.drawable.ic_app_logo),
                contentDescription = "LinkShield Sandbox",
                contentScale = ContentScale.Crop,
                modifier = Modifier.size(36.dp).clip(CircleShape)
            )

            Box {
                OutlinedButton(
                    onClick = { shieldMenu = true },
                    modifier = Modifier.height(30.dp),
                    contentPadding = androidx.compose.foundation.layout.PaddingValues(horizontal = 7.dp),
                    shape = RoundedCornerShape(9.dp)
                ) {
                    Icon(
                        if (isShieldProtectionEnabled) Icons.Default.Security else Icons.Default.ShieldMoon,
                        contentDescription = null,
                        modifier = Modifier.size(14.dp)
                    )
                    Spacer(Modifier.width(3.dp))
                    Text(
                        if (isShieldProtectionEnabled) "Shield ON" else "Shield OFF",
                        fontSize = 9.sp,
                        fontWeight = FontWeight.Bold
                    )
                    Icon(Icons.Default.ArrowDropDown, null, Modifier.size(14.dp))
                }

                DropdownMenu(
                    expanded = shieldMenu,
                    onDismissRequest = { shieldMenu = false }
                ) {
                    DropdownMenuItem(
                        text = { Text("Shield Protection / AdBlocker") },
                        trailingContent = {
                            Switch(
                                checked = isShieldProtectionEnabled,
                                onCheckedChange = { onShieldProtectionToggle() }
                            )
                        },
                        onClick = { onShieldProtectionToggle() }
                    )
                    DropdownMenuItem(
                        text = { Text("WireGuard VPN") },
                        trailingContent = {
                            Switch(
                                checked = isWireGuardEnabled,
                                onCheckedChange = { onWireGuardToggle() }
                            )
                        },
                        onClick = { onWireGuardToggle() }
                    )
                }
            }

            Surface(
                modifier = Modifier.height(24.dp),
                shape = RoundedCornerShape(50),
                color = androidx.compose.material3.MaterialTheme.colorScheme.tertiaryContainer
            ) {
                Text(
                    if (trialDaysLeft > 0) "Trial: ${trialDaysLeft}d" else "Trial expired",
                    modifier = Modifier.padding(horizontal = 7.dp, vertical = 4.dp),
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold
                )
            }

            Switch(
                checked = isDarkTheme,
                onCheckedChange = onThemeToggle,
                modifier = Modifier.scale(0.8f)
            )

            Surface(
                modifier = Modifier
                    .weight(1f)
                    .height(34.dp)
                    .padding(start = 4.dp),
                shape = RoundedCornerShape(9.dp),
                color = androidx.compose.material3.MaterialTheme.colorScheme.surfaceVariant
            ) {
                Row(
                    modifier = Modifier.padding(horizontal = 8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    BasicTextField(
                        value = currentUrl,
                        onValueChange = onUrlChange,
                        singleLine = true,
                        cursorBrush = SolidColor(androidx.compose.material3.MaterialTheme.colorScheme.primary),
                        textStyle = TextStyle(
                            fontSize = 11.sp,
                            color = androidx.compose.material3.MaterialTheme.colorScheme.onSurface
                        ),
                        keyboardOptions = KeyboardOptions(imeAction = ImeAction.Go),
                        keyboardActions = KeyboardActions(onGo = { onNavigate() }),
                        modifier = Modifier.weight(1f)
                    )
                    Icon(
                        imageVector = Icons.Default.ArrowForward,
                        contentDescription = if (isLoading) "Loading" else "Go",
                        tint = androidx.compose.material3.MaterialTheme.colorScheme.primary,
                        modifier = Modifier
                            .size(18.dp)
                            .clip(CircleShape)
                    )
                }
            }
        }
    }
}
