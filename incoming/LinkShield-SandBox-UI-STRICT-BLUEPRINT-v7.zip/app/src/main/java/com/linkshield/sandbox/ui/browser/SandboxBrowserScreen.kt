package com.linkshield.sandbox.ui.browser

import android.graphics.Bitmap
import android.view.ViewGroup
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.viewinterop.AndroidView
import com.linkshield.sandbox.ui.components.TopHeader

/**
 * Browser tab. The compact TopHeader is intentionally mounted here and nowhere else.
 * Backend protection engines are not executed by this UI layer.
 */
@Composable
fun SandboxBrowserScreen(
    onOpenGrabber: () -> Unit,
    onExit: () -> Unit,
    initialUrl: String = "",
    isShieldProtectionEnabled: Boolean = true,
    isWireGuardEnabled: Boolean = false,
    trialDaysLeft: Int = 30,
    isDarkTheme: Boolean = false,
    onShieldProtectionToggle: () -> Unit = {},
    onWireGuardToggle: () -> Unit = {},
    onThemeToggle: (Boolean) -> Unit = {},
) {
    var webView by androidx.compose.runtime.remember { mutableStateOf<WebView?>(null) }
    var currentUrl by rememberSaveable { mutableStateOf(initialUrl) }
    var title by rememberSaveable { mutableStateOf("LinkShield Sandbox") }
    var canBack by androidx.compose.runtime.remember { mutableStateOf(false) }
    var canForward by androidx.compose.runtime.remember { mutableStateOf(false) }
    var isLoading by androidx.compose.runtime.remember { mutableStateOf(false) }

    BackHandler {
        if (canBack) webView?.goBack() else onExit()
    }

    fun navigate() {
        val url = currentUrl.trim()
        if (url.isNotBlank()) {
            val normalized = if (
                url.startsWith("http://") || url.startsWith("https://")
            ) url else "https://$url"
            webView?.loadUrl(normalized)
        }
    }

    Column(Modifier.fillMaxSize()) {
        TopHeader(
            currentUrl = currentUrl,
            onUrlChange = { currentUrl = it },
            isShieldProtectionEnabled = isShieldProtectionEnabled,
            onShieldProtectionToggle = onShieldProtectionToggle,
            isWireGuardEnabled = isWireGuardEnabled,
            onWireGuardToggle = onWireGuardToggle,
            trialDaysLeft = trialDaysLeft,
            isDarkTheme = isDarkTheme,
            onThemeToggle = onThemeToggle,
            canGoBack = canBack,
            canGoForward = canForward,
            onBack = { webView?.goBack() },
            onForward = { webView?.goForward() },
            onReload = { webView?.reload() },
            onNavigate = ::navigate,
            isLoading = isLoading
        )

        AndroidView(
            modifier = Modifier.weight(1f).fillMaxWidth(),
            factory = { ctx ->
                WebView(ctx).apply {
                    layoutParams = ViewGroup.LayoutParams(
                        ViewGroup.LayoutParams.MATCH_PARENT,
                        ViewGroup.LayoutParams.MATCH_PARENT
                    )
                    settings.javaScriptEnabled = true
                    settings.domStorageEnabled = true
                    settings.databaseEnabled = true
                    settings.useWideViewPort = true
                    settings.loadWithOverviewMode = true
                    settings.setSupportMultipleWindows(false)

                    webViewClient = object : WebViewClient() {
                        override fun onPageStarted(
                            view: WebView?,
                            url: String?,
                            favicon: Bitmap?
                        ) {
                            isLoading = true
                            url?.let { currentUrl = it }
                            title = view?.title?.takeIf { it.isNotBlank() }
                                ?: "LinkShield Sandbox"
                        }

                        override fun onPageFinished(
                            view: WebView?,
                            url: String?
                        ) {
                            isLoading = false
                            url?.let { currentUrl = it }
                            canBack = view?.canGoBack() == true
                            canForward = view?.canGoForward() == true
                            title = view?.title?.takeIf { it.isNotBlank() }
                                ?: "LinkShield Sandbox"
                        }

                        override fun shouldOverrideUrlLoading(
                            view: WebView?,
                            request: WebResourceRequest?
                        ): Boolean {
                            val scheme = request?.url?.scheme?.lowercase()
                            return scheme != null && scheme !in setOf("http", "https")
                        }

                        override fun onRenderProcessGone(
                            view: WebView?,
                            detail: android.webkit.RenderProcessGoneDetail?
                        ): Boolean {
                            isLoading = false
                            runCatching { view?.destroy() }
                            webView = null
                            return true
                        }
                    }

                    webChromeClient = WebChromeClient()
                    webView = this
                    if (initialUrl.isNotBlank()) loadUrl(initialUrl)
                }
            },
            update = { webView = it }
        )
    }
}
