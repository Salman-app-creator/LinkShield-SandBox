package com.linkshield.sandbox

// REPO PATH: app/src/main/java/com/linkshield/sandbox/LinkShieldApp.kt

import android.app.Application
import android.util.Log
import com.linkshield.sandbox.adblock.AdBlockEngine
import com.linkshield.sandbox.ui.grabber.YouTubeGrabber
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch

class LinkShieldApp : Application() {

    private val appScope = CoroutineScope(SupervisorJob() + Dispatchers.Default)

    override fun onCreate() {
        super.onCreate()

        // AdBlock engine
        appScope.launch(Dispatchers.IO) {
            runCatching {
                AdBlockEngine.getInstance().initialize(this@LinkShieldApp)
            }.onFailure {
                Log.w("LinkShieldApp", "AdBlock init failed: ${it.message}")
            }
        }

        // YouTubeGrabber (yt-dlp) — background init
        appScope.launch(Dispatchers.IO) {
            runCatching {
                YouTubeGrabber.initialize(this@LinkShieldApp)
            }.onFailure {
                Log.w("LinkShieldApp", "yt-dlp pre-init failed: ${it.message}")
            }
        }
    }
}
